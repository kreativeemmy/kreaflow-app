import { useRef, useState } from "react";
import { Modal, PanResponder, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { palette } from "@/components/business-ui";
import { MONTHS, WEEKDAYS_SHORT, addDays, formatDateFriendly, isoToDate, today } from "@/lib/dates";

export function FormField({ label, value, onChangeText, placeholder, keyboardType = "default", multiline = false, secureTextEntry = false, autoCapitalize = "sentences" }: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  keyboardType?: "default" | "numeric" | "email-address" | "phone-pad";
  multiline?: boolean;
  secureTextEntry?: boolean;
  autoCapitalize?: "none" | "sentences" | "words" | "characters";
}) {
  const [revealed, setRevealed] = useState(false);
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <View>
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#9AA09C"
          keyboardType={keyboardType}
          multiline={multiline}
          secureTextEntry={secureTextEntry && !revealed}
          autoCapitalize={autoCapitalize}
          returnKeyType="done"
          style={[styles.input, multiline && styles.textarea, secureTextEntry && styles.inputWithIcon]}
        />
        {secureTextEntry ? (
          <TouchableOpacity onPress={() => setRevealed((value) => !value)} hitSlop={10} style={styles.revealButton} accessibilityLabel={revealed ? "Hide password" : "Show password"}>
            <MaterialIcons name={revealed ? "visibility-off" : "visibility"} size={19} color="#8A918C" />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

export function ChoicePills({ options, value, onChange }: { options: string[]; value: string; onChange: (option: string) => void }) {
  return (
    <View style={styles.choiceWrap}>
      {options.map((option) => {
        const active = option === value;
        return (
          <TouchableOpacity key={option} activeOpacity={0.72} onPress={() => onChange(option)} style={[styles.choice, active && styles.choiceActive]}>
            <Text style={[styles.choiceText, active && styles.choiceTextActive]}>{option}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// A drag-to-resize slider with no native dependency (plain PanResponder), so
// it works the same in the app and on the web build with nothing extra to
// install or link before the first APK.
export function SizeSlider({ label, value, min, max, step = 1, onChange, formatValue }: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  formatValue?: (value: number) => string;
}) {
  const trackWidth = useRef(1);
  const setFromX = (x: number) => {
    const ratio = Math.min(1, Math.max(0, x / trackWidth.current));
    const raw = min + ratio * (max - min);
    const snapped = Math.round(raw / step) * step;
    onChange(Math.min(max, Math.max(min, snapped)));
  };
  const responder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (event) => setFromX(event.nativeEvent.locationX),
      onPanResponderMove: (event) => setFromX(event.nativeEvent.locationX),
    })
  ).current;
  const percent = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  return (
    <View style={styles.sliderWrap}>
      <View style={styles.sliderLabelRow}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.sliderValue}>{formatValue ? formatValue(value) : value}</Text>
      </View>
      <View
        style={styles.sliderTrack}
        onLayout={(event) => { trackWidth.current = Math.max(1, event.nativeEvent.layout.width); }}
        {...responder.panHandlers}
      >
        <View style={styles.sliderBase} />
        <View style={[styles.sliderFill, { width: `${percent}%` }]} />
        <View style={[styles.sliderThumb, { left: `${percent}%` }]} />
      </View>
    </View>
  );
}

export function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const QUICK_PICKS: { label: string; days: number }[] = [
  { label: "Today", days: 0 },
  { label: "In a week", days: 7 },
  { label: "In 2 weeks", days: 14 },
  { label: "In a month", days: 30 },
];

/** A tap-to-open calendar for picking a real date, instead of typing one by
 * hand. Value in/out is always "YYYY-MM-DD", same as every other date field. */
export function DateField({ label, value, onChange }: { label: string; value: string; onChange: (iso: string) => void }) {
  const [open, setOpen] = useState(false);
  const selected = /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : today();
  const [viewDate, setViewDate] = useState(() => isoToDate(selected));

  const openPicker = () => { setViewDate(isoToDate(selected)); setOpen(true); };
  const pick = (iso: string) => { onChange(iso); setOpen(false); };

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
  while (cells.length % 7 !== 0) cells.push(null);

  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity activeOpacity={0.75} onPress={openPicker} style={[styles.input, styles.dateTrigger]}>
        <Text style={styles.dateTriggerText}>{formatDateFriendly(selected)}</Text>
        <MaterialIcons name="calendar-today" size={16} color="#8A918C" />
      </TouchableOpacity>
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <TouchableOpacity style={styles.modalBackdrop} activeOpacity={1} onPress={() => setOpen(false)}>
          <TouchableOpacity activeOpacity={1} style={styles.calendarCard} onPress={(e) => e.stopPropagation()}>
            <View style={styles.calendarHeader}>
              <TouchableOpacity hitSlop={8} onPress={() => setViewDate(new Date(year, month - 1, 1))}><MaterialIcons name="chevron-left" size={22} color={palette.ink} /></TouchableOpacity>
              <Text style={styles.calendarTitle}>{MONTHS[month]} {year}</Text>
              <TouchableOpacity hitSlop={8} onPress={() => setViewDate(new Date(year, month + 1, 1))}><MaterialIcons name="chevron-right" size={22} color={palette.ink} /></TouchableOpacity>
            </View>
            <View style={styles.calendarWeekRow}>{WEEKDAYS_SHORT.map((d) => <Text key={d} style={styles.calendarWeekday}>{d}</Text>)}</View>
            <View style={styles.calendarGrid}>
              {cells.map((day, i) => {
                const iso = day ? `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}` : null;
                const isSelected = iso === selected;
                return (
                  <TouchableOpacity key={i} disabled={!day} onPress={() => iso && pick(iso)} style={[styles.calendarCell, isSelected && styles.calendarCellSelected]}>
                    {day ? <Text style={[styles.calendarCellText, isSelected && styles.calendarCellTextSelected]}>{day}</Text> : null}
                  </TouchableOpacity>
                );
              })}
            </View>
            <View style={styles.quickPickRow}>
              {QUICK_PICKS.map((q) => (
                <TouchableOpacity key={q.label} onPress={() => pick(addDays(q.days))} style={styles.quickPickChip}>
                  <Text style={styles.quickPickText}>{q.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  sliderWrap: { gap: 9 },
  sliderLabelRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sliderValue: { color: palette.primary, fontSize: 12, lineHeight: 16, fontWeight: "800" },
  sliderTrack: { height: 30, justifyContent: "center" },
  sliderBase: { position: "absolute", left: 0, right: 0, height: 6, borderRadius: 3, backgroundColor: "#DCE6F2" },
  sliderFill: { position: "absolute", left: 0, height: 6, borderRadius: 3, backgroundColor: palette.primary },
  sliderThumb: { position: "absolute", width: 22, height: 22, borderRadius: 11, marginLeft: -11, backgroundColor: "#FFFFFF", borderWidth: 2, borderColor: palette.primary },
  section: { backgroundColor: palette.surface, borderRadius: 20, padding: 15, borderWidth: 1, borderColor: palette.fog, gap: 14 },
  sectionTitle: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" },
  field: { gap: 6 },
  label: { color: palette.muted, fontSize: 11, lineHeight: 14, letterSpacing: 0.4, fontWeight: "800", textTransform: "uppercase" },
  input: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "600", minHeight: 46, paddingHorizontal: 13, borderRadius: 13, borderWidth: 1, borderColor: palette.fog, backgroundColor: "#FAFCFF" },
  inputWithIcon: { paddingRight: 42 },
  revealButton: { position: "absolute", right: 4, top: 0, bottom: 0, width: 38, alignItems: "center", justifyContent: "center" },
  textarea: { minHeight: 94, paddingTop: 12, textAlignVertical: "top" },
  choiceWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  choice: { borderRadius: 99, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: palette.fog, backgroundColor: "#FAFCFF" },
  choiceActive: { backgroundColor: "#E6F1FF", borderColor: "#B4DEFF" },
  choiceText: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "700" },
  choiceTextActive: { color: palette.primary, fontWeight: "800" },
  dateTrigger: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  dateTriggerText: { color: palette.ink, fontSize: 14, fontWeight: "600" },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(50,54,55,0.45)", alignItems: "center", justifyContent: "center", padding: 24 },
  calendarCard: { width: "100%", maxWidth: 360, backgroundColor: palette.surface, borderRadius: 22, padding: 18, gap: 14 },
  calendarHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  calendarTitle: { color: palette.ink, fontSize: 15, fontWeight: "800" },
  calendarWeekRow: { flexDirection: "row" },
  calendarWeekday: { flex: 1, textAlign: "center", color: palette.muted, fontSize: 11, fontWeight: "700" },
  calendarGrid: { flexDirection: "row", flexWrap: "wrap" },
  calendarCell: { width: `${100 / 7}%`, aspectRatio: 1, alignItems: "center", justifyContent: "center", borderRadius: 999 },
  calendarCellSelected: { backgroundColor: palette.primary },
  calendarCellText: { color: palette.ink, fontSize: 13, fontWeight: "600" },
  calendarCellTextSelected: { color: "#FFFFFF", fontWeight: "800" },
  quickPickRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, paddingTop: 4, borderTopWidth: 1, borderTopColor: "#E8EFF7" },
  quickPickChip: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 99, backgroundColor: "#E6F1FF" },
  quickPickText: { color: palette.primary, fontSize: 11.5, fontWeight: "800" },
});
