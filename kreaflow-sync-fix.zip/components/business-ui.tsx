import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import type { ComponentProps, ReactNode } from "react";
import { useEffect, useRef, useState } from "react";
import { Animated, Modal, StyleSheet, Text, TouchableOpacity, View, type ViewStyle } from "react-native";
import { router } from "expo-router";

import { useBusiness } from "@/components/business-provider";

export const palette = {
  ink: "#323637",
  paper: "#F4F8FD",
  surface: "#FFFFFF",
  primary: "#0562E9",
  coral: "#F26A50",
  moss: "#3E8E6A",
  gold: "#F0D250",
  fog: "#DCE6F2",
  muted: "#6D736F",
  charcoal: "#323637",
};

type IconName = ComponentProps<typeof MaterialIcons>["name"];
type Tone = "primary" | "coral" | "moss" | "gold" | "fog";

const toneStyles: Record<Tone, ViewStyle> = {
  primary: { backgroundColor: "#E6F1FF" },
  coral: { backgroundColor: "#FDE9E4" },
  moss: { backgroundColor: "#E3F1EA" },
  gold: { backgroundColor: "#FBF1DB" },
  fog: { backgroundColor: palette.fog },
};

export function IconButton({ icon, onPress, label, solid = false }: { icon: IconName; onPress: () => void; label: string; solid?: boolean }) {
  return (
    <TouchableOpacity accessibilityRole="button" accessibilityLabel={label} activeOpacity={0.7} onPress={onPress} style={[styles.iconButton, solid && styles.iconButtonSolid]}>
      <MaterialIcons name={icon} size={20} color={solid ? palette.surface : palette.ink} />
    </TouchableOpacity>
  );
}

export function ScreenHeader({ eyebrow, title, subtitle, onSearch, onAlerts, onBack, action }: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  onSearch?: () => void;
  onAlerts?: () => void;
  onBack?: () => void;
  action?: ReactNode;
}) {
  return (
    <View style={styles.header}>
      <View style={styles.headerTitleRow}>
        <View style={styles.headerCopy}>
          {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.headerTitle}>{title}</Text>
          {subtitle ? <Text style={styles.headerSubtitle}>{subtitle}</Text> : null}
        </View>
        <View style={styles.headerActions}>
          {onBack ? <IconButton icon="arrow-back" label="Go back" onPress={onBack} /> : null}
          {onSearch ? <IconButton icon="search" label="Search business records" onPress={onSearch} /> : null}
          {onAlerts ? <IconButton icon="notifications-none" label="View notifications" onPress={onAlerts} /> : null}
          {action}
        </View>
      </View>
    </View>
  );
}

export function WorkspaceSwitcher() {
  const { activeWorkspace, workspaces, switchWorkspace } = useBusiness();
  const [visible, setVisible] = useState(false);
  return (
    <>
      <TouchableOpacity accessibilityRole="button" accessibilityLabel="Switch workspace" activeOpacity={0.72} onPress={() => setVisible(true)} style={styles.workspaceTrigger}>
        <MaterialIcons name="business" size={16} color={palette.primary} />
        <Text numberOfLines={1} style={styles.workspaceTriggerText}>{activeWorkspace?.name ?? "Choose workspace"}</Text>
        <MaterialIcons name="arrow-drop-down" size={19} color={palette.primary} />
      </TouchableOpacity>
      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => setVisible(false)}>
        <TouchableOpacity activeOpacity={1} onPress={() => setVisible(false)} style={styles.workspaceOverlay}>
          <TouchableOpacity activeOpacity={1} onPress={() => undefined} style={styles.workspaceSheet}>
            <View style={styles.workspaceSheetHeader}><View><Text style={styles.workspaceSheetEyebrow}>KREAFLOW WORKSPACES</Text><Text style={styles.workspaceSheetTitle}>Switch workspace</Text></View><IconButton icon="close" label="Close workspace switcher" onPress={() => setVisible(false)} /></View>
            <View style={styles.workspaceList}>{workspaces.map((workspace) => <TouchableOpacity key={workspace.id} activeOpacity={0.72} onPress={() => { switchWorkspace(workspace.id); setVisible(false); }} style={[styles.workspaceRow, workspace.id === activeWorkspace?.id && styles.workspaceRowActive]}><View style={styles.workspaceAvatar}><Text style={styles.workspaceAvatarText}>{workspace.name.slice(0, 1).toUpperCase()}</Text></View><View style={styles.workspaceCopy}><Text style={styles.workspaceName}>{workspace.name}</Text><Text style={styles.workspaceStatus}>{workspace.onboardingComplete ? "Ready workspace" : "Setup incomplete"}</Text></View>{workspace.id === activeWorkspace?.id ? <MaterialIcons name="check-circle" size={21} color={palette.moss} /> : null}</TouchableOpacity>)}</View>
            <TouchableOpacity activeOpacity={0.75} onPress={() => { setVisible(false); router.push("/workspaces"); }} style={styles.workspaceAction}><MaterialIcons name="add" size={20} color={palette.primary} /><Text style={styles.workspaceActionText}>Create workspace</Text></TouchableOpacity>
            <TouchableOpacity activeOpacity={0.75} onPress={() => { setVisible(false); router.push("/workspaces"); }} style={styles.workspaceManage}><Text style={styles.workspaceManageText}>Manage workspaces</Text><MaterialIcons name="arrow-forward" size={18} color={palette.primary} /></TouchableOpacity>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </>
  );
}

export function SectionHeading({ title, actionLabel, onAction }: { title: string; actionLabel?: string; onAction?: () => void }) {
  return (
    <View style={styles.sectionHeading}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {actionLabel && onAction ? (
        <TouchableOpacity onPress={onAction} activeOpacity={0.65} accessibilityRole="button">
          <Text style={styles.sectionAction}>{actionLabel}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

export function MetricCard({ label, value, detail, tone = "primary", icon }: { label: string; value: string; detail?: string; tone?: Tone; icon?: IconName }) {
  return (
    <View style={[styles.metricCard, toneStyles[tone]]}>
      <View style={styles.metricTopline}>
        <Text style={styles.metricLabel}>{label}</Text>
        {icon ? <MaterialIcons name={icon} size={17} color={palette.ink} /> : null}
      </View>
      <Text style={styles.metricValue}>{value}</Text>
      {detail ? <Text style={styles.metricDetail}>{detail}</Text> : null}
    </View>
  );
}

export function Pill({ label, tone = "fog" }: { label: string; tone?: Tone }) {
  const textColor = tone === "moss" ? palette.moss : tone === "coral" ? "#B54533" : tone === "gold" ? "#936315" : tone === "primary" ? palette.primary : palette.muted;
  return (
    <View style={[styles.pill, toneStyles[tone]]}>
      <Text style={[styles.pillText, { color: textColor }]}>{label}</Text>
    </View>
  );
}

export function ProgressBar({ value, tone = "primary", height = 8 }: { value: number; tone?: Tone; height?: number }) {
  const color = tone === "moss" ? palette.moss : tone === "coral" ? palette.coral : tone === "gold" ? palette.gold : palette.primary;
  const clamped = Math.max(0, Math.min(100, value));
  // Starts at the first value with no animation (so a freshly opened list
  // doesn't visibly fill up every bar at once), then eases toward any value
  // it's given after that — ticking off a step or logging a payment visibly
  // nudges the bar instead of just silently jumping.
  const animated = useRef(new Animated.Value(clamped)).current;
  const mounted = useRef(false);
  useEffect(() => {
    if (!mounted.current) { mounted.current = true; return; }
    Animated.timing(animated, { toValue: clamped, duration: 450, useNativeDriver: false }).start();
  }, [clamped, animated]);
  const width = animated.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"], extrapolate: "clamp" });
  return (
    <View style={[styles.progressTrack, { height }]} pointerEvents="none">
      <Animated.View style={[styles.progressFill, { width, height, backgroundColor: color }]} />
    </View>
  );
}

export function EmptyState({ title, detail, actionLabel, onAction, icon = "folder-open" }: { title: string; detail: string; actionLabel?: string; onAction?: () => void; icon?: IconName }) {
  return (
    <View style={styles.emptyState}>
      <View style={styles.emptyIcon}><MaterialIcons name={icon} size={26} color={palette.primary} /></View>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyDetail}>{detail}</Text>
      {actionLabel && onAction ? <PrimaryButton label={actionLabel} onPress={onAction} icon="add" compact /> : null}
    </View>
  );
}

export function PrimaryButton({ label, onPress, icon, compact = false, tone = "primary", disabled = false }: { label: string; onPress: () => void; icon?: IconName; compact?: boolean; tone?: "primary" | "coral"; disabled?: boolean }) {
  const background = tone === "coral" ? palette.coral : palette.primary;
  const scale = useRef(new Animated.Value(1)).current;
  const pressIn = () => Animated.spring(scale, { toValue: 0.96, useNativeDriver: true, speed: 50, bounciness: 0 }).start();
  const pressOut = () => Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 30, bounciness: 9 }).start();
  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <TouchableOpacity onPress={onPress} onPressIn={pressIn} onPressOut={pressOut} activeOpacity={0.82} accessibilityRole="button" disabled={disabled} style={[styles.primaryButton, compact && styles.primaryButtonCompact, { backgroundColor: background, opacity: disabled ? 0.6 : 1 }]}>
        {icon ? <MaterialIcons name={icon} size={18} color="#FFFFFF" /> : null}
        <Text style={styles.primaryButtonText}>{label}</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

export function Divider() { return <View style={styles.divider} />; }

/** A tap-to-check box with a small bounce on the way to checked — used for
 * every checklist in the app (project deliverables and tasks, goal steps),
 * so ticking something off feels the same, and feels good, everywhere. */
export function Checkbox({ checked, onToggle, size = 23 }: { checked: boolean; onToggle: () => void; size?: number }) {
  const scale = useRef(new Animated.Value(checked ? 1 : 0.85)).current;
  const mounted = useRef(false);
  useEffect(() => {
    if (!mounted.current) { mounted.current = true; return; }
    Animated.sequence([
      Animated.spring(scale, { toValue: checked ? 1.18 : 0.85, useNativeDriver: true, speed: 60, bounciness: 0 }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 20, bounciness: 9 }),
    ]).start();
  }, [checked, scale]);
  return (
    <TouchableOpacity onPress={onToggle} activeOpacity={0.75} hitSlop={6}>
      <Animated.View style={[styles.checkbox, { width: size, height: size, borderRadius: size * 0.35, transform: [{ scale }] }, checked && styles.checkboxComplete]}>
        {checked ? <MaterialIcons name="check" size={Math.round(size * 0.7)} color="#FFFFFF" /> : null}
      </Animated.View>
    </TouchableOpacity>
  );
}

export const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingTop: 6, paddingBottom: 14 },
  headerTitleRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 12 },
  headerCopy: { flex: 1, gap: 3 },
  headerActions: { flexDirection: "row", gap: 8, paddingTop: 3 },
  eyebrow: { color: palette.primary, fontSize: 11, lineHeight: 14, fontWeight: "800", letterSpacing: 1.1, textTransform: "uppercase" },
  headerTitle: { color: palette.ink, fontSize: 29, lineHeight: 34, fontWeight: "800", letterSpacing: -0.8 },
  headerSubtitle: { color: palette.muted, fontSize: 13, lineHeight: 19, maxWidth: 240 },
  iconButton: { width: 38, height: 38, alignItems: "center", justifyContent: "center", borderRadius: 19, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog },
  iconButtonSolid: { backgroundColor: palette.primary, borderColor: palette.primary },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 11 },
  sectionTitle: { color: palette.ink, fontSize: 17, lineHeight: 22, fontWeight: "800", letterSpacing: -0.25 },
  sectionAction: { color: palette.primary, fontSize: 13, lineHeight: 18, fontWeight: "800" },
  metricCard: { borderRadius: 20, padding: 15, minHeight: 116, width: "100%", gap: 6 },
  metricTopline: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 4 },
  metricLabel: { color: palette.ink, fontSize: 11, lineHeight: 14, fontWeight: "800", flexShrink: 1, maxWidth: "82%" },
  metricValue: { color: palette.ink, fontSize: 24, lineHeight: 29, fontWeight: "800", letterSpacing: -0.65 },
  metricDetail: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" },
  pill: { alignSelf: "flex-start", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 999 },
  pillText: { fontSize: 11, lineHeight: 13, fontWeight: "800" },
  progressTrack: { overflow: "hidden", borderRadius: 99, width: "100%", flexShrink: 1, minWidth: 0, backgroundColor: "#DCE6F2" },
  progressFill: { borderRadius: 99 },
  emptyState: { padding: 28, borderRadius: 22, borderWidth: 1, borderColor: palette.fog, backgroundColor: palette.surface, alignItems: "center", gap: 8, marginTop: 6 },
  emptyIcon: { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF", marginBottom: 3 },
  emptyTitle: { color: palette.ink, fontSize: 17, lineHeight: 22, fontWeight: "800", textAlign: "center" },
  emptyDetail: { color: palette.muted, fontSize: 13, lineHeight: 19, textAlign: "center", maxWidth: 260 },
  primaryButton: { minHeight: 48, paddingHorizontal: 17, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  primaryButtonCompact: { minHeight: 40, paddingHorizontal: 14, marginTop: 7 },
  primaryButtonText: { color: "#FFFFFF", fontSize: 14, lineHeight: 18, fontWeight: "800" },
  divider: { height: 1, backgroundColor: palette.fog, width: "100%" },
  checkbox: { borderWidth: 1.5, borderColor: "#C8CDC9", alignItems: "center", justifyContent: "center" },
  checkboxComplete: { borderColor: palette.moss, backgroundColor: palette.moss },
  workspaceTrigger: { marginTop: 10, minHeight: 35, alignSelf: "flex-start", maxWidth: "100%", paddingHorizontal: 11, borderRadius: 12, backgroundColor: "#EAF4FF", borderWidth: 1, borderColor: "#B4DEFF", flexDirection: "row", alignItems: "center", gap: 5 },
  workspaceTriggerText: { color: palette.primary, fontSize: 12, lineHeight: 16, fontWeight: "800", maxWidth: 220 },
  workspaceOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(23,33,30,.38)" },
  workspaceSheet: { backgroundColor: palette.paper, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, paddingBottom: 34, gap: 14 },
  workspaceSheetHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  workspaceSheetEyebrow: { color: palette.coral, fontSize: 10, lineHeight: 14, fontWeight: "900", letterSpacing: 1 },
  workspaceSheetTitle: { color: palette.ink, fontSize: 22, lineHeight: 28, fontWeight: "800", marginTop: 2 },
  workspaceList: { gap: 8 },
  workspaceRow: { flexDirection: "row", alignItems: "center", gap: 11, padding: 13, borderRadius: 17, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog },
  workspaceRowActive: { borderColor: "#8BC7FA", backgroundColor: "#F2F8FF" },
  workspaceAvatar: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#DDEEFF" },
  workspaceAvatarText: { color: "#044BB2", fontSize: 16, lineHeight: 20, fontWeight: "900" },
  workspaceCopy: { flex: 1, gap: 1 },
  workspaceName: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" },
  workspaceStatus: { color: palette.muted, fontSize: 10, lineHeight: 14, fontWeight: "700" },
  workspaceAction: { minHeight: 48, borderRadius: 15, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, backgroundColor: "#EAF4FF", borderWidth: 1, borderColor: "#B4DEFF" },
  workspaceActionText: { color: palette.primary, fontSize: 13, lineHeight: 18, fontWeight: "900" },
  workspaceManage: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5 },
  workspaceManageText: { color: palette.primary, fontSize: 12, lineHeight: 17, fontWeight: "800" },
});
