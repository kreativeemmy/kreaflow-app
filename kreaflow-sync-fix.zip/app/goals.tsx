import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useState } from "react";
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { Checkbox, EmptyState, ProgressBar, ScreenHeader, SectionHeading, palette } from "@/components/business-ui";
import { formatNaira, revenueThisMonth } from "@/lib/business-metrics";
import type { Goal } from "@/lib/business-types";

function goalTone(category: string): "primary" | "coral" | "moss" | "gold" { return category === "Revenue" ? "coral" : category === "Clients" ? "moss" : category === "Projects" ? "primary" : "gold"; }
function targetDisplay(category: string, value: number): string { return category === "Revenue" ? formatNaira(value) : String(value); }

function StepsList({ goal }: { goal: Goal }) {
  const { addGoalStep, toggleGoalStep } = useBusiness();
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState("");
  const submit = () => {
    const title = draft.trim();
    if (title) addGoalStep(goal.id, title);
    setDraft("");
    setAdding(false);
  };
  return <View style={styles.steps}>
    {goal.steps.map((step) => <View key={step.id} style={styles.stepRow}>
      <Checkbox checked={step.done} onToggle={() => toggleGoalStep(goal.id, step.id)} size={19} />
      <TouchableOpacity activeOpacity={0.7} onPress={() => toggleGoalStep(goal.id, step.id)} style={{ flex: 1 }}>
        <Text style={[styles.stepText, step.done && styles.stepTextDone]}>{step.title}</Text>
      </TouchableOpacity>
    </View>)}
    {adding ? <View style={styles.stepAddRow}>
      <TextInput value={draft} onChangeText={setDraft} placeholder="e.g. Post 2 case studies" placeholderTextColor={palette.muted} style={styles.stepInput} autoFocus onSubmitEditing={submit} returnKeyType="done" />
      <TouchableOpacity onPress={submit} style={styles.stepAddConfirm} hitSlop={8}><MaterialIcons name="check" size={17} color="#fff" /></TouchableOpacity>
    </View> : <TouchableOpacity onPress={() => setAdding(true)} activeOpacity={0.7} style={styles.stepAddOpen}>
      <MaterialIcons name="add" size={15} color={palette.primary} />
      <Text style={styles.stepAddText}>Add step</Text>
    </TouchableOpacity>}
  </View>;
}

function GoalCard({ goal }: { goal: Goal }) {
  const { nudgeGoal } = useBusiness();
  const progress = goal.target > 0 ? Math.min(100, (goal.current / goal.target) * 100) : 0;
  return <View style={styles.goalCard}>
    <View style={styles.goalTop}>
      <View style={styles.goalCopy}><Text style={styles.goalName}>{goal.name}</Text><Text style={styles.goalDeadline}>Due {goal.deadline}</Text></View>
      <Text style={styles.goalValue}>{targetDisplay(goal.category, goal.current)}<Text style={styles.goalTarget}> / {targetDisplay(goal.category, goal.target)}</Text></Text>
    </View>
    <ProgressBar value={progress} tone={goalTone(goal.category)} height={8} />
    <View style={styles.goalFoot}><Text style={styles.goalProgress}>{Math.round(progress)}% complete</Text><TouchableOpacity onPress={() => nudgeGoal(goal.id)} activeOpacity={0.72} style={styles.updateButton}><Text style={styles.updateText}>Update progress</Text></TouchableOpacity></View>
    <StepsList goal={goal} />
  </View>;
}

export default function GoalsScreen() {
  const { goals, transactions } = useBusiness();
  const revenue = revenueThisMonth(transactions);
  const revenueGoal = goals.find((goal) => goal.category === "Revenue");
  const revenueProgress = revenueGoal && revenueGoal.target > 0 ? Math.min(100, (revenue / revenueGoal.target) * 100) : 0;
  const visionGoals = goals.filter((goal) => goal.level === "year" && goal.id !== revenueGoal?.id);
  const monthGoals = goals.filter((goal) => goal.level === "month");
  const otherGoals = goals.filter((goal) => goal.level === "custom" && goal.id !== revenueGoal?.id);

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Growth signals" title="Goals" subtitle="A vision for the year, broken into months you can actually check off." onBack={() => router.back()} action={<TouchableOpacity activeOpacity={0.8} onPress={() => router.push("/create?type=goal")} style={styles.addButton}><MaterialIcons name="add" color="#FFF" size={22} /></TouchableOpacity>} />

    {revenueGoal ? <View style={styles.hero}><Text style={styles.heroEyebrow}>REVENUE TARGET</Text><View style={styles.heroTop}><Text style={styles.heroValue}>{formatNaira(revenue)}</Text><View style={styles.heroPercent}><Text style={styles.heroPercentText}>{Math.round(revenueProgress)}%</Text></View></View><Text style={styles.heroDetail}>{formatNaira(revenueGoal.target - revenue > 0 ? revenueGoal.target - revenue : 0)} remaining to your target</Text><ProgressBar value={revenueProgress} tone="gold" height={10} /><View style={styles.heroFoot}><Text style={styles.heroFootText}>Current revenue</Text><Text style={styles.heroFootText}>{formatNaira(revenueGoal.target)} target · Due {revenueGoal.deadline}</Text></View></View> : null}

    <View style={styles.section}><SectionHeading title="Yearly vision" actionLabel="New vision" onAction={() => router.push("/create?type=goal")} />
      {visionGoals.length ? <View style={styles.goalList}>{visionGoals.map((goal) => <GoalCard key={goal.id} goal={goal} />)}</View>
        : !revenueGoal ? <EmptyState title="No vision set yet" detail="Set the one big thing you want true by the end of the year." actionLabel="Set your vision" onAction={() => router.push("/create?type=goal")} icon="flag" />
        : <Text style={styles.hint}>Your revenue target above is this year&rsquo;s headline number. Add another vision goal if there&rsquo;s more to it than money.</Text>}
    </View>

    <View style={styles.section}><SectionHeading title="This month" actionLabel="New goal" onAction={() => router.push("/create?type=goal")} />
      {monthGoals.length ? <View style={styles.goalList}>{monthGoals.map((goal) => <GoalCard key={goal.id} goal={goal} />)}</View>
        : <EmptyState title="No goals for this month yet" detail="Break your vision into something you can finish in the next few weeks." actionLabel="Add a monthly goal" onAction={() => router.push("/create?type=goal")} icon="calendar-today" />}
    </View>

    <View style={styles.section}><SectionHeading title="Other goals" actionLabel="New goal" onAction={() => router.push("/create?type=goal")} />
      {otherGoals.length ? <View style={styles.goalList}>{otherGoals.map((goal) => <GoalCard key={goal.id} goal={goal} />)}</View>
        : <EmptyState title="Nothing here yet" detail="One-off goals that don't belong to a specific month live here." actionLabel="Create goal" onAction={() => router.push("/create?type=goal")} icon="flag" />}
    </View>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 32 }, addButton: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: palette.primary, marginTop: 3 }, hero: { marginHorizontal: 20, marginTop: 4, padding: 19, borderRadius: 23, backgroundColor: palette.primary, gap: 11 }, heroEyebrow: { color: "#DCEBFF", fontSize: 10, lineHeight: 14, letterSpacing: 0.8, fontWeight: "800" }, heroTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, heroValue: { color: "#FFF", fontSize: 31, lineHeight: 37, fontWeight: "800", letterSpacing: -0.8 }, heroPercent: { width: 53, height: 53, borderRadius: 18, backgroundColor: "#044BB2", alignItems: "center", justifyContent: "center" }, heroPercentText: { color: "#FFF", fontSize: 17, lineHeight: 22, fontWeight: "800" }, heroDetail: { color: "#DCEBFF", fontSize: 12, lineHeight: 16, fontWeight: "600" }, heroFoot: { flexDirection: "row", justifyContent: "space-between" }, heroFootText: { color: "#DCEBFF", fontSize: 10, lineHeight: 14, fontWeight: "700" },
  section: { marginTop: 25, paddingHorizontal: 20 }, hint: { color: palette.muted, fontSize: 12, lineHeight: 18, fontWeight: "600" }, goalList: { gap: 10 },
  goalCard: { backgroundColor: palette.surface, borderRadius: 20, borderWidth: 1, borderColor: palette.fog, padding: 15, gap: 12 }, goalTop: { flexDirection: "row", justifyContent: "space-between", gap: 10 }, goalCopy: { flex: 1, gap: 3 }, goalName: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "800" }, goalDeadline: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" }, goalValue: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800", textAlign: "right" }, goalTarget: { color: palette.muted, fontSize: 11, fontWeight: "700" }, goalFoot: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, goalProgress: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "700" }, updateButton: { paddingVertical: 5 }, updateText: { color: palette.primary, fontSize: 11, lineHeight: 15, fontWeight: "800" },
  steps: { gap: 8, paddingTop: 10, borderTopWidth: 1, borderTopColor: "#E8EFF7" }, stepRow: { flexDirection: "row", alignItems: "center", gap: 9 }, stepText: { flex: 1, color: palette.ink, fontSize: 12.5, lineHeight: 17, fontWeight: "600" }, stepTextDone: { color: palette.muted, textDecorationLine: "line-through" },
  stepAddRow: { flexDirection: "row", alignItems: "center", gap: 8 }, stepInput: { flex: 1, minHeight: 34, borderWidth: 1, borderColor: "#D5E0EE", borderRadius: 9, backgroundColor: "#FAFCFF", paddingHorizontal: 10, color: palette.ink, fontSize: 12 }, stepAddConfirm: { width: 34, height: 34, borderRadius: 9, alignItems: "center", justifyContent: "center", backgroundColor: palette.primary },
  stepAddOpen: { flexDirection: "row", alignItems: "center", gap: 5, alignSelf: "flex-start" }, stepAddText: { color: palette.primary, fontSize: 11.5, fontWeight: "800" },
});
