import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, Pill, ProgressBar, ScreenHeader, palette } from "@/components/business-ui";
import { clientName, formatNaira, projectBalance, projectProgress } from "@/lib/business-metrics";
import { formatDateFriendly, today } from "@/lib/dates";
import type { Project } from "@/lib/business-types";

const filters = ["All", "Active", "Awaiting Feedback", "Revision", "Completed", "Overdue"];

function tone(status: string): "primary" | "coral" | "gold" | "moss" {
  if (status === "Delivered" || status === "Approved") return "moss";
  if (status === "Review") return "gold";
  if (status === "Revision") return "coral";
  return "primary";
}
function toneColor(t: "primary" | "coral" | "gold" | "moss"): string {
  return t === "moss" ? palette.moss : t === "coral" ? palette.coral : t === "gold" ? palette.gold : palette.primary;
}

function matchesFilter(project: Project, filter: string): boolean {
  if (filter === "All") return true;
  if (filter === "Active") return !["Delivered", "Review"].includes(project.status);
  if (filter === "Awaiting Feedback") return project.status === "Review";
  if (filter === "Revision") return project.status === "Revision";
  if (filter === "Completed") return project.status === "Delivered";
  if (filter === "Overdue") return project.deadline < today() && project.status !== "Delivered";
  return true;
}

export default function ProjectsScreen() {
  const { projects, clients, transactions } = useBusiness();
  const [filter, setFilter] = useState("All");
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => projects.filter((project) => {
    const client = clientName(project.clientId, clients).toLowerCase();
    return matchesFilter(project, filter) && (`${project.name} ${client}`.toLowerCase().includes(query.toLowerCase()));
  }), [projects, clients, filter, query]);

  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
      <ScreenHeader eyebrow="Delivery desk" title="Projects" subtitle="Every brief, deadline, revision, and balance in one place." onSearch={() => router.push("/search")} action={<TouchableOpacity activeOpacity={0.8} onPress={() => router.push("/create?type=project")} style={styles.addButton}><MaterialIcons name="add" color="#FFF" size={22} /></TouchableOpacity>} />
      <View style={styles.searchBox}>
        <MaterialIcons name="search" size={20} color="#7A817C" />
        <TextInput value={query} onChangeText={setQuery} placeholder="Search project or client" placeholderTextColor="#9AA09C" style={styles.searchInput} returnKeyType="done" />
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterWrap}>
        {filters.map((item) => (
          <TouchableOpacity key={item} activeOpacity={0.7} onPress={() => setFilter(item)} style={[styles.filter, filter === item && styles.filterActive]}>
            <Text style={[styles.filterText, filter === item && styles.filterTextActive]}>{item}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.summaryLine}><Text style={styles.summaryText}>{filtered.length} projects matching your view</Text><Text style={styles.summaryText}>Sorted by deadline</Text></View>
      <View style={styles.list}>
        {filtered.length ? filtered.map((project) => {
          const balance = projectBalance(project, transactions);
          return (
            <TouchableOpacity key={project.id} style={[styles.card, { borderLeftWidth: 4, borderLeftColor: toneColor(tone(project.status)) }]} activeOpacity={0.74} onPress={() => router.push({ pathname: "/project/[id]", params: { id: project.id } })}>
              <View style={styles.cardTop}><View style={styles.cardCopy}><Text style={styles.projectName}>{project.name}</Text><Text style={styles.clientText}>{clientName(project.clientId, clients)} · {project.service}</Text></View><Pill label={project.status} tone={tone(project.status)} /></View>
              <View style={styles.cardMeta}><View><Text style={styles.metaLabel}>PRICE</Text><Text style={styles.metaValue}>{formatNaira(project.price)}</Text></View><View><Text style={styles.metaLabel}>DEADLINE</Text><Text style={styles.metaValue}>{formatDateFriendly(project.deadline)}</Text></View><View><Text style={styles.metaLabel}>BALANCE</Text><Text style={[styles.metaValue, balance ? { color: palette.coral } : { color: palette.moss }]}>{formatNaira(balance)}</Text></View></View>
              <View style={styles.progressLine}><ProgressBar value={projectProgress(project)} tone={tone(project.status)} height={7} /><Text style={styles.progressText}>{projectProgress(project)}%</Text></View>
            </TouchableOpacity>
          );
        }) : <EmptyState title="No projects found" detail="Try a different filter, or create a project to begin the workflow." actionLabel="Create project" onAction={() => router.push("/create?type=project")} />}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 30 },
  addButton: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: palette.primary, marginTop: 3 },
  searchBox: { flexDirection: "row", alignItems: "center", gap: 9, marginHorizontal: 20, paddingHorizontal: 13, height: 49, borderRadius: 15, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog },
  searchInput: { flex: 1, color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "600" },
  filterWrap: { paddingHorizontal: 20, paddingTop: 14, gap: 8 }, filter: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 99, backgroundColor: "#ECEDE9" }, filterActive: { backgroundColor: palette.primary }, filterText: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "700" }, filterTextActive: { color: "#FFF", fontWeight: "800" },
  summaryLine: { marginTop: 17, paddingHorizontal: 20, flexDirection: "row", justifyContent: "space-between", gap: 10 }, summaryText: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "700" },
  list: { paddingHorizontal: 20, paddingTop: 10, gap: 10 }, card: { backgroundColor: palette.surface, borderRadius: 20, borderWidth: 1, borderColor: palette.fog, padding: 15, gap: 15 }, cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }, cardCopy: { flex: 1, gap: 4 }, projectName: { color: palette.ink, fontSize: 16, lineHeight: 21, fontWeight: "800", letterSpacing: -0.2 }, clientText: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "600" },
  cardMeta: { flexDirection: "row", justifyContent: "space-between", gap: 10 }, metaLabel: { color: "#8A918C", fontSize: 9, lineHeight: 12, letterSpacing: 0.6, fontWeight: "800" }, metaValue: { color: palette.ink, fontSize: 12, lineHeight: 17, fontWeight: "800", marginTop: 2 }, progressLine: { flexDirection: "row", alignItems: "center", gap: 10 }, progressText: { flexShrink: 0, minWidth: 42, textAlign: "right", color: palette.muted, fontSize: 11, lineHeight: 14, fontWeight: "800" },
});
