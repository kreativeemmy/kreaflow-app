import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { Pill, ScreenHeader, palette } from "@/components/business-ui";
import { formatNaira, totalOutstanding, revenueThisMonth } from "@/lib/business-metrics";
import { PRODUCT_IDENTITY } from "@/lib/product-identity";

const menu = [
  { title: "Money", detail: "Revenue, balances, and transactions", icon: "account-balance-wallet" as const, route: "/money", tone: "coral" as const },
  { title: "Invoices", detail: "Open, preview, and download saved invoices", icon: "file-download" as const, route: "/invoices", tone: "primary" as const },
  { title: "Invoice design", detail: "Brand, customize, and reset client-ready invoices", icon: "receipt-long" as const, route: "/invoice-design", tone: "moss" as const },
  { title: "Goals", detail: "Monthly targets and growth signals", icon: "flag" as const, route: "/goals", tone: "moss" as const },
  { title: "Business alerts", detail: "Deadlines, follow-ups, and payment nudges", icon: "notifications-active" as const, route: "/alerts", tone: "gold" as const },
  { title: "Notifications", detail: "Device reminders and cloud push delivery", icon: "notifications-active" as const, route: "/notifications", tone: "gold" as const },
  { title: "Account & backup", detail: "Secure sign-in and cloud workspace protection", icon: "cloud-done" as const, route: "/account", tone: "moss" as const },
];

export default function MoreScreen() {
  const { projects, transactions, goals, businessProfile } = useBusiness();
  const revenueGoal = goals.find((goal) => goal.category === "Revenue");
  const revenue = revenueThisMonth(transactions);
  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <ScreenHeader eyebrow="Business pulse" title="More" subtitle="Your money, goals, and business reminders." />
      <View style={styles.summary}><View style={styles.summaryTop}><View><Text style={styles.summaryLabel}>AUGUST POSITION</Text><Text style={styles.summaryValue}>{formatNaira(revenue)}</Text><Text style={styles.summaryDetail}>received this month</Text></View><Pill label={revenueGoal ? `${Math.round((revenue / revenueGoal.target) * 100)}% goal` : "On track"} tone="moss" /></View><View style={styles.summaryLine}><Text style={styles.summaryLineLabel}>Outstanding to collect</Text><Text style={styles.summaryLineValue}>{formatNaira(totalOutstanding(projects, transactions))}</Text></View></View>
      <View style={styles.menu}>{menu.map((item) => <TouchableOpacity key={item.title} style={styles.menuItem} activeOpacity={0.74} onPress={() => router.push(item.route)}><View style={[styles.menuIcon, item.tone === "coral" ? { backgroundColor: "#FDE9E4" } : item.tone === "moss" ? { backgroundColor: "#E3F1EA" } : { backgroundColor: "#FBF1DB" }]}><MaterialIcons name={item.icon} size={21} color={item.tone === "coral" ? palette.coral : item.tone === "moss" ? palette.moss : palette.gold} /></View><View style={styles.menuCopy}><Text style={styles.menuTitle}>{item.title}</Text><Text style={styles.menuDetail}>{item.detail}</Text></View><MaterialIcons name="chevron-right" size={23} color="#9AA09C" /></TouchableOpacity>)}</View>
      <View style={styles.helpCard}><View style={styles.helpMark}><Text style={styles.helpMarkText}>K</Text></View><View style={styles.helpCopy}><Text style={styles.helpTitle}>{PRODUCT_IDENTITY.name}</Text><Text style={styles.helpDetail}>{PRODUCT_IDENTITY.tagline}</Text><Text style={styles.workspaceLabel}>Workspace: {businessProfile.name}</Text></View></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 30 }, summary: { margin: 20, marginTop: 4, padding: 18, borderRadius: 22, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, gap: 17 }, summaryTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }, summaryLabel: { color: palette.muted, fontSize: 10, lineHeight: 14, letterSpacing: 0.8, fontWeight: "800" }, summaryValue: { color: palette.ink, fontSize: 29, lineHeight: 35, fontWeight: "800", letterSpacing: -0.7, marginTop: 3 }, summaryDetail: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "600" }, summaryLine: { paddingTop: 14, borderTopWidth: 1, borderTopColor: palette.fog, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, summaryLineLabel: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "600" }, summaryLineValue: { color: palette.coral, fontSize: 14, lineHeight: 18, fontWeight: "800" }, menu: { paddingHorizontal: 20, gap: 9 }, menuItem: { backgroundColor: palette.surface, borderRadius: 19, borderWidth: 1, borderColor: palette.fog, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 }, menuIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, menuCopy: { flex: 1, gap: 2 }, menuTitle: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "800" }, menuDetail: { color: palette.muted, fontSize: 11, lineHeight: 16, fontWeight: "600" }, helpCard: { margin: 20, marginTop: 25, borderRadius: 20, padding: 16, backgroundColor: "#E6F1FF", flexDirection: "row", alignItems: "center", gap: 12 }, helpMark: { width: 37, height: 37, borderRadius: 13, backgroundColor: palette.primary, alignItems: "center", justifyContent: "center" }, helpMarkText: { color: "#FFF", fontSize: 18, lineHeight: 23, fontWeight: "800" }, helpCopy: { flex: 1, gap: 2 }, helpTitle: { color: palette.primary, fontSize: 13, lineHeight: 18, fontWeight: "800" }, helpDetail: { color: "#645C7D", fontSize: 11, lineHeight: 16, fontWeight: "600" }, workspaceLabel: { color: palette.primary, fontSize: 10, lineHeight: 14, fontWeight: "800", marginTop: 3 },
});
