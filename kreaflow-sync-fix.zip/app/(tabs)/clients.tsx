import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, Pill, ScreenHeader, palette } from "@/components/business-ui";
import { clientRevenue, formatNaira } from "@/lib/business-metrics";

function initials(name: string): string { return name.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase(); }
function clientTone(status: string): "primary" | "coral" | "gold" | "moss" { return status === "Active" ? "moss" : status === "Lead" ? "gold" : status === "Completed" ? "primary" : "coral"; }
const TONE_TINTS: Record<"primary" | "coral" | "gold" | "moss", { bg: string; fg: string }> = {
  moss: { bg: "#E3F1EA", fg: palette.moss },
  gold: { bg: "#FCF3D6", fg: "#A8821A" },
  coral: { bg: "#FBE6E1", fg: palette.coral },
  primary: { bg: "#E6F1FF", fg: palette.primary },
};

export default function ClientsScreen() {
  const { clients, projects, transactions } = useBusiness();
  const [query, setQuery] = useState("");
  const clientList = useMemo(() => clients.filter((client) => `${client.name} ${client.business}`.toLowerCase().includes(query.toLowerCase())), [clients, query]);
  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
      <ScreenHeader eyebrow="Relationship desk" title="Clients" subtitle="See the people and businesses behind the work." onSearch={() => router.push("/search")} action={<TouchableOpacity activeOpacity={0.8} onPress={() => router.push("/create?type=client")} style={styles.addButton}><MaterialIcons name="person-add" color="#FFF" size={18} /></TouchableOpacity>} />
      <View style={styles.searchBox}><MaterialIcons name="search" size={20} color="#7A817C" /><TextInput value={query} onChangeText={setQuery} placeholder="Search clients or businesses" placeholderTextColor="#9AA09C" style={styles.searchInput} returnKeyType="done" /></View>
      <View style={styles.totals}><View><Text style={styles.totalLabel}>ACTIVE CLIENTS</Text><Text style={styles.totalValue}>{clients.filter((client) => client.status === "Active").length}</Text></View><View style={styles.totalDivider} /><View><Text style={styles.totalLabel}>CLIENT VALUE</Text><Text style={styles.totalValue}>{formatNaira(transactions.filter((item) => item.status === "received").reduce((sum, item) => sum + item.amount, 0))}</Text></View></View>
      <View style={styles.list}>
        {clientList.length ? clientList.map((client) => {
          const count = projects.filter((project) => project.clientId === client.id).length;
          const tint = TONE_TINTS[clientTone(client.status)];
          return <TouchableOpacity key={client.id} style={[styles.card, { borderLeftWidth: 4, borderLeftColor: tint.fg }]} activeOpacity={0.74} onPress={() => router.push({ pathname: "/client/[id]", params: { id: client.id } })}>
            <View style={[styles.avatar, { backgroundColor: tint.bg }]}><Text style={[styles.avatarText, { color: tint.fg }]}>{initials(client.name)}</Text></View><View style={styles.cardCopy}><View style={styles.nameRow}><Text style={styles.name}>{client.name}</Text><Pill label={client.status} tone={clientTone(client.status)} /></View><Text style={styles.business}>{client.business}</Text><View style={styles.metaRow}><Text style={styles.meta}>{count} {count === 1 ? "project" : "projects"}</Text><View style={styles.dot} /><Text style={styles.meta}>{formatNaira(clientRevenue(client.id, transactions))} received</Text></View><Text style={styles.activity}>{client.lastActivity}</Text></View><MaterialIcons name="chevron-right" size={22} color="#9AA09C" /></TouchableOpacity>;
        }) : <EmptyState title="No client matches" detail="Search by a different name, or start your next relationship here." actionLabel="New client" onAction={() => router.push("/create?type=client")} icon="groups-2" />}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 30 }, addButton: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: palette.primary, marginTop: 3 },
  searchBox: { flexDirection: "row", alignItems: "center", gap: 9, marginHorizontal: 20, paddingHorizontal: 13, height: 49, borderRadius: 15, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog }, searchInput: { flex: 1, color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "600" },
  totals: { margin: 17, marginHorizontal: 20, backgroundColor: "#E6F1FF", borderRadius: 18, padding: 16, flexDirection: "row", alignItems: "center", gap: 16 }, totalLabel: { color: palette.primary, fontSize: 10, lineHeight: 13, letterSpacing: 0.7, fontWeight: "800" }, totalValue: { color: palette.ink, fontSize: 21, lineHeight: 27, fontWeight: "800", marginTop: 3 }, totalDivider: { width: 1, height: 37, backgroundColor: "#D9D3EB" },
  list: { paddingHorizontal: 20, gap: 10 }, card: { backgroundColor: palette.surface, borderRadius: 20, borderWidth: 1, borderColor: palette.fog, padding: 14, flexDirection: "row", alignItems: "center", gap: 11 }, avatar: { width: 43, height: 43, borderRadius: 15, backgroundColor: "#E3F1EA", alignItems: "center", justifyContent: "center" }, avatarText: { color: palette.moss, fontSize: 13, lineHeight: 17, fontWeight: "800" }, cardCopy: { flex: 1, gap: 2 }, nameRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 6 }, name: { flex: 1, color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" }, business: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "600" }, metaRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 3, flexWrap: "wrap" }, meta: { color: palette.ink, fontSize: 11, lineHeight: 15, fontWeight: "700" }, dot: { width: 3, height: 3, borderRadius: 3, backgroundColor: "#A0A6A2" }, activity: { color: "#8B918D", fontSize: 10, lineHeight: 14, fontWeight: "600", marginTop: 2 },
});
