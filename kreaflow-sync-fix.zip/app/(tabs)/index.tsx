import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { ScrollView, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { MetricCard, Pill, ProgressBar, ScreenHeader, SectionHeading, WorkspaceSwitcher, palette } from "@/components/business-ui";
import { formatNaira, projectProgress, totalOutstanding, revenueThisMonth } from "@/lib/business-metrics";
import { dashboardMetricLayout } from "@/lib/dashboard-layout";
import { timeOfDayGreeting } from "@/lib/dates";

function statusTone(status: string): "primary" | "moss" | "gold" | "coral" { if (status === "Delivered" || status === "Approved") return "moss"; if (status === "Revision") return "coral"; if (status === "Review") return "gold"; return "primary"; }

export default function DashboardScreen() {
  const { clients, projects, leads, transactions, followUps, goals, account } = useBusiness();
  const { width } = useWindowDimensions();
  const metricWidth = dashboardMetricLayout(width).cellWidth;
  const activeProjects = projects.filter((project) => project.status !== "Delivered");
  const revenueGoal = goals.find((goal) => goal.category === "Revenue");
  const revenue = revenueThisMonth(transactions);
  const outstanding = totalOutstanding(projects, transactions);
  const goalPercent = revenueGoal && revenueGoal.target > 0 ? Math.min(100, Math.round((revenue / revenueGoal.target) * 100)) : 0;
  const focusItems = [
    ...followUps.filter((item) => !item.complete && item.date === "Today").map((item) => ({ label: "Follow-up", title: item.title, detail: item.projectId ? projects.find((project) => project.id === item.projectId)?.name ?? "Project context" : "Due today", icon: "call" as const })),
    ...activeProjects.flatMap((project) => project.tasks.filter((task) => !task.complete && task.dueDate === "Today").map((task) => ({ label: "Task due", title: task.title, detail: project.name, icon: "task-alt" as const }))),
  ].slice(0, 4);
  const activity = [
    ...transactions.slice(0, 3).map((item) => ({ label: item.status === "pending" ? "Payment pending" : "Payment received", detail: `${formatNaira(item.amount)} · ${item.note || "Payment recorded"}`, icon: item.status === "pending" ? "schedule" as const : "payments" as const })),
    ...projects.filter((project) => project.status === "Approved" || project.status === "Delivered").slice(0, 2).map((project) => ({ label: project.status === "Delivered" ? "Project delivered" : "Project approved", detail: project.name, icon: "check-circle" as const })),
  ].slice(0, 4);

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="KreaFlow · Business command center" title={`${timeOfDayGreeting()}, ${account.name?.split(" ")[0] ?? "there"}`} subtitle="Here’s what needs your attention and what is moving today." onSearch={() => router.push("/search")} onAlerts={() => router.push("/alerts")} />
    <View style={styles.workspaceWrap}><WorkspaceSwitcher /></View>
    <View style={styles.metricGrid}>
      <View style={[styles.metricCell, { width: metricWidth }]}><MetricCard label="Active projects" value={String(activeProjects.length)} detail="across your workflow" tone="primary" icon="folder-open" /></View>
      <View style={[styles.metricCell, { width: metricWidth }]}><MetricCard label="Outstanding" value={formatNaira(outstanding)} detail="to collect" tone="coral" icon="account-balance-wallet" /></View>
      <View style={[styles.metricCell, { width: metricWidth }]}><MetricCard label="Active clients" value={String(clients.filter((client) => client.status === "Active").length)} detail="relationships in motion" tone="moss" icon="groups-2" /></View>
      <View style={[styles.metricCell, { width: metricWidth }]}><MetricCard label="Qualified leads" value={String(leads.filter((lead) => !["Won", "Lost"].includes(lead.status)).length)} detail="in the pipeline" tone="gold" icon="waterfall-chart" /></View>
    </View>
    <View style={styles.section}><SectionHeading title="Business overview" actionLabel="Open money" onAction={() => router.push("/money")} /><View style={styles.revenueCard}><View><Text style={styles.revenueEyebrow}>REVENUE THIS MONTH</Text><Text style={styles.revenueValue}>{formatNaira(revenue)}</Text><Text style={styles.revenueDetail}>{formatNaira(outstanding)} remains outstanding</Text></View><View style={styles.goalBubble}><Text style={styles.goalBubbleLabel}>GOAL</Text><Text style={styles.goalBubbleValue}>{revenueGoal ? `${goalPercent}%` : "—"}</Text></View>{revenueGoal ? <ProgressBar value={goalPercent} tone="gold" height={9} /> : null}{revenueGoal ? <Text style={styles.revenueGoalText}>{formatNaira(revenue)} of {formatNaira(revenueGoal.target)} target</Text> : null}</View></View>
    <View style={styles.section}><SectionHeading title="Today’s focus" actionLabel="View all" onAction={() => router.push("/alerts")} />
      {focusItems.length ? focusItems.map((item, index) => <TouchableOpacity key={`${item.title}-${index}`} style={styles.focusCard} activeOpacity={0.72} onPress={() => router.push("/projects")}><View style={styles.focusIcon}><MaterialIcons name={item.icon} size={19} color={palette.primary} /></View><View style={styles.focusCopy}><Text style={styles.focusMeta}>{item.label} · Due today</Text><Text style={styles.focusTitle}>{item.title}</Text><Text style={styles.focusDetail}>{item.detail}</Text></View><MaterialIcons name="chevron-right" size={22} color="#9AA09C" /></TouchableOpacity>) : <Text style={styles.quietText}>Nothing urgent today. Use the space to create momentum.</Text>}
    </View>
    <View style={styles.section}><SectionHeading title="Active projects" actionLabel="View all projects" onAction={() => router.push("/projects")} /><View style={styles.workflowCard}>{activeProjects.slice(0, 3).map((project) => <TouchableOpacity key={project.id} style={styles.projectLine} activeOpacity={0.72} onPress={() => router.push({ pathname: "/project/[id]", params: { id: project.id } })}><View style={styles.projectLineTop}><Text style={styles.projectName} numberOfLines={1}>{project.name}</Text><Pill label={project.status} tone={statusTone(project.status)} /></View><View style={styles.progressRow}><ProgressBar value={projectProgress(project)} tone={statusTone(project.status)} height={7} /><Text style={styles.progressLabel}>{projectProgress(project)}%</Text></View></TouchableOpacity>)}</View></View>
    <View style={styles.section}><SectionHeading title="Recent activity" actionLabel="Open money" onAction={() => router.push("/money")} /><View style={styles.activityCard}>{activity.length ? activity.map((item, index) => <View key={`${item.label}-${index}`} style={styles.activityRow}><View style={styles.activityIcon}><MaterialIcons name={item.icon} size={17} color={palette.primary} /></View><View style={styles.activityCopy}><Text style={styles.activityTitle}>{item.label}</Text><Text style={styles.activityDetail}>{item.detail}</Text></View></View>) : <Text style={styles.quietText}>Recent business activity will appear here.</Text>}</View></View>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 30 }, workspaceWrap: { paddingHorizontal: 20, marginTop: -8 }, section: { marginTop: 25, paddingHorizontal: 20 }, metricGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 10, paddingHorizontal: 20, marginTop: 25 }, metricCell: { minWidth: 0 },
  focusCard: { backgroundColor: palette.surface, borderRadius: 18, padding: 14, marginBottom: 9, flexDirection: "row", alignItems: "center", gap: 12, borderWidth: 1, borderColor: palette.fog }, focusIcon: { width: 37, height: 37, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF" }, focusCopy: { flex: 1, gap: 2 }, focusMeta: { color: palette.coral, fontSize: 10, lineHeight: 14, fontWeight: "800", letterSpacing: .35, textTransform: "uppercase" }, focusTitle: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" }, focusDetail: { color: palette.muted, fontSize: 12, lineHeight: 17, fontWeight: "600" }, quietText: { color: palette.muted, fontSize: 13, lineHeight: 19, paddingVertical: 5 },
  revenueCard: { backgroundColor: palette.primary, borderRadius: 22, padding: 18, gap: 13 }, revenueEyebrow: { color: "#DCEBFF", fontSize: 10, lineHeight: 14, fontWeight: "800", letterSpacing: 1.1 }, revenueValue: { color: "#FFFFFF", fontSize: 31, lineHeight: 37, fontWeight: "800", letterSpacing: -1 }, revenueDetail: { color: "#DCEBFF", fontSize: 12, lineHeight: 17, fontWeight: "600" }, goalBubble: { position: "absolute", right: 18, top: 17, width: 56, height: 56, borderRadius: 18, backgroundColor: "#044BB2", alignItems: "center", justifyContent: "center" }, goalBubbleLabel: { color: "#DCEBFF", fontSize: 8, lineHeight: 11, fontWeight: "800", letterSpacing: .5 }, goalBubbleValue: { color: "#FFFFFF", fontSize: 18, lineHeight: 22, fontWeight: "800" }, revenueGoalText: { color: "#DCEBFF", fontSize: 11, lineHeight: 15, fontWeight: "700" },
  workflowCard: { backgroundColor: palette.surface, borderRadius: 20, borderWidth: 1, borderColor: palette.fog, paddingHorizontal: 14 }, projectLine: { paddingVertical: 14, gap: 9, borderBottomWidth: 1, borderBottomColor: palette.fog }, projectLineTop: { flexDirection: "row", justifyContent: "space-between", gap: 12, alignItems: "center" }, projectName: { flex: 1, color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" }, progressRow: { flexDirection: "row", alignItems: "center", gap: 10 }, progressLabel: { color: palette.muted, fontSize: 11, lineHeight: 14, fontWeight: "800", width: 28, textAlign: "right" },
  activityCard: { backgroundColor: palette.surface, borderRadius: 20, borderWidth: 1, borderColor: palette.fog, overflow: "hidden" }, activityRow: { minHeight: 58, paddingHorizontal: 13, paddingVertical: 10, flexDirection: "row", gap: 10, alignItems: "center", borderBottomWidth: 1, borderBottomColor: palette.fog }, activityIcon: { width: 32, height: 32, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF" }, activityCopy: { flex: 1, gap: 1 }, activityTitle: { color: palette.ink, fontSize: 12, lineHeight: 17, fontWeight: "800" }, activityDetail: { color: palette.muted, fontSize: 10, lineHeight: 14, fontWeight: "600" },
});
