import { router, useLocalSearchParams } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, View } from "react-native";

import { today, useBusiness } from "@/components/business-provider";
import { addDays } from "@/lib/dates";
import { PrimaryButton, ScreenHeader, palette } from "@/components/business-ui";
import { ChoicePills, DateField, FormField, FormSection } from "@/components/form-ui";
import type { ClientStatus, Goal, LeadStage, ProjectStage, TransactionStatus } from "@/lib/business-types";

type FormType = "client" | "project" | "lead" | "payment" | "followup" | "goal" | "deliverable";
const parseAmount = (value: string) => Number(String(value).replace(/[^0-9.]/g, "")) || 0;
const titles: Record<FormType, string> = { client: "New client", project: "New project", lead: "New lead", payment: "Record payment", followup: "Add follow-up", goal: "New goal", deliverable: "Add deliverable" };

export default function CreateScreen() {
  const params = useLocalSearchParams<{ type?: string; clientId?: string; projectId?: string; editId?: string }>();
  const formType = (params.type && ["client", "project", "lead", "payment", "followup", "goal", "deliverable"].includes(params.type) ? params.type : "client") as FormType;
  const { clients, projects, goals, addClient, addProject, addLead, addTransaction, addFollowUp, addGoal, addDeliverable, updateClient, updateProject } = useBusiness();
  const editingClient = params.editId ? clients.find((client) => client.id === params.editId) : undefined;
  const editingProject = params.editId ? projects.find((project) => project.id === params.editId) : undefined;
  const [clientName, setClientName] = useState(editingClient?.name ?? "");
  const [business, setBusiness] = useState(editingClient?.business ?? "");
  const [phone, setPhone] = useState(editingClient?.phone ?? "");
  const [email, setEmail] = useState(editingClient?.email ?? "");
  const [handle, setHandle] = useState(editingClient?.handle ?? "");
  const [notes, setNotes] = useState(editingClient?.notes ?? editingProject?.notes ?? "");
  const [clientId, setClientId] = useState(editingProject?.clientId ?? params.clientId ?? clients[0]?.id ?? "");
  const [projectId, setProjectId] = useState(params.projectId ?? projects[0]?.id ?? "");
  const [projectName, setProjectName] = useState(editingProject?.name ?? "");
  const [service, setService] = useState(editingProject?.service ?? "");
  const [price, setPrice] = useState(editingProject ? String(editingProject.price) : "");
  const [deadline, setDeadline] = useState(() => editingProject?.deadline ?? addDays(14));
  const [status, setStatus] = useState<ProjectStage>(editingProject?.status ?? "Brief");
  const [revisions, setRevisions] = useState(editingProject ? String(editingProject.revisionsIncluded) : "2");
  const [leadStatus, setLeadStatus] = useState<LeadStage>("New Lead");
  const [source, setSource] = useState("Instagram referral");
  const [followUp, setFollowUp] = useState("Tomorrow");
  const [method, setMethod] = useState("Bank transfer");
  const [transactionStatus, setTransactionStatus] = useState<TransactionStatus>("received");
  const [goalLevel, setGoalLevel] = useState<"Vision (year)" | "This month" | "One-off">("This month");
  const [goalCategory, setGoalCategory] = useState<Goal["category"]>("Revenue");
  const [target, setTarget] = useState("");
  const [current, setCurrent] = useState("0");
  const selectedClient = useMemo(() => clients.find((client) => client.id === clientId), [clients, clientId]);
  const selectedProject = useMemo(() => projects.find((project) => project.id === projectId), [projects, projectId]);

  const validate = (values: string[]) => values.every((value) => value.trim().length > 0);
  const save = () => {
    if (formType === "client") {
      if (!validate([clientName, business])) return Alert.alert("Add a name and business", "Both are needed to create a useful client record.");
      if (editingClient) {
        updateClient(editingClient.id, { name: clientName, business, phone, email, handle, notes });
        return router.replace({ pathname: "/client/[id]", params: { id: editingClient.id } });
      }
      const id = addClient({ name: clientName, business, phone, email, handle, notes, status: "Active" as ClientStatus });
      return router.replace({ pathname: "/client/[id]", params: { id } });
    }
    if (formType === "project") {
      if (!validate([projectName, clientId, service, price, deadline])) return Alert.alert("Finish the project details", "Name, client, service, price, and deadline are required.");
      const projectPrice = parseAmount(price);
      if (editingProject) {
        updateProject(editingProject.id, { name: projectName, clientId, service, description: notes, price: projectPrice, deadline, status, revisionsIncluded: parseAmount(revisions), notes });
        return router.replace({ pathname: "/project/[id]", params: { id: editingProject.id } });
      }
      const id = addProject({ name: projectName, clientId, service, description: notes, price: projectPrice, startDate: today(), deadline, status, revisionsIncluded: parseAmount(revisions), notes, deliverables: [], tasks: [] });
      // Starting a project should hand you a ready-to-send invoice immediately,
      // not just a project card — so open one automatically, unpaid, for the full price.
      const invoiceId = addTransaction({ clientId, projectId: id, amount: projectPrice, date: today(), method: "", status: "pending", note: "Invoice issued when project started" });
      return router.replace({ pathname: "/invoice/[id]", params: { id: invoiceId } });
    }
    if (formType === "lead") {
      if (!validate([clientName, business, service, price])) return Alert.alert("Finish the lead details", "Name, business, service, and estimated value are required.");
      const id = addLead({ name: clientName, business, contact: email || phone, service, value: parseAmount(price), source, dateContacted: today(), nextFollowUp: followUp, notes, status: leadStatus });
      return router.replace({ pathname: "/lead/[id]", params: { id } });
    }
    if (formType === "payment") {
      if (!validate([projectId, price])) return Alert.alert("Add payment details", "Choose a project and enter an amount.");
      addTransaction({ clientId: selectedProject?.clientId ?? clientId, projectId, amount: parseAmount(price), date: today(), method, status: transactionStatus, note: notes || "Payment recorded" });
      return router.replace("/money");
    }
    if (formType === "followup") {
      if (!validate([projectName, followUp])) return Alert.alert("Add a task and date", "A follow-up needs a clear action and due date.");
      addFollowUp({ title: projectName, date: followUp, clientId: clientId || undefined, projectId: projectId || undefined });
      return router.back();
    }
    if (formType === "deliverable") {
      if (!validate([projectId, projectName])) return Alert.alert("Add a deliverable", "Choose the project and name the output to create it.");
      addDeliverable(projectId, projectName);
      return router.back();
    }
    if (!validate([projectName, target, deadline])) return Alert.alert("Finish the goal details", "Give the goal a name, target, and deadline.");
    const level = goalLevel === "Vision (year)" ? "year" : goalLevel === "This month" ? "month" : "custom";
    const parentId = level === "month" ? goals.find((goal) => goal.level === "year")?.id : undefined;
    addGoal({ name: projectName, target: parseAmount(target), current: parseAmount(current), deadline, category: goalCategory, level, parentId, steps: [] });
    return router.replace("/goals");
  };

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Quick action" title={editingClient ? "Edit client" : editingProject ? "Edit project" : titles[formType]} subtitle={editingClient || editingProject ? "Update the details below, then save your changes." : "Add the details that keep your business command center accurate."} onBack={() => router.back()} />
    <View style={styles.form}>
      {formType === "client" ? <><FormSection title="Client identity"><FormField label="Client name" value={clientName} onChangeText={setClientName} placeholder="e.g. Amara Okafor" /><FormField label="Business name" value={business} onChangeText={setBusiness} placeholder="e.g. Studio Noma" /><FormField label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="+234" /><FormField label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="hello@business.com" /><FormField label="Social handle" value={handle} onChangeText={setHandle} placeholder="@business" /></FormSection><FormSection title="Context"><FormField label="Notes" value={notes} onChangeText={setNotes} placeholder="Preferences, context, or relationship notes" multiline /></FormSection></> : null}
      {formType === "project" ? <><FormSection title="Project essentials"><FormField label="Project name" value={projectName} onChangeText={setProjectName} placeholder="e.g. New menu launch" /><Text style={styles.pickerLabel}>CLIENT</Text><ChoicePills options={clients.map((client) => client.business)} value={selectedClient?.business ?? ""} onChange={(businessName) => setClientId(clients.find((client) => client.business === businessName)?.id ?? "")} /><FormField label="Service" value={service} onChangeText={setService} placeholder="e.g. Social campaign design" /><FormField label="Price (₦)" value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="85000" /><DateField label="Deadline" value={deadline} onChange={setDeadline} /></FormSection><FormSection title="Workflow"><Text style={styles.pickerLabel}>STARTING STAGE</Text><ChoicePills options={["Brief", "Designing", "Review", "Revision", "Approved", "Delivered"]} value={status} onChange={(item) => setStatus(item as ProjectStage)} /><FormField label="Revisions included" value={revisions} onChangeText={setRevisions} keyboardType="numeric" placeholder="2" /><FormField label="Project notes" value={notes} onChangeText={setNotes} placeholder="Creative direction or internal notes" multiline /></FormSection></> : null}
      {formType === "lead" ? <><FormSection title="Lead identity"><FormField label="Contact name" value={clientName} onChangeText={setClientName} placeholder="e.g. Dami Adepoju" /><FormField label="Business name" value={business} onChangeText={setBusiness} placeholder="e.g. Kola Home" /><FormField label="Email or phone" value={email} onChangeText={setEmail} placeholder="how to reach them" /></FormSection><FormSection title="Opportunity"><FormField label="Service interested in" value={service} onChangeText={setService} placeholder="e.g. Product launch design" /><FormField label="Estimated value (₦)" value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="150000" /><FormField label="Lead source" value={source} onChangeText={setSource} placeholder="Instagram referral" /><Text style={styles.pickerLabel}>PIPELINE STAGE</Text><ChoicePills options={["New Lead", "Contacted", "Proposal", "Negotiation"]} value={leadStatus} onChange={(item) => setLeadStatus(item as LeadStage)} /><FormField label="Next follow-up" value={followUp} onChangeText={setFollowUp} placeholder="Tomorrow" /><FormField label="Notes" value={notes} onChangeText={setNotes} placeholder="What they need and what matters" multiline /></FormSection></> : null}
      {formType === "payment" ? <><FormSection title="Payment details"><Text style={styles.pickerLabel}>PROJECT</Text><ChoicePills options={projects.map((project) => project.name)} value={selectedProject?.name ?? ""} onChange={(name) => { const project = projects.find((item) => item.name === name); setProjectId(project?.id ?? ""); setClientId(project?.clientId ?? ""); }} /><FormField label="Amount (₦)" value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="20000" /><Text style={styles.pickerLabel}>PAYMENT METHOD</Text><ChoicePills options={["Bank transfer", "Card transfer", "Cash"]} value={method} onChange={setMethod} /><Text style={styles.pickerLabel}>STATUS</Text><ChoicePills options={["received", "pending", "refund", "income"]} value={transactionStatus} onChange={(item) => setTransactionStatus(item as TransactionStatus)} /><FormField label="Note" value={notes} onChangeText={setNotes} placeholder="e.g. 50% deposit" /></FormSection></> : null}
      {formType === "followup" ? <><FormSection title="Follow-up details"><FormField label="Action" value={projectName} onChangeText={setProjectName} placeholder="e.g. Follow up on proposal" /><Text style={styles.pickerLabel}>CLIENT (OPTIONAL)</Text><ChoicePills options={["No client", ...clients.map((client) => client.business)]} value={selectedClient?.business ?? "No client"} onChange={(businessName) => setClientId(businessName === "No client" ? "" : clients.find((client) => client.business === businessName)?.id ?? "")} /><FormField label="When" value={followUp} onChangeText={setFollowUp} placeholder="Today, Tomorrow, or a date" /></FormSection></> : null}
      {formType === "deliverable" ? <FormSection title="Deliverable details"><Text style={styles.pickerLabel}>PROJECT</Text><ChoicePills options={projects.map((project) => project.name)} value={selectedProject?.name ?? ""} onChange={(name) => setProjectId(projects.find((project) => project.name === name)?.id ?? "")} /><FormField label="Deliverable name" value={projectName} onChangeText={setProjectName} placeholder="e.g. Final export pack" /></FormSection> : null}
      {formType === "goal" ? <><FormSection title="Goal setup"><Text style={styles.pickerLabel}>GOAL TYPE</Text><ChoicePills options={["Vision (year)", "This month", "One-off"]} value={goalLevel} onChange={(item) => setGoalLevel(item as typeof goalLevel)} /><FormField label="Goal name" value={projectName} onChangeText={setProjectName} placeholder={goalLevel === "Vision (year)" ? "e.g. Build a studio friends recommend" : "e.g. New retained clients"} /><Text style={styles.pickerLabel}>CATEGORY</Text><ChoicePills options={["Revenue", "Clients", "Projects", "Content", "Portfolio"]} value={goalCategory} onChange={(item) => setGoalCategory(item as Goal["category"])} /><FormField label="Target" value={target} onChangeText={setTarget} keyboardType="numeric" placeholder={goalCategory === "Revenue" ? "150000" : "3"} /><FormField label="Current progress" value={current} onChangeText={setCurrent} keyboardType="numeric" placeholder="0" /><DateField label="Deadline" value={deadline} onChange={setDeadline} /></FormSection></> : null}
      <PrimaryButton label={editingClient || editingProject ? "Save changes" : `Save ${titles[formType].toLowerCase()}`} icon="check" onPress={save} />
    </View>
  </ScrollView>;
}

const styles = StyleSheet.create({ page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 34 }, form: { paddingHorizontal: 20, gap: 14 }, pickerLabel: { color: palette.muted, fontSize: 11, lineHeight: 14, letterSpacing: 0.4, fontWeight: "800", textTransform: "uppercase", marginBottom: -6 }, });
