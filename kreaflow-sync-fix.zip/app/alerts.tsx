import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, ScreenHeader, palette } from "@/components/business-ui";
import { clientName, formatNaira, projectBalance } from "@/lib/business-metrics";
import { daysUntil, formatDateFriendly, today } from "@/lib/dates";

export default function AlertsScreen() {
  const { followUps, projects, clients, transactions, goals } = useBusiness();
  const pendingFollowUps = followUps.filter((item) => !item.complete);
  const overdue = projects.filter((project) => project.deadline < today() && project.status !== "Delivered");
  const unpaid = projects.filter((project) => projectBalance(project, transactions) > 0);
  const alerts = [
    ...pendingFollowUps.map((item) => ({ id: item.id, kind: "Follow-up", title: item.title, detail: `${item.date} · keep the conversation moving`, icon: "event-note" as const, tone: "primary" })),
    ...overdue.map((project) => ({ id: project.id, kind: "Project deadline", title: `${project.name} is overdue`, detail: `${clientName(project.clientId, clients)} · deadline ${formatDateFriendly(project.deadline)}`, icon: "alarm" as const, tone: "coral" })),
    ...unpaid.map((project) => ({ id: `pay-${project.id}`, kind: "Payment", title: `${formatNaira(projectBalance(project, transactions))} outstanding`, detail: `${project.name} · ${clientName(project.clientId, clients)}`, icon: "payments" as const, tone: "gold" })),
    ...goals.filter((goal) => goal.current < goal.target && daysUntil(goal.deadline) !== null && (daysUntil(goal.deadline) as number) <= 7).map((goal) => ({ id: `goal-${goal.id}`, kind: "Goal", title: `${goal.name} needs attention`, detail: `${goal.current} of ${goal.target} · due ${formatDateFriendly(goal.deadline)}`, icon: "flag" as const, tone: "moss" })),
  ];
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Business alerts" title="Stay ahead" subtitle="A focused list of the work, money, and conversations that need attention." onBack={() => router.back()} />
    <View style={styles.countCard}><Text style={styles.count}>{alerts.length}</Text><Text style={styles.countCopy}>active business reminders</Text></View>
    <View style={styles.list}>{alerts.length ? alerts.map((item) => <TouchableOpacity key={item.id} style={styles.alert} activeOpacity={0.74} onPress={() => router.push("/projects")}><View style={[styles.icon, item.tone === "coral" ? { backgroundColor: "#FDE9E4" } : item.tone === "gold" ? { backgroundColor: "#FBF1DB" } : item.tone === "moss" ? { backgroundColor: "#E3F1EA" } : { backgroundColor: "#E6F1FF" }]}><MaterialIcons name={item.icon} size={20} color={item.tone === "coral" ? palette.coral : item.tone === "gold" ? palette.gold : item.tone === "moss" ? palette.moss : palette.primary} /></View><View style={styles.copy}><Text style={styles.kind}>{item.kind}</Text><Text style={styles.title}>{item.title}</Text><Text style={styles.detail}>{item.detail}</Text></View><MaterialIcons name="chevron-right" size={22} color="#9AA09C" /></TouchableOpacity>) : <EmptyState title="You’re all caught up" detail="No deadlines, follow-ups, balances, or goals need attention right now." icon="check-circle" />}</View>
  </ScrollView>;
}

const styles = StyleSheet.create({ page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 32 }, countCard: { marginHorizontal: 20, marginTop: 3, padding: 17, borderRadius: 20, backgroundColor: palette.ink, flexDirection: "row", alignItems: "center", gap: 10 }, count: { color: "#FFF", fontSize: 27, lineHeight: 33, fontWeight: "800" }, countCopy: { color: "#C5CEC8", fontSize: 12, lineHeight: 17, fontWeight: "700" }, list: { paddingHorizontal: 20, paddingTop: 18, gap: 9 }, alert: { padding: 14, borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, flexDirection: "row", alignItems: "center", gap: 11 }, icon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center" }, copy: { flex: 1, gap: 2 }, kind: { color: palette.muted, fontSize: 9, lineHeight: 12, letterSpacing: 0.6, fontWeight: "800", textTransform: "uppercase" }, title: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "800" }, detail: { color: palette.muted, fontSize: 10, lineHeight: 14, fontWeight: "600" }, });
