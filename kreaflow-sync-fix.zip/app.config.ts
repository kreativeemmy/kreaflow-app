import type { ExpoConfig } from "expo/config";

// Permanent identity of the app. Do not change after the first APK is shared:
// friends can only update the app if the package name and signing key stay the same.
const PACKAGE_NAME = "com.kreativeemmy.kreaflow";
const SCHEME = "kreaflow";

const config: ExpoConfig = {
  name: "KreaFlow",
  slug: "kreaflow",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/images/icon.png",
  scheme: SCHEME,
  userInterfaceStyle: "light",
  newArchEnabled: true,
  owner: "kreative_emmy",
  ios: {
    supportsTablet: true,
    bundleIdentifier: PACKAGE_NAME,
    infoPlist: { ITSAppUsesNonExemptEncryption: false },
  },
  android: {
    package: PACKAGE_NAME,
    adaptiveIcon: {
      backgroundColor: "#0562E9",
      foregroundImage: "./assets/images/android-icon-foreground.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
    },
    edgeToEdgeEnabled: true,
    predictiveBackGestureEnabled: false,
    permissions: ["POST_NOTIFICATIONS"],
  },
  web: {
    bundler: "metro",
    output: "single",
    favicon: "./assets/images/favicon.png",
  },
  plugins: [
    "expo-router",
    ["expo-notifications", { color: "#0562E9", defaultChannel: "business-reminders", enableBackgroundRemoteNotifications: false }],
    ["expo-splash-screen", { image: "./assets/images/splash-icon.png", imageWidth: 200, resizeMode: "contain", backgroundColor: "#F4F8FD" }],
    ["expo-build-properties", { android: { buildArchs: ["armeabi-v7a", "arm64-v8a"], minSdkVersion: 24 } }],
  ],
  experiments: { typedRoutes: false, reactCompiler: true },
  extra: {
    eas: {
      projectId: "75908e65-b91d-4b34-8f66-89859fd8e3ea",
    },
  },
};

export default config;
