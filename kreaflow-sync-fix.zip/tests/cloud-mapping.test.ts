import { describe, expect, it } from "vitest";
import { assembleWorkspaces, workspaceToRows, num, str, countRecords } from "../lib/cloud-mapping";
import { DEFAULT_BUSINESS_PROFILE, DEFAULT_INVOICE_DESIGN, type Workspace } from "../lib/business-types";

function sampleWorkspace(): Workspace {
  return {
    id: "11111111-1111-1111-1111-111111111111",
    name: "Kreativeemmy",
    createdAt: "2026-09-01T00:00:00.000Z",
    onboardingComplete: true,
    data: {
      businessProfile: { ...DEFAULT_BUSINESS_PROFILE, name: "Kreativeemmy" },
      invoiceDesign: { ...DEFAULT_INVOICE_DESIGN },
      clients: [{ id: "c1", name: "Dani Daniels", business: "Kola Home", phone: "+234", email: "d@x.com", handle: "@dani", notes: "", status: "Active", lastActivity: "Payment recorded today" }],
      projects: [{
        id: "p1", name: "CTY", clientId: "c1", service: "Brand", description: "", price: 80000, startDate: "2026-08-01",
        deadline: "2026-08-30", status: "Brief", revisionsIncluded: 2, revisionsUsed: 0, notes: "",
        deliverables: [{ id: "d1", title: "Moodboard", complete: true }, { id: "d2", title: "Logo", complete: false }],
        tasks: [{ id: "pt1", title: "Send draft", dueDate: "Tomorrow", complete: false }],
      }],
      leads: [{ id: "l1", name: "Sam", business: "Nova", contact: "sam@x.com", service: "Flyer", value: 15000, source: "Instagram", dateContacted: "2026-08-10", nextFollowUp: "Converted", notes: "", status: "Won", lostReason: undefined }],
      transactions: [{ id: "t1", clientId: "c1", projectId: "p1", amount: 20000, date: "2026-09-01", method: "Bank", status: "received", note: "Deposit", invoiceSnapshot: { businessProfile: { ...DEFAULT_BUSINESS_PROFILE }, design: { ...DEFAULT_INVOICE_DESIGN }, lineItems: [{ description: "Brand", detail: "CTY", quantity: 1, rate: 80000, amount: 80000 }] } }],
      followUps: [{ id: "f1", title: "Check in", date: "22 Aug", clientId: "c1", projectId: "p1", complete: false }],
      goals: [
        { id: "g1", name: "Monthly revenue", target: 100000, current: 20000, deadline: "2026-09-30", category: "Revenue", level: "month", parentId: "gY", steps: [
          { id: "gs1", title: "Post 3x a week", done: true },
          { id: "gs2", title: "Land one referral", done: false },
        ] },
      ],
    },
  };
}

describe("num / str coercion", () => {
  it("coerces Postgres numeric strings safely", () => {
    expect(num("80000.00")).toBe(80000);
    expect(num(null)).toBe(0);
    expect(num(undefined)).toBe(0);
    expect(num("not-a-number")).toBe(0);
  });
  it("never returns null/undefined for text fields", () => {
    expect(str(null)).toBe("");
    expect(str(undefined)).toBe("");
    expect(str("x")).toBe("x");
  });
});

describe("workspace -> rows -> workspace round trip", () => {
  const original = sampleWorkspace();
  const rows = workspaceToRows(original);
  const [rebuilt] = assembleWorkspaces(rows);

  it("produces exactly one row per record, addressed to the right tables", () => {
    expect(rows.workspaces).toHaveLength(1);
    expect(rows.clients).toHaveLength(1);
    expect(rows.projects).toHaveLength(1);
    expect(rows.deliverables).toHaveLength(2);
    // one project task + one follow-up, both land in the shared "tasks" table
    expect(rows.tasks).toHaveLength(2);
    expect(rows.tasks.filter((r) => r.kind === "task")).toHaveLength(1);
    expect(rows.tasks.filter((r) => r.kind === "follow_up")).toHaveLength(1);
    expect(rows.leads).toHaveLength(1);
    expect(rows.payments).toHaveLength(1);
    expect(rows.goals).toHaveLength(1);
  });

  it("every row carries the workspace_id (what Row Level Security keys off)", () => {
    for (const table of [rows.clients, rows.projects, rows.deliverables, rows.tasks, rows.leads, rows.payments, rows.goals]) {
      for (const row of table) expect(row.workspace_id).toBe(original.id);
    }
  });

  it("reassembles into a workspace identical to the original", () => {
    expect(rebuilt).toEqual(original);
  });

  it("keeps a lead's non-date next-follow-up text intact (e.g. 'Converted')", () => {
    expect(rebuilt.data.leads[0].nextFollowUp).toBe("Converted");
  });

  it("keeps a project task's loose due-date text intact (e.g. 'Tomorrow')", () => {
    expect(rebuilt.data.projects[0].tasks[0].dueDate).toBe("Tomorrow");
  });

  it("splits project tasks from follow-ups back out correctly despite sharing one table", () => {
    expect(rebuilt.data.projects[0].tasks).toHaveLength(1);
    expect(rebuilt.data.followUps).toHaveLength(1);
    expect(rebuilt.data.followUps[0].title).toBe("Check in");
  });

  it("keeps deliverable order and completion state", () => {
    expect(rebuilt.data.projects[0].deliverables.map((d) => d.title)).toEqual(["Moodboard", "Logo"]);
    expect(rebuilt.data.projects[0].deliverables[0].complete).toBe(true);
    expect(rebuilt.data.projects[0].deliverables[1].complete).toBe(false);
  });

  it("carries the invoice snapshot through payments untouched", () => {
    expect(rebuilt.data.transactions[0].invoiceSnapshot?.lineItems[0].amount).toBe(80000);
  });

  it("keeps a goal's level, parent link, and step completion intact", () => {
    expect(rebuilt.data.goals[0].level).toBe("month");
    expect(rebuilt.data.goals[0].parentId).toBe("gY");
    expect(rebuilt.data.goals[0].steps).toEqual([
      { id: "gs1", title: "Post 3x a week", done: true },
      { id: "gs2", title: "Land one referral", done: false },
    ]);
  });
});

describe("assembleWorkspaces handles what Postgres actually returns", () => {
  it("coerces numeric-as-string columns from Postgres (price, amount, value, target/current)", () => {
    const [ws] = assembleWorkspaces({
      workspaces: [{ id: "w1", name: "W", created_at: "2026-01-01", onboarding_complete: true, business_profile: {}, invoice_design: {} }],
      clients: [],
      leads: [{ id: "l1", workspace_id: "w1", name: "L", business: "", contact: "", service: "", value: "15000.00", source: "", date_contacted: null, next_follow_up: "", notes: "", status: "New Lead", lost_reason: null }],
      projects: [{ id: "p1", workspace_id: "w1", client_id: null, name: "P", service: "", description: "", price: "80000.00", start_date: null, deadline: null, status: "Brief", revisions_included: "2", revisions_used: "0", notes: "" }],
      deliverables: [],
      tasks: [],
      payments: [{ id: "t1", workspace_id: "w1", client_id: null, project_id: null, amount: "20000.50", status: "received", paid_on: "2026-01-01", method: "", note: "", invoice_snapshot: null }],
      goals: [{ id: "g1", workspace_id: "w1", title: "G", target_value: "100000", current_value: "20000", deadline: null, category: null, level: "month", parent_id: null }],
      goalSteps: [],
    });
    expect(ws.data.leads[0].value).toBe(15000);
    expect(ws.data.projects[0].price).toBe(80000);
    expect(ws.data.projects[0].revisionsIncluded).toBe(2);
    expect(ws.data.transactions[0].amount).toBe(20000.5);
    expect(ws.data.goals[0].target).toBe(100000);
    expect(ws.data.goals[0].current).toBe(20000);
  });

  it("defaults a null goal category to Revenue instead of crashing", () => {
    const [ws] = assembleWorkspaces({
      workspaces: [{ id: "w1", name: "W", created_at: "2026-01-01", onboarding_complete: true, business_profile: {}, invoice_design: {} }],
      clients: [], leads: [], projects: [], deliverables: [], tasks: [], payments: [],
      goals: [{ id: "g1", workspace_id: "w1", title: "G", target_value: "1", current_value: "0", deadline: null, category: null, level: "custom", parent_id: null }],
      goalSteps: [],
    });
    expect(ws.data.goals[0].category).toBe("Revenue");
  });

  it("returns nothing for a person with no cloud workspaces yet, instead of throwing", () => {
    const result = assembleWorkspaces({ workspaces: [], clients: [], leads: [], projects: [], deliverables: [], tasks: [], payments: [], goals: [], goalSteps: [] });
    expect(result).toEqual([]);
  });

  it("keeps two workspaces' data from leaking into each other", () => {
    const result = assembleWorkspaces({
      workspaces: [
        { id: "w1", name: "A", created_at: "2026-01-01", onboarding_complete: true, business_profile: {}, invoice_design: {} },
        { id: "w2", name: "B", created_at: "2026-01-01", onboarding_complete: true, business_profile: {}, invoice_design: {} },
      ],
      clients: [
        { id: "c1", workspace_id: "w1", name: "Client A", business: "", phone: "", email: "", handle: "", notes: "", status: "Active", last_activity: "" },
        { id: "c2", workspace_id: "w2", name: "Client B", business: "", phone: "", email: "", handle: "", notes: "", status: "Active", last_activity: "" },
      ],
      leads: [], projects: [], deliverables: [], tasks: [], payments: [], goals: [], goalSteps: [],
    });
    expect(result.find((w) => w.id === "w1")?.data.clients.map((c) => c.name)).toEqual(["Client A"]);
    expect(result.find((w) => w.id === "w2")?.data.clients.map((c) => c.name)).toEqual(["Client B"]);
  });
});

describe("countRecords — the signal used to decide if the cloud copy is behind", () => {
  it("counts every kind of record, including nested ones", () => {
    const workspace = sampleWorkspace();
    // 1 client + 1 project + 1 lead + 1 transaction + 1 followUp + 1 goal
    // + 2 deliverables + 1 project task + 2 goal steps = 11
    expect(countRecords(workspace.data)).toBe(11);
  });

  it("is 0 for a brand-new, empty workspace", () => {
    expect(countRecords({ ...sampleWorkspace().data, clients: [], projects: [], leads: [], transactions: [], followUps: [], goals: [] })).toBe(0);
  });

  it("catches an interrupted migration: local with real entries outcounts an empty cloud shell", () => {
    const local = sampleWorkspace();
    const emptyCloudShell = { ...local, data: { ...local.data, clients: [], projects: [], leads: [], transactions: [], followUps: [], goals: [] } };
    expect(countRecords(local.data)).toBeGreaterThan(countRecords(emptyCloudShell.data));
  });
});
