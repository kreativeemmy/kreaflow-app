import { describe, expect, it } from "vitest";
import { addDays, daysUntil, formatDateFriendly, isoToDate, timeOfDayGreeting, today } from "../lib/dates";
import { monthlyRevenueSeries, revenueThisMonth } from "../lib/business-metrics";
import type { Transaction } from "../lib/business-types";

describe("today / addDays — must reflect the real device date, never a fixed one", () => {
  it("today() matches the actual current date", () => {
    expect(today()).toBe(new Date().toISOString().slice(0, 10));
  });

  it("addDays(0) is today, addDays(14) is two weeks out", () => {
    expect(addDays(0)).toBe(today());
    const in14 = isoToDate(addDays(14));
    const now = isoToDate(today());
    expect(Math.round((in14.getTime() - now.getTime()) / 86_400_000)).toBe(14);
  });

  it("addDays can offset from a given date, not just today", () => {
    expect(addDays(1, "2026-08-30")).toBe("2026-08-31");
    expect(addDays(1, "2026-08-31")).toBe("2026-09-01"); // crosses a month boundary correctly
  });
});

describe("formatDateFriendly", () => {
  it("formats a real ISO date using its actual month, not a fixed one", () => {
    expect(formatDateFriendly("2026-09-05")).toBe("5 Sep 2026");
    expect(formatDateFriendly("2026-12-25")).toBe("25 Dec 2026");
    expect(formatDateFriendly("2026-01-01")).toBe("1 Jan 2026");
  });

  it("leaves loose, non-ISO text (like a follow-up's 'Tomorrow') untouched", () => {
    expect(formatDateFriendly("Tomorrow")).toBe("Tomorrow");
    expect(formatDateFriendly("Converted")).toBe("Converted");
  });
});

describe("daysUntil", () => {
  it("is 0 for today, negative for the past, positive for the future", () => {
    expect(daysUntil(today())).toBe(0);
    expect(daysUntil(addDays(-3))).toBe(-3);
    expect(daysUntil(addDays(5))).toBe(5);
  });
});

describe("timeOfDayGreeting — the fix for the frozen 'Good morning'", () => {
  it("greets appropriately across the day", () => {
    expect(timeOfDayGreeting(8)).toBe("Good morning");
    expect(timeOfDayGreeting(11)).toBe("Good morning");
    expect(timeOfDayGreeting(12)).toBe("Good afternoon");
    expect(timeOfDayGreeting(16)).toBe("Good afternoon");
    expect(timeOfDayGreeting(17)).toBe("Good evening");
    expect(timeOfDayGreeting(23)).toBe("Good evening");
  });
});

function tx(date: string, amount: number, status: Transaction["status"] = "received"): Transaction {
  return { id: date + amount, amount, date, method: "Bank", status, note: "" };
}

describe("revenueThisMonth — must reset every month, not accumulate forever", () => {
  it("only counts the current calendar month", () => {
    const now = new Date(2026, 8, 15); // 15 Sep 2026
    const transactions = [tx("2026-08-20", 50000), tx("2026-09-01", 30000), tx("2026-09-10", 20000), tx("2026-10-01", 99999)];
    expect(revenueThisMonth(transactions, now)).toBe(50000); // only the two September ones
  });

  it("ignores pending and refund transactions", () => {
    const now = new Date(2026, 8, 15);
    const transactions = [tx("2026-09-05", 10000, "received"), tx("2026-09-06", 5000, "pending"), tx("2026-09-07", 2000, "refund")];
    expect(revenueThisMonth(transactions, now)).toBe(10000);
  });

  it("is 0 with no transactions this month, even if past months have revenue", () => {
    const now = new Date(2026, 8, 15);
    expect(revenueThisMonth([tx("2026-08-20", 500000)], now)).toBe(0);
  });
});

describe("monthlyRevenueSeries — replaces the chart that faked five of its six bars", () => {
  it("buckets real revenue into the right months, ending with the current one", () => {
    const now = new Date(2026, 8, 15); // Sep 2026
    const transactions = [tx("2026-07-10", 10000), tx("2026-08-05", 20000), tx("2026-09-01", 30000)];
    const series = monthlyRevenueSeries(transactions, 3, now);
    expect(series.map((b) => b.label)).toEqual(["Jul", "Aug", "Sep"]);
    expect(series.map((b) => b.value)).toEqual([10000, 20000, 30000]);
  });

  it("every month is a real bucket now, not hardcoded zeros for all but the last", () => {
    const now = new Date(2026, 8, 15);
    const series = monthlyRevenueSeries([tx("2026-09-01", 1000)], 6, now);
    const nonLastMonths = series.slice(0, -1);
    // at least the shape is genuine per-month data, not a fixed placeholder array
    expect(series).toHaveLength(6);
    expect(nonLastMonths.every((b) => b.value === 0)).toBe(true); // correctly empty because there's truly no data for them
    expect(series[series.length - 1].value).toBe(1000);
  });

  it("labels stay correct across a year boundary", () => {
    const now = new Date(2026, 1, 10); // Feb 2026
    const series = monthlyRevenueSeries([], 3, now);
    expect(series.map((b) => b.label)).toEqual(["Dec", "Jan", "Feb"]);
  });
});
