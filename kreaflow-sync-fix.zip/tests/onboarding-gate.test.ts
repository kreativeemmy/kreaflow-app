import { describe, expect, it } from "vitest";
import { shouldRedirectToOnboarding, type OnboardingGateState } from "../lib/onboarding-gate";

function state(overrides: Partial<OnboardingGateState> = {}): OnboardingGateState {
  return {
    hydrated: true,
    accountLoading: false,
    isAuthenticated: true,
    cloudChecked: true,
    needsOnboarding: true,
    currentSegment: "index",
    ...overrides,
  };
}

describe("the bug as it actually happened: signed in, real cloud data, but not checked yet", () => {
  it("does NOT send a signed-in person to onboarding before their cloud data has been checked", () => {
    // This is the exact moment that used to break: auth just resolved
    // (isAuthenticated: true), so needsOnboarding is still computed from
    // empty local state (true) — but the cloud hasn't been checked yet.
    expect(shouldRedirectToOnboarding(state({ isAuthenticated: true, cloudChecked: false, needsOnboarding: true }))).toBe(false);
  });

  it("DOES send them to onboarding once the cloud has been checked and genuinely has nothing", () => {
    expect(shouldRedirectToOnboarding(state({ isAuthenticated: true, cloudChecked: true, needsOnboarding: true }))).toBe(true);
  });

  it("does not redirect once the cloud check lands a real workspace (needsOnboarding flips false)", () => {
    expect(shouldRedirectToOnboarding(state({ isAuthenticated: true, cloudChecked: true, needsOnboarding: false }))).toBe(false);
  });
});

describe("signed-out behaviour is unaffected by the fix", () => {
  it("still redirects a signed-out person who needs onboarding, cloudChecked or not", () => {
    expect(shouldRedirectToOnboarding(state({ isAuthenticated: false, cloudChecked: false, needsOnboarding: true }))).toBe(true);
    expect(shouldRedirectToOnboarding(state({ isAuthenticated: false, cloudChecked: true, needsOnboarding: true }))).toBe(true);
  });

  it("never redirects a signed-out person who doesn't need onboarding", () => {
    expect(shouldRedirectToOnboarding(state({ isAuthenticated: false, needsOnboarding: false }))).toBe(false);
  });
});

describe("other guards still hold", () => {
  it("never redirects before local storage has hydrated", () => {
    expect(shouldRedirectToOnboarding(state({ hydrated: false }))).toBe(false);
  });

  it("never redirects while the account is still loading", () => {
    expect(shouldRedirectToOnboarding(state({ accountLoading: true }))).toBe(false);
  });

  it("never redirects away from the onboarding screen itself (no redirect loop)", () => {
    expect(shouldRedirectToOnboarding(state({ currentSegment: "onboarding" }))).toBe(false);
  });

  it("never redirects when onboarding is already complete", () => {
    expect(shouldRedirectToOnboarding(state({ needsOnboarding: false }))).toBe(false);
  });
});
