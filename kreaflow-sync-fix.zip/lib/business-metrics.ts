import type { Client, Project, Transaction } from "@/lib/business-types";

export function formatNaira(value: number): string {
  return `₦${Math.round(value).toLocaleString("en-NG")}`;
}

export function projectPaid(projectId: string, transactions: Transaction[]): number {
  return transactions
    .filter((transaction) => transaction.projectId === projectId && (transaction.status === "received" || transaction.status === "income"))
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function projectBalance(project: Project, transactions: Transaction[]): number {
  return Math.max(0, project.price - projectPaid(project.id, transactions));
}

export function projectProgress(project: Project): number {
  if (!project.deliverables.length) return 0;
  const completed = project.deliverables.filter((item) => item.complete).length;
  return Math.round((completed / project.deliverables.length) * 100);
}

export function clientRevenue(clientId: string, transactions: Transaction[]): number {
  return transactions
    .filter((transaction) => transaction.clientId === clientId && (transaction.status === "received" || transaction.status === "income"))
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function clientOutstanding(clientId: string, projects: Project[], transactions: Transaction[]): number {
  return projects
    .filter((project) => project.clientId === clientId)
    .reduce((total, project) => total + projectBalance(project, transactions), 0);
}

export function totalRevenue(transactions: Transaction[]): number {
  return transactions
    .filter((transaction) => transaction.status === "received" || transaction.status === "income")
    .reduce((total, transaction) => total + transaction.amount, 0);
}

// "This month" specifically — totalRevenue() above is lifetime and should
// only be used for genuinely all-time totals. Every "this month" label in
// the app (the Home hero, Money screen, monthly goal progress) needs this
// one instead, or it silently stops resetting once a second month begins.
export function revenueThisMonth(transactions: Transaction[], now: Date = new Date()): number {
  const year = now.getFullYear();
  const month = now.getMonth();
  return transactions
    .filter((transaction) => {
      if (transaction.status !== "received" && transaction.status !== "income") return false;
      const match = /^(\d{4})-(\d{2})/.exec(transaction.date);
      if (!match) return false;
      return Number(match[1]) === year && Number(match[2]) - 1 === month;
    })
    .reduce((total, transaction) => total + transaction.amount, 0);
}

const CHART_MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// Real received-revenue per month, for the last N months ending with the
// current one — replaces a chart that used to be hand-filled with zeros
// for every month except whichever one was hardcoded as "latest".
export function monthlyRevenueSeries(transactions: Transaction[], months: number, now: Date = new Date()): { label: string; value: number }[] {
  const buckets = Array.from({ length: Math.max(1, months) }, (_, i) => {
    const offset = months - 1 - i;
    const date = new Date(now.getFullYear(), now.getMonth() - offset, 1);
    return { key: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`, label: CHART_MONTHS_SHORT[date.getMonth()], value: 0 };
  });
  const byKey = new Map(buckets.map((bucket) => [bucket.key, bucket]));
  for (const transaction of transactions) {
    if (transaction.status !== "received" && transaction.status !== "income") continue;
    const bucket = byKey.get(transaction.date.slice(0, 7));
    if (bucket) bucket.value += transaction.amount;
  }
  return buckets.map(({ label, value }) => ({ label, value }));
}

export function totalOutstanding(projects: Project[], transactions: Transaction[]): number {
  return projects.reduce((total, project) => total + projectBalance(project, transactions), 0);
}

export function clientName(clientId: string | undefined, clients: Client[]): string {
  if (!clientId) return "Independent income";
  return clients.find((client) => client.id === clientId)?.business ?? "Unassigned client";
}

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// Turns an ISO "YYYY-MM-DD" into "30 August 2026" for display. Free-text
// dates some screens allow (e.g. "Tomorrow") are shown exactly as typed.
export function formatDate(value: string): string {
  if (!value) return "No date set";
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!match) return value;
  const [, year, month, day] = match;
  const monthName = MONTH_NAMES[Number(month) - 1];
  return monthName ? `${Number(day)} ${monthName} ${year}` : value;
}
