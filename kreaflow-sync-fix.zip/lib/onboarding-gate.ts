export interface OnboardingGateState {
  hydrated: boolean;
  accountLoading: boolean;
  isAuthenticated: boolean;
  // Whether a signed-in person's cloud workspaces have been fetched at least
  // once since they signed in. Irrelevant when signed out.
  cloudChecked: boolean;
  needsOnboarding: boolean;
  currentSegment: string | undefined;
}

/**
 * Should the app send this person to onboarding right now?
 *
 * The one rule that matters: if someone is signed in, we do not decide
 * they need onboarding until we've actually checked the cloud for an
 * existing workspace. Deciding too early — the instant a session restores,
 * before that check finishes — looks exactly like a brand-new account and
 * sends someone with real data on the server straight back to "set up your
 * workspace," even though it's seconds from loading.
 */
export function shouldRedirectToOnboarding(state: OnboardingGateState): boolean {
  if (!state.hydrated) return false;
  if (state.accountLoading) return false;
  if (state.isAuthenticated && !state.cloudChecked) return false;
  if (!state.needsOnboarding) return false;
  if (state.currentSegment === "onboarding") return false;
  return true;
}
