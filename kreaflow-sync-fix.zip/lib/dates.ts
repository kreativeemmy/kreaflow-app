const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const WEEKDAYS_SHORT = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

/** Today's real date, in the same YYYY-MM-DD form every date field in the app stores. */
export function today(): string {
  return new Date().toISOString().slice(0, 10);
}

/** N days from today (or from another ISO date), still as YYYY-MM-DD. */
export function addDays(days: number, fromIso?: string): string {
  const base = fromIso ? isoToDate(fromIso) : new Date();
  base.setDate(base.getDate() + days);
  return base.toISOString().slice(0, 10);
}

/** Parses a "YYYY-MM-DD" string as a local-time Date (not UTC midnight, which
 * can silently land on the wrong day depending on the phone's timezone). */
export function isoToDate(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  if (!year || !month || !day) return new Date();
  return new Date(year, month - 1, day);
}

/** "2026-08-30" -> "30 Aug 2026". Falls back to the raw text for anything
 * that isn't a real ISO date (some fields, like a follow-up's date, are
 * intentionally loose text such as "Tomorrow"). */
export function formatDateFriendly(iso: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
  const date = isoToDate(iso);
  return `${date.getDate()} ${MONTHS_SHORT[date.getMonth()]} ${date.getFullYear()}`;
}

/** How many whole days from today until this ISO date (negative if past). */
export function daysUntil(iso: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return null;
  const target = isoToDate(iso);
  const now = isoToDate(today());
  return Math.round((target.getTime() - now.getTime()) / 86_400_000);
}

/** "Good morning" / "Good afternoon" / "Good evening", from the phone's own clock. */
export function timeOfDayGreeting(hour: number = new Date().getHours()): string {
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

export { MONTHS, MONTHS_SHORT, WEEKDAYS_SHORT };
