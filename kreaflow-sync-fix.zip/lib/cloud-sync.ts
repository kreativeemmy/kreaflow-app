import { supabase } from "@/lib/supabase";
import { newId } from "@/lib/id";
import { assembleWorkspaces, workspaceToRows, type Row } from "@/lib/cloud-mapping";
import type {
  BusinessProfile,
  Client,
  Deliverable,
  FollowUp,
  Goal,
  InvoiceDesign,
  InvoiceLineItem,
  Lead,
  Project,
  ProjectTask,
  Transaction,
  Workspace,
} from "@/lib/business-types";

// Every write silently logs instead of throwing, so a dropped connection
// never breaks the screen the person is looking at. The optimistic local
// change already happened; this is just trying to mirror it to the cloud.
function fireAndForget(promise: PromiseLike<{ error: { message: string } | null }>, label: string) {
  Promise.resolve(promise).then(({ error }) => {
    if (error) console.warn(`[cloud] ${label} failed:`, error.message);
  }).catch((error) => console.warn(`[cloud] ${label} failed:`, error));
}

/* ----------------------------- reading ----------------------------- */

export async function fetchCloudWorkspaces(): Promise<Workspace[]> {
  const { data: workspaceRows, error: wsError } = await supabase.from("workspaces").select("*").order("created_at");
  if (wsError) throw new Error(wsError.message);
  if (!workspaceRows || workspaceRows.length === 0) return [];

  const ids = workspaceRows.map((w) => w.id as string);
  const [clientsRes, leadsRes, projectsRes, deliverablesRes, tasksRes, paymentsRes, goalsRes, goalStepsRes] = await Promise.all([
    supabase.from("clients").select("*").in("workspace_id", ids),
    supabase.from("leads").select("*").in("workspace_id", ids),
    supabase.from("projects").select("*").in("workspace_id", ids),
    supabase.from("project_deliverables").select("*").in("workspace_id", ids).order("position"),
    supabase.from("tasks").select("*").in("workspace_id", ids),
    supabase.from("payments").select("*").in("workspace_id", ids),
    supabase.from("goals").select("*").in("workspace_id", ids),
    supabase.from("goal_steps").select("*").in("workspace_id", ids).order("position"),
  ]);
  for (const res of [clientsRes, leadsRes, projectsRes, deliverablesRes, tasksRes, paymentsRes, goalsRes, goalStepsRes]) {
    if (res.error) throw new Error(res.error.message);
  }

  return assembleWorkspaces({
    workspaces: workspaceRows,
    clients: clientsRes.data ?? [],
    leads: leadsRes.data ?? [],
    projects: projectsRes.data ?? [],
    deliverables: deliverablesRes.data ?? [],
    tasks: tasksRes.data ?? [],
    payments: paymentsRes.data ?? [],
    goals: goalsRes.data ?? [],
    goalSteps: goalStepsRes.data ?? [],
  });
}

/* ----------------------------- writing ----------------------------- */

export async function insertCloudWorkspace(id: string, input: { name: string; businessProfile: BusinessProfile; invoiceDesign: InvoiceDesign; onboardingComplete: boolean }): Promise<void> {
  // upsert, not insert: safe to call again if a previous attempt was
  // interrupted partway (a dropped connection, the app closing mid-save).
  const { error } = await supabase.from("workspaces").upsert({
    id, name: input.name, onboarding_complete: input.onboardingComplete,
    business_profile: input.businessProfile, invoice_design: input.invoiceDesign,
  }, { onConflict: "id" });
  if (error) throw new Error(error.message);
}

export function cloudCompleteOnboarding(workspaceId: string) {
  fireAndForget(supabase.from("workspaces").update({ onboarding_complete: true }).eq("id", workspaceId), "complete onboarding");
}

export function cloudUpdateBusinessProfile(workspaceId: string, profile: BusinessProfile) {
  fireAndForget(supabase.from("workspaces").update({ business_profile: profile, name: profile.name }).eq("id", workspaceId), "update business profile");
}

export function cloudUpdateInvoiceDesign(workspaceId: string, design: InvoiceDesign) {
  fireAndForget(supabase.from("workspaces").update({ invoice_design: design }).eq("id", workspaceId), "update invoice design");
}

export function cloudAddClient(workspaceId: string, client: Client) {
  fireAndForget(supabase.from("clients").insert({
    id: client.id, workspace_id: workspaceId, name: client.name, business: client.business, phone: client.phone,
    email: client.email, handle: client.handle, notes: client.notes, status: client.status, last_activity: client.lastActivity,
  }), "add client");
}

export function cloudTouchClient(workspaceId: string, clientId: string, patch: { status?: Client["status"]; lastActivity: string }) {
  fireAndForget(supabase.from("clients").update({ ...(patch.status ? { status: patch.status } : {}), last_activity: patch.lastActivity }).eq("id", clientId).eq("workspace_id", workspaceId), "touch client");
}

export function cloudUpdateClient(workspaceId: string, id: string, patch: Partial<Client>) {
  const row: Record<string, unknown> = {};
  if (patch.name !== undefined) row.name = patch.name;
  if (patch.business !== undefined) row.business = patch.business;
  if (patch.phone !== undefined) row.phone = patch.phone;
  if (patch.email !== undefined) row.email = patch.email;
  if (patch.handle !== undefined) row.handle = patch.handle;
  if (patch.notes !== undefined) row.notes = patch.notes;
  if (patch.status !== undefined) row.status = patch.status;
  if (Object.keys(row).length === 0) return;
  fireAndForget(supabase.from("clients").update(row).eq("id", id).eq("workspace_id", workspaceId), "update client");
}

export async function cloudDeleteClient(workspaceId: string, id: string): Promise<void> {
  const { error } = await supabase.from("clients").delete().eq("id", id).eq("workspace_id", workspaceId);
  if (error) throw new Error(error.message);
}

export async function cloudDeleteProject(workspaceId: string, id: string): Promise<void> {
  const { error } = await supabase.from("projects").delete().eq("id", id).eq("workspace_id", workspaceId);
  if (error) throw new Error(error.message);
}

export function cloudAddProject(workspaceId: string, project: Project) {
  fireAndForget(supabase.from("projects").insert({
    id: project.id, workspace_id: workspaceId, client_id: project.clientId || null, name: project.name, service: project.service,
    description: project.description, price: project.price, start_date: project.startDate || null, deadline: project.deadline || null,
    status: project.status, revisions_included: project.revisionsIncluded, revisions_used: project.revisionsUsed, notes: project.notes,
  }), "add project");
  for (const d of project.deliverables) cloudAddDeliverable(workspaceId, project.id, d);
  for (const t of project.tasks) cloudAddProjectTask(workspaceId, project.id, t);
}

export function cloudUpdateProject(workspaceId: string, id: string, patch: Partial<Project>) {
  const row: Record<string, unknown> = {};
  if (patch.name !== undefined) row.name = patch.name;
  if (patch.clientId !== undefined) row.client_id = patch.clientId || null;
  if (patch.service !== undefined) row.service = patch.service;
  if (patch.description !== undefined) row.description = patch.description;
  if (patch.price !== undefined) row.price = patch.price;
  if (patch.startDate !== undefined) row.start_date = patch.startDate || null;
  if (patch.deadline !== undefined) row.deadline = patch.deadline || null;
  if (patch.status !== undefined) row.status = patch.status;
  if (patch.revisionsIncluded !== undefined) row.revisions_included = patch.revisionsIncluded;
  if (patch.revisionsUsed !== undefined) row.revisions_used = patch.revisionsUsed;
  if (patch.notes !== undefined) row.notes = patch.notes;
  if (Object.keys(row).length === 0) return;
  fireAndForget(supabase.from("projects").update(row).eq("id", id).eq("workspace_id", workspaceId), "update project");
}

export function cloudAddDeliverable(workspaceId: string, projectId: string, deliverable: Deliverable, position = 0) {
  fireAndForget(supabase.from("project_deliverables").insert({ id: deliverable.id, workspace_id: workspaceId, project_id: projectId, title: deliverable.title, complete: deliverable.complete, position }), "add deliverable");
}

export function cloudToggleDeliverable(workspaceId: string, deliverableId: string, complete: boolean) {
  fireAndForget(supabase.from("project_deliverables").update({ complete }).eq("id", deliverableId).eq("workspace_id", workspaceId), "toggle deliverable");
}

export function cloudAddProjectTask(workspaceId: string, projectId: string, task: ProjectTask) {
  fireAndForget(supabase.from("tasks").insert({ id: task.id, workspace_id: workspaceId, kind: "task", project_id: projectId, title: task.title, due_date: task.dueDate, complete: task.complete }), "add project task");
}

export function cloudToggleProjectTask(workspaceId: string, taskId: string, complete: boolean) {
  fireAndForget(supabase.from("tasks").update({ complete }).eq("id", taskId).eq("workspace_id", workspaceId), "toggle project task");
}

export function cloudAddFollowUp(workspaceId: string, followUp: FollowUp) {
  fireAndForget(supabase.from("tasks").insert({
    id: followUp.id, workspace_id: workspaceId, kind: "follow_up", title: followUp.title, due_date: followUp.date,
    complete: followUp.complete, client_id: followUp.clientId || null, project_id: followUp.projectId || null,
  }), "add follow-up");
}

export function cloudAddLead(workspaceId: string, lead: Lead) {
  fireAndForget(supabase.from("leads").insert({
    id: lead.id, workspace_id: workspaceId, name: lead.name, business: lead.business, contact: lead.contact,
    service: lead.service, value: lead.value, source: lead.source, date_contacted: lead.dateContacted || null,
    next_follow_up: lead.nextFollowUp, notes: lead.notes, status: lead.status, lost_reason: lead.lostReason ?? null,
  }), "add lead");
}

export function cloudUpdateLead(workspaceId: string, id: string, patch: Partial<Lead>) {
  const row: Record<string, unknown> = {};
  if (patch.name !== undefined) row.name = patch.name;
  if (patch.business !== undefined) row.business = patch.business;
  if (patch.contact !== undefined) row.contact = patch.contact;
  if (patch.service !== undefined) row.service = patch.service;
  if (patch.value !== undefined) row.value = patch.value;
  if (patch.source !== undefined) row.source = patch.source;
  if (patch.dateContacted !== undefined) row.date_contacted = patch.dateContacted || null;
  if (patch.nextFollowUp !== undefined) row.next_follow_up = patch.nextFollowUp;
  if (patch.notes !== undefined) row.notes = patch.notes;
  if (patch.status !== undefined) row.status = patch.status;
  if (patch.lostReason !== undefined) row.lost_reason = patch.lostReason ?? null;
  if (Object.keys(row).length === 0) return;
  fireAndForget(supabase.from("leads").update(row).eq("id", id).eq("workspace_id", workspaceId), "update lead");
}

export function cloudAddTransaction(workspaceId: string, transaction: Transaction) {
  fireAndForget(supabase.from("payments").insert({
    id: transaction.id, workspace_id: workspaceId, client_id: transaction.clientId || null, project_id: transaction.projectId || null,
    amount: transaction.amount, status: transaction.status === "income" ? "received" : transaction.status, paid_on: transaction.date || null,
    method: transaction.method, note: transaction.note, invoice_snapshot: transaction.invoiceSnapshot ?? null,
  }), "add transaction");
}

export function cloudUpdateInvoiceSnapshot(workspaceId: string, transactionId: string, invoiceSnapshot: { businessProfile: BusinessProfile; design: InvoiceDesign; lineItems: InvoiceLineItem[] }) {
  fireAndForget(supabase.from("payments").update({ invoice_snapshot: invoiceSnapshot }).eq("id", transactionId).eq("workspace_id", workspaceId), "update invoice snapshot");
}

export function cloudAddGoal(workspaceId: string, goal: Goal) {
  fireAndForget(supabase.from("goals").insert({
    id: goal.id, workspace_id: workspaceId, level: goal.level, parent_id: goal.parentId || null, metric: "manual", title: goal.name,
    target_value: goal.target, current_value: goal.current, deadline: goal.deadline || null, category: goal.category,
  }), "add goal");
  for (const step of goal.steps) cloudAddGoalStep(workspaceId, goal.id, step);
}

export function cloudAddGoalStep(workspaceId: string, goalId: string, step: { id: string; title: string; done: boolean }, position = 0) {
  fireAndForget(supabase.from("goal_steps").insert({ id: step.id, workspace_id: workspaceId, goal_id: goalId, title: step.title, done: step.done, position }), "add goal step");
}

export function cloudToggleGoalStep(workspaceId: string, stepId: string, done: boolean) {
  fireAndForget(supabase.from("goal_steps").update({ done }).eq("id", stepId).eq("workspace_id", workspaceId), "toggle goal step");
}

export function cloudUpdateGoalProgress(workspaceId: string, id: string, current: number) {
  fireAndForget(supabase.from("goals").update({ current_value: current }).eq("id", id).eq("workspace_id", workspaceId), "update goal progress");
}

/* --------------------- one-time local -> cloud move --------------------- */

// Used the first time someone signs in after building a workspace locally.
// Every id was already a real UUID (see lib/id.ts), so rows move across
// unchanged and everything that referenced them keeps working.
export async function pushWorkspaceToCloud(workspace: Workspace): Promise<void> {
  // Every write here is an upsert keyed on id, so this whole function is
  // safe to re-run on a workspace that partly made it up before (a flaky
  // connection, the app being closed mid-save) — it finishes the job
  // instead of failing on "already exists" or creating duplicates.
  const rows = workspaceToRows(workspace);
  const { error: wsErr } = await supabase.from("workspaces").upsert(rows.workspaces[0], { onConflict: "id" });
  if (wsErr) throw new Error(wsErr.message);

  const upserts: [string, Row[]][] = [
    ["clients", rows.clients], ["projects", rows.projects], ["project_deliverables", rows.deliverables],
    ["tasks", rows.tasks], ["leads", rows.leads], ["payments", rows.payments], ["goals", rows.goals], ["goal_steps", rows.goalSteps],
  ];
  for (const [table, tableRows] of upserts) {
    if (!tableRows.length) continue;
    const { error } = await supabase.from(table).upsert(tableRows, { onConflict: "id" });
    if (error) throw new Error(error.message);
  }
}

export { newId };
