import { defineConfig } from "vitest/config";
import path from "node:path";

// Lets tests resolve the same "@/..." imports the app uses (tsconfig paths
// aren't picked up by Vite automatically).
export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, ".") } },
});
