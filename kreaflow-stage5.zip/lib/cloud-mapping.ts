import { DEFAULT_BUSINESS_PROFILE, DEFAULT_INVOICE_DESIGN } from "@/lib/business-types";
import type {
  BusinessProfile,
  BusinessState,
  Client,
  Deliverable,
  FollowUp,
  Goal,
  GoalStep,
  InvoiceDesign,
  Lead,
  Project,
  ProjectTask,
  Transaction,
  Workspace,
} from "@/lib/business-types";

// Postgres numeric columns come back from Supabase as strings (to protect
// precision), so every money/amount field needs to pass through this.
export function num(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}
export function str(value: unknown): string {
  return typeof value === "string" ? value : value == null ? "" : String(value);
}

// Older test data stored logo size as "Small"/"Medium"/"Large"; anything else
// (undefined, or already a number) passes straight through.
function coerceLogoScale(value: unknown): number {
  if (typeof value === "number") return value;
  if (value === "Small") return 54;
  if (value === "Large") return 112;
  if (value === "Medium") return 82;
  return DEFAULT_INVOICE_DESIGN.logoScale;
}

// Loose row shapes matching the Supabase tables (snake_case columns).
export type Row = Record<string, any>;

export interface CloudRows {
  workspaces: Row[];
  clients: Row[];
  leads: Row[];
  projects: Row[];
  deliverables: Row[];
  tasks: Row[];
  payments: Row[];
  goals: Row[];
  goalSteps: Row[];
}

/** Turns raw Supabase rows (grouped by table) into the app's Workspace[] shape. */
export function assembleWorkspaces(rows: CloudRows): Workspace[] {
  const { workspaces, clients, leads, projects, deliverables, tasks, payments, goals, goalSteps } = rows;

  return workspaces.map((ws): Workspace => {
    const wid = ws.id as string;
    const businessProfile: BusinessProfile = { ...DEFAULT_BUSINESS_PROFILE, ...(ws.business_profile ?? {}) };
    const invoiceDesign: InvoiceDesign = { ...DEFAULT_INVOICE_DESIGN, ...(ws.invoice_design ?? {}), logoScale: coerceLogoScale((ws.invoice_design ?? {}).logoScale) };

    const wsProjects: Project[] = projects.filter((p) => p.workspace_id === wid).map((p): Project => ({
      id: p.id, name: str(p.name), clientId: str(p.client_id), service: str(p.service), description: str(p.description),
      price: num(p.price), startDate: str(p.start_date), deadline: str(p.deadline), status: p.status,
      revisionsIncluded: num(p.revisions_included), revisionsUsed: num(p.revisions_used), notes: str(p.notes),
      deliverables: deliverables.filter((d) => d.project_id === p.id).map((d): Deliverable => ({ id: d.id, title: str(d.title), complete: !!d.complete })),
      tasks: tasks.filter((t) => t.kind === "task" && t.project_id === p.id).map((t): ProjectTask => ({ id: t.id, title: str(t.title), dueDate: str(t.due_date), complete: !!t.complete })),
    }));

    const wsFollowUps: FollowUp[] = tasks.filter((t) => t.workspace_id === wid && t.kind === "follow_up").map((t): FollowUp => ({
      id: t.id, title: str(t.title), date: str(t.due_date), clientId: t.client_id ?? undefined, projectId: t.project_id ?? undefined, complete: !!t.complete,
    }));

    const wsTransactions: Transaction[] = payments.filter((pay) => pay.workspace_id === wid).map((pay): Transaction => ({
      id: pay.id, clientId: pay.client_id ?? undefined, projectId: pay.project_id ?? undefined, amount: num(pay.amount),
      date: str(pay.paid_on), method: str(pay.method), status: pay.status, note: str(pay.note),
      invoiceSnapshot: pay.invoice_snapshot ?? undefined,
    }));

    const data: BusinessState = {
      businessProfile, invoiceDesign,
      clients: clients.filter((c) => c.workspace_id === wid).map((c): Client => ({
        id: c.id, name: str(c.name), business: str(c.business), phone: str(c.phone), email: str(c.email),
        handle: str(c.handle), notes: str(c.notes), status: c.status, lastActivity: str(c.last_activity),
      })),
      leads: leads.filter((l) => l.workspace_id === wid).map((l): Lead => ({
        id: l.id, name: str(l.name), business: str(l.business), contact: str(l.contact), service: str(l.service),
        value: num(l.value), source: str(l.source), dateContacted: str(l.date_contacted), nextFollowUp: str(l.next_follow_up),
        notes: str(l.notes), status: l.status, lostReason: l.lost_reason ?? undefined,
      })),
      projects: wsProjects,
      transactions: wsTransactions,
      followUps: wsFollowUps,
      goals: goals.filter((g) => g.workspace_id === wid).map((g): Goal => ({
        id: g.id, name: str(g.title), target: num(g.target_value), current: num(g.current_value),
        deadline: str(g.deadline), category: (g.category as Goal["category"]) ?? "Revenue",
        level: (g.level as Goal["level"]) ?? "custom", parentId: g.parent_id ?? undefined,
        steps: goalSteps.filter((s) => s.goal_id === g.id).map((s): GoalStep => ({ id: s.id, title: str(s.title), done: !!s.done })),
      })),
    };

    return { id: wid, name: str(ws.name), createdAt: str(ws.created_at), onboardingComplete: !!ws.onboarding_complete, data };
  });
}

/** Turns a local Workspace (and its nested data) into the row sets a fresh push would insert. */
export function workspaceToRows(workspace: Workspace): CloudRows {
  const { data } = workspace;
  const workspaceRow: Row = {
    id: workspace.id, name: workspace.name, onboarding_complete: workspace.onboardingComplete,
    business_profile: data.businessProfile, invoice_design: data.invoiceDesign,
    // Preserve the real creation date across the move instead of letting the
    // database stamp "now" for a workspace that was actually built earlier.
    created_at: workspace.createdAt,
  };
  const clientRows = data.clients.map((c): Row => ({
    id: c.id, workspace_id: workspace.id, name: c.name, business: c.business, phone: c.phone, email: c.email,
    handle: c.handle, notes: c.notes, status: c.status, last_activity: c.lastActivity,
  }));
  const projectRows = data.projects.map((p): Row => ({
    id: p.id, workspace_id: workspace.id, client_id: p.clientId || null, name: p.name, service: p.service,
    description: p.description, price: p.price, start_date: p.startDate || null, deadline: p.deadline || null,
    status: p.status, revisions_included: p.revisionsIncluded, revisions_used: p.revisionsUsed, notes: p.notes,
  }));
  const deliverableRows = data.projects.flatMap((p) => p.deliverables.map((d, i): Row => ({ id: d.id, workspace_id: workspace.id, project_id: p.id, title: d.title, complete: d.complete, position: i })));
  const projectTaskRows = data.projects.flatMap((p) => p.tasks.map((t): Row => ({ id: t.id, workspace_id: workspace.id, kind: "task", project_id: p.id, title: t.title, due_date: t.dueDate, complete: t.complete })));
  const followUpRows = data.followUps.map((f): Row => ({
    id: f.id, workspace_id: workspace.id, kind: "follow_up", title: f.title, due_date: f.date,
    complete: f.complete, client_id: f.clientId || null, project_id: f.projectId || null,
  }));
  const leadRows = data.leads.map((l): Row => ({
    id: l.id, workspace_id: workspace.id, name: l.name, business: l.business, contact: l.contact, service: l.service,
    value: l.value, source: l.source, date_contacted: l.dateContacted || null, next_follow_up: l.nextFollowUp,
    notes: l.notes, status: l.status, lost_reason: l.lostReason ?? null,
  }));
  const paymentRows = data.transactions.map((t): Row => ({
    id: t.id, workspace_id: workspace.id, client_id: t.clientId || null, project_id: t.projectId || null,
    amount: t.amount, status: t.status === "income" ? "received" : t.status, paid_on: t.date || null,
    method: t.method, note: t.note, invoice_snapshot: t.invoiceSnapshot ?? null,
  }));
  const goalRows = data.goals.map((g): Row => ({
    id: g.id, workspace_id: workspace.id, level: g.level, parent_id: g.parentId || null, metric: "manual", title: g.name,
    target_value: g.target, current_value: g.current, deadline: g.deadline || null, category: g.category,
  }));
  const goalStepRows = data.goals.flatMap((g) => g.steps.map((s, i): Row => ({ id: s.id, workspace_id: workspace.id, goal_id: g.id, title: s.title, done: s.done, position: i })));

  return {
    workspaces: [workspaceRow], clients: clientRows, leads: leadRows, projects: projectRows,
    deliverables: deliverableRows, tasks: [...projectTaskRows, ...followUpRows], payments: paymentRows, goals: goalRows, goalSteps: goalStepRows,
  };
}
