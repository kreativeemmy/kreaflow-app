export type ClientStatus = "Lead" | "Active" | "Completed" | "Inactive";
export type ProjectStage = "Brief" | "Designing" | "Review" | "Revision" | "Approved" | "Delivered";
export type LeadStage = "New Lead" | "Contacted" | "Proposal" | "Negotiation" | "Won" | "Lost";
export type TransactionStatus = "received" | "pending" | "refund" | "income";
export type InvoiceLayout = "Classic" | "Modern" | "Minimal";
export type InvoiceFont = "Inter" | "Poppins" | "Roboto" | "Open Sans" | "Lato" | "Custom";
export type LogoPosition = "Left" | "Center" | "Right";
export type AccentStyle = "Bar" | "Stripe" | "Block";
export type InvoiceTableStyle = "Ruled" | "Tinted" | "Minimal";
export type SpacingDensity = "Compact" | "Balanced" | "Relaxed";
export type InvoiceBackgroundMode = "Default" | "Solid" | "Gradient" | "Image";

export interface ImportedInvoiceAsset {
  name: string;
  mimeType: string;
  dataUri: string;
  size?: number;
}

export interface BusinessProfile {
  name: string;
  currency: string;
  businessType: string;
  industry: string;
  description: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  social: string;
  taxId: string;
  invoicePrefix: string;
  paymentDetails: string;
  logo?: ImportedInvoiceAsset;
  notes: string;
  terms: string;
}

export interface InvoiceDesign {
  name: string;
  layout: InvoiceLayout;
  primaryColor: string;
  accentColor: string;
  textColor: string;
  backgroundColor: string;
  tableHeaderColor: string;
  borderColor: string;
  font: InvoiceFont;
  customFont?: ImportedInvoiceAsset;
  logo?: ImportedInvoiceAsset;
  logoPosition: LogoPosition;
  logoScale: number; // logo width in the printed invoice, in px (40-220)
  backgroundMode: InvoiceBackgroundMode;
  backgroundImage?: ImportedInvoiceAsset;
  backgroundOpacity: number;
  backgroundFit: "Cover" | "Contain";
  backgroundPosition: "Top" | "Center" | "Bottom";
  headerAlignment: "Left" | "Center" | "Right";
  accentStyle: AccentStyle;
  tableStyle: InvoiceTableStyle;
  borderVisible: boolean;
  cornerRadius: "Square" | "Soft" | "Rounded";
  spacing: SpacingDensity;
}

export interface InvoiceLineItem {
  description: string;
  detail: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface InvoiceSnapshot {
  businessProfile: BusinessProfile;
  design: InvoiceDesign;
  lineItems: InvoiceLineItem[];
}

export const DEFAULT_BUSINESS_PROFILE: BusinessProfile = {
  name: "Kreativeemmy",
  currency: "NGN",
  businessType: "Social Media Brand Design",
  industry: "Creative services",
  description: "A focused social media brand design workspace.",
  address: "Lagos, Nigeria",
  phone: "+234 000 000 0000",
  email: "hello@kreativeemmy.co",
  website: "kreativeemmy.co",
  social: "@kreativeemmy",
  taxId: "",
  invoicePrefix: "INV",
  paymentDetails: "Bank transfer details can be added here.",
  notes: "Thank you for choosing Kreativeemmy. Payment confirms your project booking or delivery milestone.",
  terms: "Payment is due on receipt unless a written project agreement states otherwise.",
};

export const DEFAULT_INVOICE_DESIGN: InvoiceDesign = {
  name: "Kreativeemmy Default",
  layout: "Modern",
  primaryColor: "#0562E9",
  accentColor: "#F0D250",
  textColor: "#323637",
  backgroundColor: "#FFFFFF",
  tableHeaderColor: "#B4DEFF",
  borderColor: "#B4DEFF",
  font: "Inter",
  logoPosition: "Left",
  logoScale: 82,
  backgroundMode: "Default",
  backgroundOpacity: 8,
  backgroundFit: "Cover",
  backgroundPosition: "Center",
  headerAlignment: "Left",
  accentStyle: "Bar",
  tableStyle: "Tinted",
  borderVisible: true,
  cornerRadius: "Soft",
  spacing: "Balanced",
};

export interface Client {
  id: string;
  name: string;
  business: string;
  phone: string;
  email: string;
  handle: string;
  notes: string;
  status: ClientStatus;
  lastActivity: string;
}

export interface Deliverable {
  id: string;
  title: string;
  complete: boolean;
}

export interface ProjectTask {
  id: string;
  title: string;
  dueDate: string;
  complete: boolean;
}

export interface Project {
  id: string;
  name: string;
  clientId: string;
  service: string;
  description: string;
  price: number;
  startDate: string;
  deadline: string;
  status: ProjectStage;
  revisionsIncluded: number;
  revisionsUsed: number;
  notes: string;
  deliverables: Deliverable[];
  tasks: ProjectTask[];
}

export interface Lead {
  id: string;
  name: string;
  business: string;
  contact: string;
  service: string;
  value: number;
  source: string;
  dateContacted: string;
  nextFollowUp: string;
  notes: string;
  status: LeadStage;
  lostReason?: string;
}

export interface Transaction {
  id: string;
  clientId?: string;
  projectId?: string;
  amount: number;
  date: string;
  method: string;
  status: TransactionStatus;
  note: string;
  invoiceSnapshot?: InvoiceSnapshot;
}

export interface FollowUp {
  id: string;
  title: string;
  date: string;
  clientId?: string;
  projectId?: string;
  complete: boolean;
}

export interface GoalStep {
  id: string;
  title: string;
  done: boolean;
}

export interface Goal {
  id: string;
  name: string;
  target: number;
  current: number;
  deadline: string;
  category: "Revenue" | "Clients" | "Projects" | "Content" | "Portfolio";
  // "year" = the big vision for the year, "month" = a goal under that vision,
  // "custom" = an old-style one-off milestone with no year/month attached.
  level: "year" | "month" | "custom";
  parentId?: string;
  steps: GoalStep[];
}

export interface BusinessState {
  clients: Client[];
  projects: Project[];
  leads: Lead[];
  transactions: Transaction[];
  followUps: FollowUp[];
  goals: Goal[];
  businessProfile: BusinessProfile;
  invoiceDesign: InvoiceDesign;
}

export interface Workspace {
  id: string;
  name: string;
  createdAt: string;
  onboardingComplete: boolean;
  data: BusinessState;
}

export interface WorkspaceStore {
  version: 2;
  activeWorkspaceId: string | null;
  workspaces: Workspace[];
}

export type WorkspaceSummary = Pick<Workspace, "id" | "name" | "createdAt" | "onboardingComplete">;

export const PROJECT_STAGES: ProjectStage[] = [
  "Brief",
  "Designing",
  "Review",
  "Revision",
  "Approved",
  "Delivered",
];

export const LEAD_STAGES: LeadStage[] = [
  "New Lead",
  "Contacted",
  "Proposal",
  "Negotiation",
  "Won",
  "Lost",
];
