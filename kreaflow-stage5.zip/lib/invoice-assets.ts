import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import { Platform } from "react-native";

import type { ImportedInvoiceAsset } from "@/lib/business-types";

const MAX_IMAGE_BYTES = 700_000;
const MAX_FONT_BYTES = 650_000;

function inferMimeType(name: string, fallback: string): string {
  const extension = name.split(".").pop()?.toLowerCase();
  const map: Record<string, string> = {
    png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", svg: "image/svg+xml",
    ttf: "font/ttf", otf: "font/otf", woff: "font/woff", woff2: "font/woff2",
  };
  return map[extension ?? ""] ?? fallback;
}

async function webDataUri(uri: string, mimeType: string): Promise<string> {
  const response = await fetch(uri);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The selected file could not be imported."));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(blob);
  });
}

async function asImportedAsset(asset: DocumentPicker.DocumentPickerAsset, maxBytes: number): Promise<ImportedInvoiceAsset> {
  if (asset.size && asset.size > maxBytes) throw new Error(`Choose a file smaller than ${Math.round(maxBytes / 1000)} KB so it remains safe to store and export.`);
  const mimeType = inferMimeType(asset.name, asset.mimeType ?? "application/octet-stream");
  const dataUri = Platform.OS === "web"
    ? await webDataUri(asset.uri, mimeType)
    : `data:${mimeType};base64,${await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 })}`;
  return { name: asset.name, mimeType, dataUri, size: asset.size };
}

export async function pickInvoiceImage(kind: "logo" | "background"): Promise<ImportedInvoiceAsset | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["image/png", "image/jpeg", "image/svg+xml"], copyToCacheDirectory: true });
  if (result.canceled || !result.assets?.[0]) return null;
  const asset = await asImportedAsset(result.assets[0], MAX_IMAGE_BYTES);
  if (!asset.mimeType.startsWith("image/")) throw new Error(`Choose a PNG, JPG, JPEG, or SVG ${kind} file.`);
  return asset;
}

export async function pickInvoiceFont(): Promise<ImportedInvoiceAsset | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["font/ttf", "font/otf", "font/woff", "font/woff2", "application/font-sfnt"], copyToCacheDirectory: true });
  if (result.canceled || !result.assets?.[0]) return null;
  const asset = await asImportedAsset(result.assets[0], MAX_FONT_BYTES);
  if (!/\.(ttf|otf|woff|woff2)$/i.test(asset.name)) throw new Error("Choose a TTF, OTF, WOFF, or WOFF2 font file.");
  return asset;
}
