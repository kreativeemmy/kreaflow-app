import type { Client, Project, Transaction } from "@/lib/business-types";

export function formatNaira(value: number): string {
  return `₦${Math.round(value).toLocaleString("en-NG")}`;
}

export function projectPaid(projectId: string, transactions: Transaction[]): number {
  return transactions
    .filter((transaction) => transaction.projectId === projectId && (transaction.status === "received" || transaction.status === "income"))
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function projectBalance(project: Project, transactions: Transaction[]): number {
  return Math.max(0, project.price - projectPaid(project.id, transactions));
}

export function projectProgress(project: Project): number {
  if (!project.deliverables.length) return 0;
  const completed = project.deliverables.filter((item) => item.complete).length;
  return Math.round((completed / project.deliverables.length) * 100);
}

export function clientRevenue(clientId: string, transactions: Transaction[]): number {
  return transactions
    .filter((transaction) => transaction.clientId === clientId && (transaction.status === "received" || transaction.status === "income"))
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function clientOutstanding(clientId: string, projects: Project[], transactions: Transaction[]): number {
  return projects
    .filter((project) => project.clientId === clientId)
    .reduce((total, project) => total + projectBalance(project, transactions), 0);
}

export function totalRevenue(transactions: Transaction[]): number {
  return transactions
    .filter((transaction) => transaction.status === "received" || transaction.status === "income")
    .reduce((total, transaction) => total + transaction.amount, 0);
}

export function totalOutstanding(projects: Project[], transactions: Transaction[]): number {
  return projects.reduce((total, project) => total + projectBalance(project, transactions), 0);
}

export function clientName(clientId: string | undefined, clients: Client[]): string {
  if (!clientId) return "Independent income";
  return clients.find((client) => client.id === clientId)?.business ?? "Unassigned client";
}

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// Turns an ISO "YYYY-MM-DD" into "30 August 2026" for display. Free-text
// dates some screens allow (e.g. "Tomorrow") are shown exactly as typed.
export function formatDate(value: string): string {
  if (!value) return "No date set";
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!match) return value;
  const [, year, month, day] = match;
  const monthName = MONTH_NAMES[Number(month) - 1];
  return monthName ? `${Number(day)} ${monthName} ${year}` : value;
}
