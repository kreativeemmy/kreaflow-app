import "react-native-url-polyfill/auto";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";
import { Platform } from "react-native";

// The anon key below is designed to be public — it only unlocks what the
// database rules (Row Level Security) allow, so it's safe to ship in the app.
const SUPABASE_URL = "https://cnbgiibfhtmfxxjldigd.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYmdpaWJmaHRtZnh4amxkaWdkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAyNTUwOTQsImV4cCI6MjEwNTgzMTA5NH0.qA0nkhJ1J3X8legTZ6IwGEmUYJUrVZreoZV-R7vcT6o";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    // Only the browser needs to read a session token out of the page URL
    // (used for password-reset links); the native app never does.
    detectSessionInUrl: Platform.OS === "web",
  },
});
