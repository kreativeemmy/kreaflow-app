export const PRODUCT_IDENTITY = {
  name: "KreaFlow",
  tagline: "A business operating system for freelancers and creative professionals.",
  summary: "Manage clients, projects, leads, payments, follow-ups and business goals from one place.",
} as const;
