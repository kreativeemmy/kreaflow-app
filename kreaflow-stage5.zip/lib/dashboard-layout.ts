export function dashboardMetricLayout(viewportWidth: number): { columns: 2 | 4; cellWidth: "48.5%" | "23.9%" } {
  return viewportWidth >= 980 ? { columns: 4, cellWidth: "23.9%" } : { columns: 2, cellWidth: "48.5%" };
}
