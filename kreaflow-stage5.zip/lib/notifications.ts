import AsyncStorage from "@react-native-async-storage/async-storage";
import Constants from "expo-constants";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

import type { BusinessState } from "@/lib/business-types";

export const DEVICE_REMINDERS_KEY = "kreativeemmy-device-reminders-enabled";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

function dateKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function addDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function createMorningTrigger(day: string): Date | null {
  const trigger = new Date(`${day}T09:00:00`);
  return trigger.getTime() > Date.now() ? trigger : null;
}

function parseFollowUpDate(value: string): string | null {
  const now = new Date();
  if (value === "Today") return dateKey(now);
  if (value === "Tomorrow") return dateKey(addDays(now, 1));
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const parsed = new Date(`${value} ${now.getFullYear()}`);
  return Number.isNaN(parsed.getTime()) ? null : dateKey(parsed);
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === "web") return false;
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("business-reminders", {
      name: "Business reminders",
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 200, 150, 200],
      lightColor: "#F26A50",
    });
  }
  const current = await Notifications.getPermissionsAsync();
  const next = current.status === "granted" ? current : await Notifications.requestPermissionsAsync();
  return next.status === "granted";
}

export async function getExpoPushToken(): Promise<string | null> {
  if (Platform.OS === "web" || !Device.isDevice) return null;
  const permitted = await requestNotificationPermission();
  if (!permitted) return null;
  const projectId = Constants.expoConfig?.extra?.eas?.projectId ?? Constants.easConfig?.projectId;
  if (!projectId) return null;
  try {
    return (await Notifications.getExpoPushTokenAsync({ projectId })).data;
  } catch {
    return null;
  }
}

export async function scheduleDeviceReminders(business: BusinessState): Promise<number> {
  if (Platform.OS === "web") return 0;
  const permitted = await requestNotificationPermission();
  if (!permitted) return 0;
  await Notifications.cancelAllScheduledNotificationsAsync();
  let count = 0;
  for (const project of business.projects) {
    if (project.status === "Delivered") continue;
    const dueTrigger = createMorningTrigger(project.deadline);
    if (dueTrigger) {
      await Notifications.scheduleNotificationAsync({
        content: { title: "Project deadline", body: `${project.name} is due today.`, data: { url: `/project/${project.id}` }, sound: "default" },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: dueTrigger, channelId: "business-reminders" },
      });
      count += 1;
    }
    const priorDate = new Date(`${project.deadline}T09:00:00`);
    priorDate.setDate(priorDate.getDate() - 1);
    if (priorDate.getTime() > Date.now()) {
      await Notifications.scheduleNotificationAsync({
        content: { title: "Project deadline tomorrow", body: `${project.name} is due tomorrow.`, data: { url: `/project/${project.id}` }, sound: "default" },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: priorDate, channelId: "business-reminders" },
      });
      count += 1;
    }
  }

  for (const followUp of business.followUps) {
    if (followUp.complete) continue;
    const dueDate = parseFollowUpDate(followUp.date);
    if (!dueDate) continue;
    const trigger = createMorningTrigger(dueDate);
    if (!trigger) continue;
    await Notifications.scheduleNotificationAsync({
      content: { title: "Follow-up reminder", body: followUp.title, data: { url: followUp.projectId ? `/project/${followUp.projectId}` : "/(tabs)/leads" }, sound: "default" },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: trigger, channelId: "business-reminders" },
    });
    count += 1;
  }
  return count;
}

export async function setDeviceRemindersEnabled(enabled: boolean, business: BusinessState): Promise<number> {
  if (!enabled) {
    await Notifications.cancelAllScheduledNotificationsAsync();
    await AsyncStorage.setItem(DEVICE_REMINDERS_KEY, "false");
    return 0;
  }
  const count = await scheduleDeviceReminders(business);
  await AsyncStorage.setItem(DEVICE_REMINDERS_KEY, "true");
  return count;
}
