import { formatNaira, projectBalance, projectPaid } from "./business-metrics";
import { DEFAULT_BUSINESS_PROFILE, DEFAULT_INVOICE_DESIGN, type BusinessProfile, type Client, type InvoiceDesign, type InvoiceLineItem, type Project, type Transaction } from "./business-types";

export type InvoiceData = {
  invoiceNumber: string;
  issueDate: string;
  transaction: Transaction;
  project: Project;
  client: Client;
  businessProfile: BusinessProfile;
  design: InvoiceDesign;
  lineItems: InvoiceLineItem[];
  subtotal: number;
  discount: number;
  total: number;
  amountPaid: number;
  balance: number;
};

export type InvoiceExportResult = { method: "downloaded" | "opened" | "shared" | "printed"; fileName: string };

type InvoiceOptions = { businessProfile: BusinessProfile; design: InvoiceDesign };

function escapeHtml(value: unknown): string {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;" })[character] ?? character);
}

function normalizeProfile(profile?: Partial<BusinessProfile>): BusinessProfile {
  return { ...DEFAULT_BUSINESS_PROFILE, ...(profile ?? {}), logo: profile?.logo ? { ...profile.logo } : undefined };
}

function normalizeDesign(design?: Partial<InvoiceDesign>): InvoiceDesign {
  return { ...DEFAULT_INVOICE_DESIGN, ...(design ?? {}), customFont: design?.customFont ? { ...design.customFont } : undefined, logo: design?.logo ? { ...design.logo } : undefined, backgroundImage: design?.backgroundImage ? { ...design.backgroundImage } : undefined };
}

function defaultItems(project: Project): InvoiceLineItem[] {
  return [{ description: project.service, detail: project.name, quantity: 1, rate: project.price, amount: project.price }];
}

function pdfFont(design: InvoiceDesign): { family: string; css: string } {
  if (design.font === "Custom" && design.customFont?.dataUri) return { family: "InvoiceCustom, Helvetica, Arial, sans-serif", css: `@font-face { font-family: InvoiceCustom; src: url('${design.customFont.dataUri}'); }` };
  const fallback: Record<string, string> = { Inter: "Arial, Helvetica, sans-serif", Poppins: "Trebuchet MS, Arial, sans-serif", Roboto: "Arial, Helvetica, sans-serif", "Open Sans": "Arial, Helvetica, sans-serif", Lato: "Verdana, Arial, sans-serif" };
  return { family: fallback[design.font] ?? "Helvetica, Arial, sans-serif", css: "" };
}

function radius(design: InvoiceDesign): string { return design.cornerRadius === "Square" ? "0" : design.cornerRadius === "Rounded" ? "20px" : "10px"; }
function density(design: InvoiceDesign): { pad: string; gap: string; row: string } { return design.spacing === "Compact" ? { pad: "15px", gap: "16px", row: "9px" } : design.spacing === "Relaxed" ? { pad: "28px", gap: "28px", row: "17px" } : { pad: "21px", gap: "22px", row: "13px" }; }

function hexColor(value: string, fallback: [number, number, number]): [number, number, number] {
  const match = /^#?([0-9a-f]{6})$/i.exec(value ?? "");
  if (!match) return fallback;
  return [parseInt(match[1].slice(0, 2), 16), parseInt(match[1].slice(2, 4), 16), parseInt(match[1].slice(4, 6), 16)];
}

function pdfEscape(value: unknown): string { return String(value ?? "").replace(/\\/g, "\\\\").replace(/[()]/g, "\\$&").replace(/[^\x20-\x7E]/g, ""); }

export function createBrowserInvoicePdf(invoice: InvoiceData): string {
  const primary = hexColor(invoice.design.primaryColor, [5, 98, 233]);
  const color = (value: [number, number, number]) => `${(value[0] / 255).toFixed(3)} ${(value[1] / 255).toFixed(3)} ${(value[2] / 255).toFixed(3)}`;
  const text = (value: unknown, x: number, y: number, size = 10, bold = false, rgb: [number, number, number] = [23, 33, 30]) => `BT /${bold ? "F2" : "F1"} ${size} Tf ${color(rgb)} rg 1 0 0 1 ${x} ${y} Tm (${pdfEscape(value)}) Tj ET`;
  const money = (amount: number) => formatNaira(amount).replace("₦", "NGN ");
  const lines = [
    `${color(primary)} rg 42 718 511 86 re f`, text(invoice.businessProfile.name, 60, 778, 9, true, [255, 255, 255]), text("INVOICE", 60, 748, 25, true, [255, 255, 255]), text(`${invoice.invoiceNumber}  |  Issued ${invoice.issueDate}`, 60, 730, 9, false, [245, 248, 255]),
    text("BILL TO", 42, 680, 8, true, [147, 99, 21]), text(invoice.client.business || invoice.client.name, 42, 660, 12, true), text(invoice.client.name, 42, 643), text(invoice.client.email || invoice.client.phone || "Client details on file", 42, 627, 9, false, [103, 110, 106]),
    text("PAYMENT", 412, 680, 8, true, [147, 99, 21]), text(invoice.transaction.status === "pending" ? "Payment due" : "Payment received", 412, 660, 12, true), text(invoice.transaction.method, 412, 643, 9, false, [103, 110, 106]),
    "0.88 0.95 1 rg 42 584 511 28 re f", text("DESCRIPTION", 54, 595, 8, true), text("QTY", 345, 595, 8, true), text("RATE", 417, 595, 8, true), text("AMOUNT", 490, 595, 8, true),
    ...invoice.lineItems.slice(0, 7).flatMap((item, index) => { const y = 563 - index * 38; return [text(item.description || "Service", 54, y, 10, true), text(item.detail || "", 54, y - 13, 8, false, [103, 110, 106]), text(item.quantity, 345, y), text(money(item.rate), 417, y), text(money(item.amount), 490, y, 10, true), `0.86 0.88 0.88 RG 42 ${y - 24} m 553 ${y - 24} l S`]; }),
    text("Subtotal", 370, 300, 9, false, [103, 110, 106]), text(money(invoice.subtotal), 485, 300, 10, true), text("Total", 370, 278, 9, false, [103, 110, 106]), text(money(invoice.total), 485, 278, 10, true), text("Amount paid", 370, 256, 9, false, [103, 110, 106]), text(money(invoice.amountPaid), 485, 256, 10, true), text("Balance due", 370, 234, 10, true), text(money(invoice.balance), 485, 234, 10, true, invoice.balance ? [147, 99, 21] : primary),
    "0.86 0.88 0.88 RG 42 194 m 553 194 l S", text("NOTES & TERMS", 42, 174, 8, true, [147, 99, 21]), text(`${invoice.businessProfile.notes || ""} ${invoice.businessProfile.terms || ""}`.trim().slice(0, 150) || "Payment confirms project booking or delivery milestone.", 42, 157, 9, false, [103, 110, 106]), text(`${invoice.businessProfile.name}${invoice.businessProfile.website ? ` - ${invoice.businessProfile.website}` : ""}`, 220, 42, 8, false, [103, 110, 106]),
    ...(invoice.businessProfile.paymentDetails ? [text("PAYMENT DETAILS", 42, 214, 8, true, [147, 99, 21]), text(invoice.businessProfile.paymentDetails.slice(0, 120), 42, 200, 9, false, [103, 110, 106])] : []),
  ];
  const stream = lines.join("\n"); const objects = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>", "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>", `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>"];
  let pdf = "%PDF-1.4\n"; const offsets = [0]; objects.forEach((object, index) => { offsets.push(pdf.length); pdf += `${index + 1} 0 obj\n${object}\nendobj\n`; }); const xref = pdf.length; pdf += `xref\n0 7\n0000000000 65535 f \n${offsets.slice(1).map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("")}trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return pdf;
}

function downloadPdfInBrowser(invoice: InvoiceData, fileName: string): InvoiceExportResult {
  const pdf = createBrowserInvoicePdf(invoice);
  const url = URL.createObjectURL(new Blob([pdf], { type: "application/pdf" }));
  const embeddedPreview = window.self !== window.top;
  if (embeddedPreview) {
    const preview = window.open(url, "_blank", "noopener,noreferrer");
    if (preview) { setTimeout(() => URL.revokeObjectURL(url), 60_000); return { method: "opened", fileName }; }
  }
  const link = document.createElement("a"); link.href = url; link.download = fileName; link.style.display = "none"; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  return { method: "downloaded", fileName };
}

export function invoiceFilename(invoice: Pick<InvoiceData, "invoiceNumber" | "client">): string {
  const source = `Invoice-${invoice.invoiceNumber}-${invoice.client.business || invoice.client.name}`;
  const cleaned = source.normalize("NFKD").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 100);
  return `${cleaned || "Invoice"}.pdf`;
}

export function createInvoiceData(transaction: Transaction, project: Project, client: Client, transactions: Transaction[], options?: InvoiceOptions): InvoiceData {
  const snapshot = transaction.invoiceSnapshot;
  const businessProfile = normalizeProfile(snapshot?.businessProfile ?? options?.businessProfile);
  const design = normalizeDesign(snapshot?.design ?? options?.design);
  const lineItems = snapshot?.lineItems?.length ? snapshot.lineItems : defaultItems(project);
  const subtotal = lineItems.reduce((sum, item) => sum + item.amount, 0);
  const suffix = transaction.id.replace(/[^a-zA-Z0-9]/g, "").slice(-6).toUpperCase();
  const prefix = (businessProfile.invoicePrefix ?? "INV").trim().toUpperCase().replace(/[^A-Z0-9]/g, "") || "INV";
  return { invoiceNumber: `${prefix}-${suffix || "0001"}`, issueDate: transaction.date, transaction, project, client, businessProfile, design, lineItems, subtotal, discount: 0, total: subtotal, amountPaid: projectPaid(project.id, transactions), balance: projectBalance(project, transactions) };
}

export function invoiceHtml(invoice: InvoiceData): string {
  const { design, businessProfile } = invoice;
  const font = pdfFont(design);
  const spacing = density(design);
  const bordered = design.borderVisible ? `1px solid ${design.borderColor}` : "0";
  const headerAlign = design.headerAlignment.toLowerCase();
  const logo = businessProfile.logo ?? design.logo;
  const logoAlign = design.logoPosition.toLowerCase();
  const logoWidth = `${design.logoScale}px`;
  const accent = design.accentStyle === "Bar" ? `border-top:8px solid ${design.accentColor};` : design.accentStyle === "Stripe" ? `background-image:linear-gradient(90deg,${design.primaryColor} 0 82%,${design.accentColor} 82% 100%);` : `box-shadow:inset 0 -12px 0 ${design.accentColor};`;
  const background = design.backgroundMode === "Gradient" ? `linear-gradient(135deg,${design.backgroundColor},${design.tableHeaderColor})` : design.backgroundMode === "Image" && design.backgroundImage ? `linear-gradient(rgba(255,255,255,${1 - Math.min(.2, design.backgroundOpacity / 100)}),rgba(255,255,255,${1 - Math.min(.2, design.backgroundOpacity / 100)})),url('${design.backgroundImage.dataUri}') ${design.backgroundPosition.toLowerCase()} / ${design.backgroundFit.toLowerCase()} no-repeat` : design.backgroundColor;
  const rowBorder = design.tableStyle === "Minimal" ? "0" : `1px solid ${design.borderColor}`;
  const paid = invoice.transaction.status !== "pending";
  return `<!doctype html><html><head><meta charset="utf-8"/><style>@page{size:A4;margin:14mm}*{box-sizing:border-box}${font.css}body{margin:0;font-family:${font.family};font-size:12px;line-height:1.48;color:${design.textColor};background:${background}}.invoice{min-height:100%;padding:${spacing.pad};border:${bordered};border-radius:${radius(design)};background:${background}}.header{padding:${spacing.pad};border-radius:${radius(design)};color:#fff;text-align:${headerAlign};background-color:${design.primaryColor};${accent}}.logo{display:block;width:${logoWidth};max-height:58px;object-fit:contain;margin:0 ${logoAlign === "right" ? "0" : logoAlign === "center" ? "auto" : "auto 0"} 12px ${logoAlign === "right" ? "auto" : logoAlign === "center" ? "auto" : "0"}}.eyebrow{color:#E9E4FA;font-size:9px;letter-spacing:1.4px;font-weight:800;text-transform:uppercase}h1{margin:5px 0 0;font-size:32px;line-height:1;letter-spacing:-.7px}.meta{margin-top:16px;display:flex;gap:12px;justify-content:${design.headerAlignment === "Center" ? "center" : design.headerAlignment === "Right" ? "flex-end" : "flex-start"};color:#E9E4FA;font-size:10px;font-weight:700}.section{margin-top:${spacing.gap};break-inside:avoid}.two{display:flex;gap:30px}.half{flex:1}.right{text-align:right}.label{color:${design.accentColor};font-size:9px;letter-spacing:1.1px;font-weight:900;text-transform:uppercase;margin-bottom:7px}.title{font-size:15px;font-weight:800}.detail{opacity:.72}.status{display:inline-block;margin-top:7px;padding:4px 9px;border-radius:999px;font-size:10px;font-weight:800;color:${paid ? "#287251" : "#936315"};background:${paid ? "#E3F1EA" : "#FBF1DB"}}table{width:100%;border-collapse:separate;border-spacing:0;border:${bordered};border-radius:${radius(design)};overflow:hidden}thead{display:table-header-group}tr{break-inside:avoid;page-break-inside:avoid}th{background:${design.tableStyle === "Minimal" ? "transparent" : design.tableHeaderColor};padding:${spacing.row};font-size:9px;letter-spacing:.9px;text-transform:uppercase;text-align:left}th:last-child,td:last-child{text-align:right}td{padding:${spacing.row};border-top:${rowBorder};vertical-align:top}.item-title{font-weight:800}.item-detail{opacity:.68;font-size:10px}.summary{width:270px;margin:${spacing.gap} 0 0 auto;padding-top:9px;border-top:1px solid ${design.borderColor};break-inside:avoid}.sumrow{display:flex;justify-content:space-between;gap:20px;padding:5px 0}.sumrow span{opacity:.72}.total{margin-top:4px;padding-top:9px;border-top:1px solid ${design.borderColor};font-size:14px;font-weight:800}.balance{color:${invoice.balance ? design.accentColor : design.primaryColor}}.notes{margin-top:${spacing.gap};padding-top:13px;border-top:1px solid ${design.borderColor};break-inside:avoid}.notes p{margin:3px 0;opacity:.76;font-size:10px}.footer{margin-top:28px;opacity:.55;font-size:9px;text-align:center}</style></head><body><main class="invoice"><section class="header">${logo ? `<img class="logo" src="${logo.dataUri}"/>` : ""}<div class="eyebrow">${escapeHtml(businessProfile.name)}</div><h1>Invoice</h1><div class="meta"><span>${escapeHtml(invoice.invoiceNumber)}</span><span>Issued ${escapeHtml(invoice.issueDate)}</span></div></section><section class="section two"><div class="half"><div class="label">Bill to</div><div class="title">${escapeHtml(invoice.client.business)}</div><div>${escapeHtml(invoice.client.name)}</div><div class="detail">${escapeHtml(invoice.client.email || invoice.client.phone || "Client details on file")}</div></div><div class="half right"><div class="label">Payment</div><div class="title">${paid ? "Payment received" : "Payment due"}</div><div class="detail">${escapeHtml(invoice.transaction.method)}</div><div class="status">${paid ? "Paid" : "Pending"}</div></div></section><section class="section"><div class="label">Services</div><table><thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead><tbody>${invoice.lineItems.map((item) => `<tr><td><div class="item-title">${escapeHtml(item.description)}</div><div class="item-detail">${escapeHtml(item.detail)}</div></td><td>${item.quantity}</td><td>${formatNaira(item.rate)}</td><td>${formatNaira(item.amount)}</td></tr>`).join("")}</tbody></table></section><section class="summary"><div class="sumrow"><span>Subtotal</span><strong>${formatNaira(invoice.subtotal)}</strong></div>${invoice.discount ? `<div class="sumrow"><span>Discount</span><strong>−${formatNaira(invoice.discount)}</strong></div>` : ""}<div class="sumrow total"><span>Total</span><strong>${formatNaira(invoice.total)}</strong></div><div class="sumrow"><span>Amount paid</span><strong>${formatNaira(invoice.amountPaid)}</strong></div><div class="sumrow total balance"><span>Balance due</span><strong>${formatNaira(invoice.balance)}</strong></div></section>${businessProfile.paymentDetails ? `<section class="notes"><div class="label">Payment details</div><p>${escapeHtml(businessProfile.paymentDetails)}</p></section>` : ""}<section class="notes"><div class="label">Notes & terms</div><p>${escapeHtml(businessProfile.notes)}</p><p>${escapeHtml(businessProfile.terms)}</p></section><footer class="footer">${escapeHtml(businessProfile.name)}${businessProfile.website ? ` · ${escapeHtml(businessProfile.website)}` : ""}${businessProfile.taxId ? ` · Tax ID: ${escapeHtml(businessProfile.taxId)}` : ""}</footer></main></body></html>`;
}

export async function exportInvoicePdf(invoice: InvoiceData): Promise<InvoiceExportResult> {
  const native = await import("react-native");
  const Print = await import("expo-print");
  const Sharing = await import("expo-sharing");
  const html = invoiceHtml(invoice);
  const fileName = invoiceFilename(invoice);
  if (native.Platform.OS === "web") return downloadPdfInBrowser(invoice, fileName);
  const file = await Print.printToFileAsync({ html, width: 595, height: 842 });
  let savedUri = file.uri;
  try { const FileSystem = await import("expo-file-system/legacy"); const directory = FileSystem.cacheDirectory ?? FileSystem.documentDirectory; if (directory) { savedUri = `${directory}${fileName}`; await FileSystem.copyAsync({ from: file.uri, to: savedUri }); } } catch { savedUri = file.uri; }
  if (await Sharing.isAvailableAsync()) { await Sharing.shareAsync(savedUri, { UTI: ".pdf", mimeType: "application/pdf", dialogTitle: `Save ${fileName}` }); return { method: "shared", fileName }; }
  await Print.printAsync({ uri: savedUri }); return { method: "printed", fileName };
}
