import * as Crypto from "expo-crypto";

// A real UUID for every record, whether or not the person has signed in yet.
// Using the same id format everywhere means a workspace built before sign-in
// can be handed to Supabase later with no id remapping.
export function newId(): string {
  return Crypto.randomUUID();
}
