import { useRef } from "react";
import { PanResponder, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { palette } from "@/components/business-ui";

export function FormField({ label, value, onChangeText, placeholder, keyboardType = "default", multiline = false, secureTextEntry = false, autoCapitalize = "sentences" }: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  keyboardType?: "default" | "numeric" | "email-address" | "phone-pad";
  multiline?: boolean;
  secureTextEntry?: boolean;
  autoCapitalize?: "none" | "sentences" | "words" | "characters";
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#9AA09C"
        keyboardType={keyboardType}
        multiline={multiline}
        secureTextEntry={secureTextEntry}
        autoCapitalize={autoCapitalize}
        returnKeyType="done"
        style={[styles.input, multiline && styles.textarea]}
      />
    </View>
  );
}

export function ChoicePills({ options, value, onChange }: { options: string[]; value: string; onChange: (option: string) => void }) {
  return (
    <View style={styles.choiceWrap}>
      {options.map((option) => {
        const active = option === value;
        return (
          <TouchableOpacity key={option} activeOpacity={0.72} onPress={() => onChange(option)} style={[styles.choice, active && styles.choiceActive]}>
            <Text style={[styles.choiceText, active && styles.choiceTextActive]}>{option}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// A drag-to-resize slider with no native dependency (plain PanResponder), so
// it works the same in the app and on the web build with nothing extra to
// install or link before the first APK.
export function SizeSlider({ label, value, min, max, step = 1, onChange, formatValue }: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  formatValue?: (value: number) => string;
}) {
  const trackWidth = useRef(1);
  const setFromX = (x: number) => {
    const ratio = Math.min(1, Math.max(0, x / trackWidth.current));
    const raw = min + ratio * (max - min);
    const snapped = Math.round(raw / step) * step;
    onChange(Math.min(max, Math.max(min, snapped)));
  };
  const responder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (event) => setFromX(event.nativeEvent.locationX),
      onPanResponderMove: (event) => setFromX(event.nativeEvent.locationX),
    })
  ).current;
  const percent = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  return (
    <View style={styles.sliderWrap}>
      <View style={styles.sliderLabelRow}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.sliderValue}>{formatValue ? formatValue(value) : value}</Text>
      </View>
      <View
        style={styles.sliderTrack}
        onLayout={(event) => { trackWidth.current = Math.max(1, event.nativeEvent.layout.width); }}
        {...responder.panHandlers}
      >
        <View style={styles.sliderBase} />
        <View style={[styles.sliderFill, { width: `${percent}%` }]} />
        <View style={[styles.sliderThumb, { left: `${percent}%` }]} />
      </View>
    </View>
  );
}

export function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  sliderWrap: { gap: 9 },
  sliderLabelRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sliderValue: { color: palette.primary, fontSize: 12, lineHeight: 16, fontWeight: "800" },
  sliderTrack: { height: 30, justifyContent: "center" },
  sliderBase: { position: "absolute", left: 0, right: 0, height: 6, borderRadius: 3, backgroundColor: "#DCE6F2" },
  sliderFill: { position: "absolute", left: 0, height: 6, borderRadius: 3, backgroundColor: palette.primary },
  sliderThumb: { position: "absolute", width: 22, height: 22, borderRadius: 11, marginLeft: -11, backgroundColor: "#FFFFFF", borderWidth: 2, borderColor: palette.primary },
  section: { backgroundColor: palette.surface, borderRadius: 20, padding: 15, borderWidth: 1, borderColor: palette.fog, gap: 14 },
  sectionTitle: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" },
  field: { gap: 6 },
  label: { color: palette.muted, fontSize: 11, lineHeight: 14, letterSpacing: 0.4, fontWeight: "800", textTransform: "uppercase" },
  input: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "600", minHeight: 46, paddingHorizontal: 13, borderRadius: 13, borderWidth: 1, borderColor: palette.fog, backgroundColor: "#FAFCFF" },
  textarea: { minHeight: 94, paddingTop: 12, textAlignVertical: "top" },
  choiceWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  choice: { borderRadius: 99, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: palette.fog, backgroundColor: "#FAFCFF" },
  choiceActive: { backgroundColor: "#E6F1FF", borderColor: "#B4DEFF" },
  choiceText: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "700" },
  choiceTextActive: { color: palette.primary, fontWeight: "800" },
});
