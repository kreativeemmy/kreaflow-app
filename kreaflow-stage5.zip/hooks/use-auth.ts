import { useCallback, useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

export type AuthUser = { id: string; name: string | null; email: string | null };

function toAuthUser(user: User | null | undefined): AuthUser | null {
  if (!user) return null;
  const meta = user.user_metadata as Record<string, unknown> | undefined;
  const name = (meta?.full_name as string) ?? (meta?.name as string) ?? null;
  return { id: user.id, name, email: user.email ?? null };
}

// Turns Supabase's technical error text into something a non-developer can act on.
function friendlyAuthError(message: string): string {
  const m = message.toLowerCase();
  if (m.includes("invalid login credentials")) return "That email or password isn't right.";
  if (m.includes("user already registered") || m.includes("already been registered")) return "An account with this email already exists — try signing in instead.";
  if (m.includes("password should be at least") || m.includes("password is too short")) return "Password needs to be at least 6 characters.";
  if (m.includes("unable to validate email") || m.includes("invalid email")) return "That email address doesn't look right.";
  if (m.includes("network") || m.includes("fetch")) return "Couldn't reach the server — check your connection and try again.";
  if (m.includes("email not confirmed")) return "Please confirm your email before signing in.";
  return message;
}

export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (active) {
        setSession(data.session);
        setLoading(false);
      }
    });
    const { data: subscription } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setLoading(false);
    });
    return () => {
      active = false;
      subscription.subscription.unsubscribe();
    };
  }, []);

  const signUp = useCallback(async (email: string, password: string, fullName: string): Promise<{ ok: boolean; message: string }> => {
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: { data: { full_name: fullName.trim() } },
    });
    if (error) return { ok: false, message: friendlyAuthError(error.message) };
    // With email confirmation on, Supabase returns no session yet — tell the person to check their inbox.
    if (!data.session) return { ok: true, message: "Check your email to confirm your account, then come back and sign in." };
    return { ok: true, message: "Account created." };
  }, []);

  const signIn = useCallback(async (email: string, password: string): Promise<{ ok: boolean; message: string }> => {
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    return error ? { ok: false, message: friendlyAuthError(error.message) } : { ok: true, message: "Signed in." };
  }, []);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  return {
    user: toAuthUser(session?.user),
    isAuthenticated: !!session,
    loading,
    signUp,
    signIn,
    logout,
  };
}
