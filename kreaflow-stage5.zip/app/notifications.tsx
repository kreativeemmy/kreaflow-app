import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { Alert, ScrollView, StyleSheet, Switch, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, ScreenHeader, SectionHeading, palette } from "@/components/business-ui";

export default function NotificationSettingsScreen() {
  const { account, reminders } = useBusiness();
  const updateDevice = async (enabled: boolean) => {
    const count = await reminders.setDeviceEnabled(enabled);
    if (enabled && count === 0) Alert.alert("Notifications need permission", "Allow notifications on a physical device to schedule reminders for project deadlines and follow-ups.");
  };
  const enableCloud = async () => {
    const status = await reminders.enableCloud();
    if (status === "enabled") Alert.alert("Cloud push enabled", "This device is registered for cloud-delivered deadline and follow-up alerts.");
    if (status === "signin") Alert.alert("Sign in first", "Connect your account before enabling cloud-delivered notifications.");
    if (status === "device") Alert.alert("Use a physical native device", "Cloud push needs a native build on an iPhone or Android device, plus notification permission.");
    if (status === "project") Alert.alert("Publish required", "Cloud delivery will activate after the current app version is published and native push credentials are configured.");
  };
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Reminder settings" title="Notifications" subtitle="Use both device schedules and cloud delivery to stay ahead of work." onBack={() => router.back()} />
    <View style={styles.hero}><MaterialIcons name="notifications-active" size={25} color={palette.gold} /><View style={styles.heroCopy}><Text style={styles.heroTitle}>Two layers of reminders</Text><Text style={styles.heroDetail}>Device schedules cover this phone. Cloud delivery covers your signed-in workspace across registered devices.</Text></View></View>
    <View style={styles.section}><SectionHeading title="On this device" /><View style={styles.card}><View style={styles.row}><View style={styles.icon}><MaterialIcons name="phone-iphone" size={20} color={palette.primary} /></View><View style={styles.copy}><Text style={styles.rowTitle}>Scheduled reminders</Text><Text style={styles.rowDetail}>Notify at 9:00 AM for project deadlines and follow-ups</Text></View><Switch value={reminders.deviceEnabled} onValueChange={updateDevice} trackColor={{ false: "#D9DDD9", true: "#8BC7FA" }} thumbColor={reminders.deviceEnabled ? palette.primary : "#FFFFFF"} /></View></View></View>
    <View style={styles.section}><SectionHeading title="From the cloud" />{account.isAuthenticated ? <View style={styles.card}><View style={styles.row}><View style={styles.icon}><MaterialIcons name="cloud-sync" size={20} color={palette.moss} /></View><View style={styles.copy}><Text style={styles.rowTitle}>Cloud-delivered push</Text><Text style={styles.rowDetail}>{reminders.cloudEnabled ? "This account is registered for cloud alert delivery" : "Register this device for alerts after cloud changes"}</Text></View><Switch value={reminders.cloudEnabled} onValueChange={(value) => value ? enableCloud() : reminders.disableCloud()} trackColor={{ false: "#D9DDD9", true: "#B6DEC8" }} thumbColor={reminders.cloudEnabled ? palette.moss : "#FFFFFF"} /></View></View> : <EmptyState title="Sign in for cloud alerts" detail="Cloud push uses your secure account to send reminder alerts to registered devices." actionLabel="Open account" onAction={() => router.push("/account")} icon="cloud-queue" />}</View>
    <View style={styles.section}><SectionHeading title="What you’ll receive" /><View style={styles.detailCard}><TouchableOpacity style={styles.detailRow} activeOpacity={0.7}><MaterialIcons name="event" size={19} color={palette.coral} /><Text style={styles.detailText}>Project deadline alerts on the due date and the day before</Text></TouchableOpacity><TouchableOpacity style={styles.detailRow} activeOpacity={0.7}><MaterialIcons name="event-note" size={19} color={palette.primary} /><Text style={styles.detailText}>Client and lead follow-up reminders on the planned day</Text></TouchableOpacity></View></View>
  </ScrollView>;
}

const styles = StyleSheet.create({ page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 35 }, hero: { marginHorizontal: 20, marginTop: 3, padding: 16, borderRadius: 21, backgroundColor: "#FBF1DB", flexDirection: "row", alignItems: "flex-start", gap: 11 }, heroCopy: { flex: 1, gap: 3 }, heroTitle: { color: "#70501E", fontSize: 15, lineHeight: 20, fontWeight: "800" }, heroDetail: { color: "#8A672D", fontSize: 12, lineHeight: 18, fontWeight: "600" }, section: { marginTop: 25, paddingHorizontal: 20 }, card: { borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog }, row: { padding: 14, flexDirection: "row", alignItems: "center", gap: 10 }, icon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF" }, copy: { flex: 1, gap: 2 }, rowTitle: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "800" }, rowDetail: { color: palette.muted, fontSize: 10, lineHeight: 15, fontWeight: "600" }, detailCard: { borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, overflow: "hidden" }, detailRow: { padding: 14, flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: 1, borderBottomColor: palette.fog }, detailText: { flex: 1, color: palette.ink, fontSize: 12, lineHeight: 17, fontWeight: "700" }, });
