import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { Alert, ScrollView, StyleSheet, Switch, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, PrimaryButton, ScreenHeader, SectionHeading, palette } from "@/components/business-ui";

export default function AccountScreen() {
  const { account, cloudSync } = useBusiness();

  const setSync = async (enabled: boolean) => {
    const success = await cloudSync.setEnabled(enabled);
    if (!success) {
      Alert.alert("Sign in first", "Turn this on after you sign in — your changes will then save to your account automatically.");
      return;
    }
    if (enabled) Alert.alert("Cloud sync enabled", "Your workspace changes now save to your account automatically.");
  };

  const backupNow = async () => {
    const success = await cloudSync.syncNow();
    Alert.alert(success ? "Up to date" : "Couldn't sync", success ? "Your workspace is saved to your account." : "Sign in first, then try again with an internet connection.");
  };

  const restore = () => {
    Alert.alert("Restore cloud backup?", "This replaces the current local workspace with the last saved cloud backup on this account.", [
      { text: "Cancel", style: "cancel" },
      { text: "Restore", style: "destructive", onPress: async () => {
        const success = await cloudSync.restoreFromCloud();
        Alert.alert(success ? "Backup restored" : "Nothing to restore", success ? "Your saved cloud workspace is now available on this device." : "No saved backup was found for this account.");
      } },
    ]);
  };

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="KreaFlow account & backup" title="Your workspace" subtitle="Sign in to protect your local business system across devices." onBack={() => router.back()} />
    {account.loading ? <View style={styles.loading}><Text style={styles.loadingText}>Checking account…</Text></View> : account.isAuthenticated ? <View style={styles.profile}><View style={styles.avatar}><Text style={styles.avatarText}>{(account.name ?? "E").slice(0, 1).toUpperCase()}</Text></View><View style={styles.profileCopy}><Text style={styles.profileTitle}>{account.name ?? "Signed-in user"}</Text><Text style={styles.profileDetail}>{account.email ?? "Secure account connected"}</Text><Text style={styles.profileStatus}>Secure sign-in active</Text></View><MaterialIcons name="verified-user" size={23} color={palette.moss} /></View> : <EmptyState title="Protect your workspace" detail="Sign in to create a private cloud backup, restore data on another device, and enable cloud push reminders." actionLabel="Sign in securely" onAction={() => router.push("/onboarding")} icon="lock" />}
    <View style={styles.section}><SectionHeading title="Cloud backup" /><View style={styles.card}><View style={styles.row}><View style={styles.rowIcon}><MaterialIcons name="cloud-done" size={21} color={palette.primary} /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>Automatic cloud sync</Text><Text style={styles.rowDetail}>{cloudSync.enabled ? "Workspace changes back up automatically" : "Keep data only on this device"}</Text></View><Switch value={cloudSync.enabled} onValueChange={setSync} trackColor={{ false: "#D9DDD9", true: "#8BC7FA" }} thumbColor={cloudSync.enabled ? palette.primary : "#FFFFFF"} /></View><View style={styles.cardDivider} /><TouchableOpacity activeOpacity={0.72} onPress={backupNow} style={styles.actionRow}><View style={styles.actionCopy}><Text style={styles.rowTitle}>Sync now</Text><Text style={styles.rowDetail}>{cloudSync.lastBackupAt ? `Last saved ${new Date(cloudSync.lastBackupAt).toLocaleString()}` : "Save any changes to your account right now"}</Text></View><MaterialIcons name="backup" size={20} color={palette.primary} /></TouchableOpacity><View style={styles.cardDivider} /><TouchableOpacity activeOpacity={0.72} onPress={restore} style={styles.actionRow}><View style={styles.actionCopy}><Text style={styles.rowTitle}>Restore cloud backup</Text><Text style={styles.rowDetail}>Replace this device’s local workspace with your saved snapshot</Text></View><MaterialIcons name="restore" size={20} color={palette.primary} /></TouchableOpacity></View></View>
    <View style={styles.section}><SectionHeading title="Privacy" /><View style={styles.privacy}><MaterialIcons name="shield" size={21} color={palette.moss} /><Text style={styles.privacyText}>Your cloud backup is associated with your authenticated account. It is not shared with your clients or other users.</Text></View></View>
    {account.isAuthenticated ? <View style={styles.signOut}><PrimaryButton label="Sign out" icon="logout" tone="coral" onPress={() => account.signOut()} /></View> : null}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 35 }, loading: { margin: 20, padding: 18, borderRadius: 19, backgroundColor: palette.surface }, loadingText: { color: palette.muted, fontSize: 13, lineHeight: 18, fontWeight: "700" }, profile: { marginHorizontal: 20, marginTop: 3, padding: 17, borderRadius: 22, backgroundColor: palette.ink, flexDirection: "row", gap: 12, alignItems: "center" }, avatar: { width: 45, height: 45, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#E3F1EA" }, avatarText: { color: palette.moss, fontSize: 17, lineHeight: 22, fontWeight: "800" }, profileCopy: { flex: 1, gap: 2 }, profileTitle: { color: "#FFFFFF", fontSize: 15, lineHeight: 20, fontWeight: "800" }, profileDetail: { color: "#D0D9D3", fontSize: 11, lineHeight: 15, fontWeight: "600" }, profileStatus: { color: "#8BD0AB", fontSize: 10, lineHeight: 14, fontWeight: "800", marginTop: 2 }, section: { marginTop: 25, paddingHorizontal: 20 }, card: { borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, overflow: "hidden" }, row: { padding: 14, flexDirection: "row", alignItems: "center", gap: 10 }, rowIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF" }, rowCopy: { flex: 1, gap: 2 }, rowTitle: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "800" }, rowDetail: { color: palette.muted, fontSize: 10, lineHeight: 15, fontWeight: "600" }, cardDivider: { height: 1, backgroundColor: palette.fog }, actionRow: { padding: 14, flexDirection: "row", alignItems: "center", gap: 10 }, actionCopy: { flex: 1, gap: 2 }, privacy: { padding: 14, borderRadius: 18, backgroundColor: "#E3F1EA", flexDirection: "row", alignItems: "flex-start", gap: 10 }, privacyText: { flex: 1, color: "#47715D", fontSize: 12, lineHeight: 18, fontWeight: "600" }, signOut: { marginTop: 25, paddingHorizontal: 20 },
});
