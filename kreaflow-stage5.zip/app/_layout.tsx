import * as Notifications from "expo-notifications";
import { router, Stack, useSegments } from "expo-router";
import { useEffect } from "react";
import { StatusBar } from "expo-status-bar";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import "../global.css";
import { BusinessProvider, useBusiness } from "@/components/business-provider";
import { palette } from "@/components/business-ui";
import { ThemeProvider } from "@/lib/theme-provider";

function NotificationNavigation() {
  useEffect(() => {
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const url = response.notification.request.content.data?.url;
      if (typeof url === "string") router.push(url as never);
    });
    return () => subscription.remove();
  }, []);
  return null;
}

function WorkspaceGate() {
  const segments = useSegments();
  const { hydrated, account, needsOnboarding } = useBusiness();
  useEffect(() => {
    if (!hydrated || account.loading || !needsOnboarding || segments[0] === "onboarding") return;
    router.replace("/onboarding");
  }, [hydrated, account.loading, needsOnboarding, segments]);
  return null;
}

// Keeps every screen below the phone's clock/battery bar so header buttons are tappable.
function SafeFrame({ children }: { children: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  return <View style={{ flex: 1, paddingTop: insets.top, backgroundColor: palette.paper }}>{children}</View>;
}

export default function RootLayout() {
  return (
    <ThemeProvider>
      <BusinessProvider>
        <NotificationNavigation />
        <WorkspaceGate />
        <SafeFrame>
        <Stack screenOptions={{ headerShown: false, animation: "slide_from_right" }}>
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="workspaces" />
          <Stack.Screen name="onboarding" />
          <Stack.Screen name="invoices" />
        </Stack>
        </SafeFrame>
        <StatusBar style="dark" />
      </BusinessProvider>
    </ThemeProvider>
  );
}
