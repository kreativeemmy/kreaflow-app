import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { ChoicePills, FormField, FormSection } from "@/components/form-ui";
import { EmptyState, PrimaryButton, ScreenHeader, SectionHeading, palette } from "@/components/business-ui";
import { formatNaira } from "@/lib/business-metrics";
import { LEAD_STAGES, type LeadStage } from "@/lib/business-types";

export default function LeadDetailScreen() {
  const params = useLocalSearchParams<{ id: string }>();
  const { leads, moveLead, updateLead, addClient } = useBusiness();
  const lead = leads.find((item) => item.id === params.id);
  const [lostReason, setLostReason] = useState("");
  if (!lead) return <View style={styles.missing}><EmptyState title="Lead not found" detail="This lead may have been removed from your local workspace." actionLabel="Back to pipeline" onAction={() => router.replace("/leads")} /></View>;
  const isWon = lead.status === "Won";
  const convert = () => {
    const clientId = addClient({ name: lead.name, business: lead.business, phone: lead.contact, email: lead.contact.includes("@") ? lead.contact : "", handle: "", notes: lead.notes, status: "Active" });
    router.replace({ pathname: "/create", params: { type: "project", clientId } });
  };
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Lead workspace" title={lead.business} subtitle={lead.name} onBack={() => router.back()} />
    <View style={styles.profile}><View style={styles.leadIcon}><MaterialIcons name="auto-graph" color={palette.coral} size={24} /></View><View style={styles.profileCopy}><Text style={styles.service}>{lead.service}</Text><Text style={styles.contact}>{lead.contact}</Text><Text style={styles.source}>Source: {lead.source}</Text></View><Text style={styles.value}>{formatNaira(lead.value)}</Text></View>
    <View style={styles.section}><SectionHeading title="Pipeline stage" /><FormSection title="Move this opportunity"><ChoicePills options={LEAD_STAGES} value={lead.status} onChange={(status) => moveLead(lead.id, status as LeadStage)} /></FormSection>{lead.status === "Lost" ? <View style={styles.lostCard}><Text style={styles.lostTitle}>Marked as lost</Text><Text style={styles.lostDetail}>Capture a reason so future pipeline decisions become clearer.</Text><FormField label="Reason" value={lostReason || lead.lostReason || ""} onChangeText={setLostReason} placeholder="e.g. Budget paused" /><TouchableOpacity onPress={() => updateLead(lead.id, { lostReason })} style={styles.saveReason} activeOpacity={0.72}><Text style={styles.saveReasonText}>Save reason</Text></TouchableOpacity></View> : null}</View>
    <View style={styles.section}><SectionHeading title="Follow-up" /><View style={styles.followCard}><View style={styles.followIcon}><MaterialIcons name="event-note" color={palette.primary} size={20} /></View><View style={styles.followCopy}><Text style={styles.followLabel}>NEXT FOLLOW-UP</Text><Text style={styles.followDate}>{lead.nextFollowUp}</Text></View><TouchableOpacity onPress={() => router.push({ pathname: "/create", params: { type: "followup" } })} style={styles.editFollow} activeOpacity={0.72}><Text style={styles.editFollowText}>Add one</Text></TouchableOpacity></View></View>
    <View style={styles.section}><SectionHeading title="Conversation notes" /><View style={styles.notes}><Text style={styles.notesText}>{lead.notes || "No notes have been captured for this lead yet."}</Text></View></View>
    {isWon ? <View style={styles.convertWrap}><View style={styles.convertCard}><MaterialIcons name="celebration" size={24} color={palette.moss} /><Text style={styles.convertTitle}>This lead is ready to become a client.</Text><Text style={styles.convertDetail}>Create the relationship record, then begin their first project without duplicating their core details.</Text><PrimaryButton label="Convert to client & project" icon="arrow-forward" onPress={convert} /></View></View> : null}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 34 }, missing: { flex: 1, padding: 20, backgroundColor: palette.paper, justifyContent: "center" }, profile: { marginHorizontal: 20, marginTop: 3, padding: 18, borderRadius: 22, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, flexDirection: "row", alignItems: "flex-start", gap: 11 }, leadIcon: { width: 45, height: 45, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#FDE9E4" }, profileCopy: { flex: 1, gap: 3 }, service: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" }, contact: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" }, source: { color: "#8C938F", fontSize: 10, lineHeight: 14, fontWeight: "700" }, value: { color: palette.primary, fontSize: 15, lineHeight: 20, fontWeight: "800" }, section: { marginTop: 25, paddingHorizontal: 20 }, lostCard: { marginTop: 10, padding: 14, borderRadius: 16, backgroundColor: "#FDE9E4", gap: 7 }, lostTitle: { color: "#9E4434", fontSize: 13, lineHeight: 18, fontWeight: "800" }, lostDetail: { color: "#AD5B4B", fontSize: 11, lineHeight: 16, fontWeight: "600" }, saveReason: { alignSelf: "flex-start", paddingVertical: 5 }, saveReasonText: { color: "#9E4434", fontSize: 11, lineHeight: 15, fontWeight: "800" }, followCard: { padding: 14, borderRadius: 20, backgroundColor: "#E6F1FF", flexDirection: "row", alignItems: "center", gap: 10 }, followIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#DFD7F1" }, followCopy: { flex: 1, gap: 2 }, followLabel: { color: "#716987", fontSize: 9, lineHeight: 12, letterSpacing: 0.6, fontWeight: "800" }, followDate: { color: palette.primary, fontSize: 14, lineHeight: 19, fontWeight: "800" }, editFollow: { paddingVertical: 6 }, editFollowText: { color: palette.primary, fontSize: 11, lineHeight: 15, fontWeight: "800" }, notes: { padding: 15, borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog }, notesText: { color: palette.muted, fontSize: 13, lineHeight: 20, fontWeight: "600" }, convertWrap: { paddingHorizontal: 20, marginTop: 25 }, convertCard: { padding: 17, borderRadius: 22, backgroundColor: "#E3F1EA", gap: 8 }, convertTitle: { color: "#24533F", fontSize: 16, lineHeight: 21, fontWeight: "800" }, convertDetail: { color: "#47715D", fontSize: 12, lineHeight: 18, fontWeight: "600", marginBottom: 5 },
});
