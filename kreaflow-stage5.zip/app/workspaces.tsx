import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { PrimaryButton, ScreenHeader, palette } from "@/components/business-ui";
import { FormField, FormSection } from "@/components/form-ui";

export default function WorkspacesScreen() {
  const { activeWorkspace, workspaces, switchWorkspace, createWorkspace } = useBusiness();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [industry, setIndustry] = useState("");
  const create = () => {
    if (!name.trim()) { Alert.alert("Workspace name required", "Enter the business or workspace name to continue."); return; }
    createWorkspace({ name: name.trim(), businessType: businessType.trim(), industry: industry.trim() });
    setCreating(false); setName(""); setBusinessType(""); setIndustry("");
    router.push("/onboarding");
  };
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="KreaFlow workspaces" title="Your workspaces" subtitle="Keep every business, brand, client list, and invoice setup separate." onBack={() => router.back()} />
    <View style={styles.intro}><MaterialIcons name="account-tree" size={23} color="#044BB2" /><Text style={styles.introText}>Switch instantly without signing out. Each workspace has its own clients, projects, payments, branding, invoices, goals, and settings.</Text></View>
    <View style={styles.list}>{workspaces.map((workspace) => <TouchableOpacity key={workspace.id} activeOpacity={0.74} onPress={() => { switchWorkspace(workspace.id); router.back(); }} style={[styles.workspace, workspace.id === activeWorkspace?.id && styles.workspaceActive]}><View style={styles.mark}><Text style={styles.markText}>{workspace.name.slice(0, 1).toUpperCase()}</Text></View><View style={styles.copy}><Text style={styles.name}>{workspace.name}</Text><Text style={styles.detail}>{workspace.id === activeWorkspace?.id ? "Active workspace" : workspace.onboardingComplete ? "Ready to switch" : "Setup incomplete"}</Text></View>{workspace.id === activeWorkspace?.id ? <MaterialIcons name="check-circle" size={23} color={palette.moss} /> : <MaterialIcons name="arrow-forward" size={21} color={palette.muted} />}</TouchableOpacity>)}</View>
    {creating ? <View style={styles.form}><FormSection title="Create workspace"><FormField label="Workspace name" value={name} onChangeText={setName} placeholder="e.g. Jane Visuals" /><FormField label="Business type" value={businessType} onChangeText={setBusinessType} placeholder="e.g. Photography studio" /><FormField label="Industry or category" value={industry} onChangeText={setIndustry} placeholder="e.g. Creative services" /></FormSection><View style={styles.formActions}><PrimaryButton label="Continue setup" icon="arrow-forward" onPress={create} /><TouchableOpacity onPress={() => setCreating(false)} activeOpacity={0.72} style={styles.cancel}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity></View></View> : <TouchableOpacity activeOpacity={0.78} onPress={() => setCreating(true)} style={styles.create}><MaterialIcons name="add-business" size={22} color={palette.primary} /><View style={styles.copy}><Text style={styles.createTitle}>Create workspace</Text><Text style={styles.createDetail}>Set up another business, brand, or freelance operation.</Text></View><MaterialIcons name="chevron-right" size={22} color={palette.primary} /></TouchableOpacity>}
    {activeWorkspace ? <TouchableOpacity activeOpacity={0.72} onPress={() => router.push("/invoice-design")} style={styles.manageBrand}><MaterialIcons name="palette" size={19} color="#044BB2" /><Text style={styles.manageBrandText}>Edit {activeWorkspace.name} workspace branding</Text><MaterialIcons name="arrow-forward" size={18} color="#044BB2" /></TouchableOpacity> : null}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 35 },
  intro: { margin: 20, marginTop: 0, padding: 15, borderRadius: 18, gap: 10, flexDirection: "row", backgroundColor: "#EAF4FF", borderWidth: 1, borderColor: "#B4DEFF" },
  introText: { flex: 1, color: "#32516E", fontSize: 12, lineHeight: 18, fontWeight: "600" },
  list: { paddingHorizontal: 20, gap: 9 },
  workspace: { minHeight: 70, padding: 14, borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, flexDirection: "row", alignItems: "center", gap: 12 },
  workspaceActive: { backgroundColor: "#F2F8FF", borderColor: "#8BC7FA" },
  mark: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#DDEEFF", alignItems: "center", justifyContent: "center" },
  markText: { color: "#044BB2", fontSize: 17, lineHeight: 22, fontWeight: "900" },
  copy: { flex: 1, gap: 2 }, name: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "800" }, detail: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" },
  create: { margin: 20, padding: 15, borderRadius: 20, borderStyle: "dashed", borderWidth: 1.5, borderColor: "#8BC7FA", flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: "#F8FBFF" },
  createTitle: { color: palette.primary, fontSize: 14, lineHeight: 19, fontWeight: "900" }, createDetail: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" },
  form: { margin: 20, padding: 15, borderRadius: 20, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog, gap: 15 }, formActions: { gap: 10 }, cancel: { minHeight: 36, alignItems: "center", justifyContent: "center" }, cancelText: { color: palette.muted, fontSize: 12, lineHeight: 16, fontWeight: "800" },
  manageBrand: { marginHorizontal: 20, minHeight: 48, paddingHorizontal: 13, borderRadius: 15, flexDirection: "row", gap: 8, alignItems: "center", backgroundColor: "#EAF4FF" }, manageBrandText: { flex: 1, color: "#044BB2", fontSize: 12, lineHeight: 17, fontWeight: "800" },
});
