import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, ScreenHeader, palette } from "@/components/business-ui";
import { formatNaira } from "@/lib/business-metrics";
import { LEAD_STAGES } from "@/lib/business-types";

const visibleStages = LEAD_STAGES.filter((stage) => stage !== "Lost");

export default function LeadsScreen() {
  const { leads } = useBusiness();
  const openLeads = leads.filter((lead) => lead.status !== "Lost");
  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <ScreenHeader eyebrow="Opportunity desk" title="Pipeline" subtitle="Keep every possible collaboration moving with intent." onSearch={() => router.push("/search")} action={<TouchableOpacity activeOpacity={0.8} onPress={() => router.push("/create?type=lead")} style={styles.addButton}><MaterialIcons name="add-chart" color="#FFF" size={18} /></TouchableOpacity>} />
      <View style={styles.pipelineIntro}><View><Text style={styles.introLabel}>OPEN PIPELINE</Text><Text style={styles.introValue}>{formatNaira(openLeads.reduce((total, lead) => total + lead.value, 0))}</Text></View><View style={styles.introStat}><Text style={styles.introStatValue}>{openLeads.length}</Text><Text style={styles.introStatLabel}>active leads</Text></View></View>
      {openLeads.length ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.board}>
        {visibleStages.map((stage) => {
          const stageLeads = leads.filter((lead) => lead.status === stage);
          return <View key={stage} style={styles.column}><View style={styles.columnHeader}><Text style={styles.columnTitle}>{stage}</Text><Text style={styles.count}>{stageLeads.length}</Text></View>{stageLeads.length ? stageLeads.map((lead) => <TouchableOpacity key={lead.id} style={styles.leadCard} activeOpacity={0.74} onPress={() => router.push({ pathname: "/lead/[id]", params: { id: lead.id } })}><Text style={styles.business}>{lead.business}</Text><Text style={styles.person}>{lead.name}</Text><Text style={styles.service}>{lead.service}</Text><View style={styles.cardFoot}><Text style={styles.value}>{formatNaira(lead.value)}</Text><Text style={styles.followUp}>{lead.nextFollowUp}</Text></View></TouchableOpacity>) : <View style={styles.emptyColumn}><Text style={styles.emptyColumnText}>Clear lane</Text></View>}</View>;
        })}
      </ScrollView> : <View style={styles.emptyWrap}><EmptyState title="Your pipeline is clear" detail="Add a lead as soon as a new enquiry appears, then move it through the conversation." actionLabel="Add lead" onAction={() => router.push("/create?type=lead")} icon="waterfall-chart" /></View>}
      <View style={styles.tip}><MaterialIcons name="lightbulb-outline" color={palette.gold} size={19} /><Text style={styles.tipText}>Tap a lead to update its stage, capture the next follow-up, or turn a win into a client and project.</Text></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 30 }, addButton: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: palette.primary, marginTop: 3 },
  pipelineIntro: { marginHorizontal: 20, marginTop: 4, borderRadius: 21, padding: 17, backgroundColor: palette.ink, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, introLabel: { color: "#B5BFBA", fontSize: 10, lineHeight: 14, fontWeight: "800", letterSpacing: 0.9 }, introValue: { color: "#FFFFFF", fontSize: 28, lineHeight: 34, fontWeight: "800", letterSpacing: -0.6, marginTop: 3 }, introStat: { borderRadius: 15, paddingVertical: 8, paddingHorizontal: 11, backgroundColor: "#2D3934", alignItems: "center" }, introStatValue: { color: "#FFFFFF", fontSize: 16, lineHeight: 20, fontWeight: "800" }, introStatLabel: { color: "#C7D0CB", fontSize: 9, lineHeight: 12, fontWeight: "700" },
  board: { paddingHorizontal: 20, paddingTop: 20, gap: 12 }, column: { width: 224, gap: 9 }, columnHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 4 }, columnTitle: { color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "800" }, count: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "800", width: 22, height: 22, borderRadius: 11, textAlign: "center", paddingTop: 3, backgroundColor: "#E7E8E4" }, leadCard: { backgroundColor: palette.surface, borderRadius: 18, borderWidth: 1, borderColor: palette.fog, padding: 14, gap: 3 }, business: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "800" }, person: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "700" }, service: { color: "#63706A", fontSize: 11, lineHeight: 15, fontWeight: "600", paddingTop: 4 }, cardFoot: { borderTopColor: palette.fog, borderTopWidth: 1, paddingTop: 10, marginTop: 7, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, value: { color: palette.primary, fontSize: 12, lineHeight: 16, fontWeight: "800" }, followUp: { color: palette.coral, fontSize: 10, lineHeight: 14, fontWeight: "800" }, emptyColumn: { height: 78, borderRadius: 18, borderWidth: 1, borderStyle: "dashed", borderColor: "#CDD1CD", alignItems: "center", justifyContent: "center" }, emptyColumnText: { color: "#A0A6A2", fontSize: 12, lineHeight: 16, fontWeight: "700" }, emptyWrap: { marginHorizontal: 20, marginTop: 18 }, tip: { margin: 20, marginTop: 24, padding: 14, borderRadius: 16, backgroundColor: "#FBF1DB", flexDirection: "row", gap: 10, alignItems: "flex-start" }, tipText: { flex: 1, color: "#78571F", fontSize: 12, lineHeight: 17, fontWeight: "600" },
});
