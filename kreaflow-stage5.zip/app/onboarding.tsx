import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { PrimaryButton, ProgressBar, palette } from "@/components/business-ui";
import { FormField, FormSection } from "@/components/form-ui";
import { useAuth } from "@/hooks/use-auth";
import { pickInvoiceImage } from "@/lib/invoice-assets";

const STEPS = ["Account", "Workspace", "Brand", "Invoice", "Finish"];
const validHex = (value: string) => /^#[0-9A-Fa-f]{6}$/.test(value);

export default function OnboardingScreen() {
  const { account, activeWorkspace, businessProfile, invoiceDesign, createWorkspace, updateBusinessProfile, updateInvoiceDesign, completeOnboarding } = useBusiness();
  const { signUp, signIn } = useAuth();
  const [step, setStep] = useState(0);
  const [authMode, setAuthMode] = useState<"signup" | "signin">("signup");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState("");
  const [authNotice, setAuthNotice] = useState("");

  const submitAuth = async () => {
    setAuthError(""); setAuthNotice("");
    if (!authEmail.trim() || !authPassword) { setAuthError("Enter your email and password."); return; }
    if (authMode === "signup" && !authName.trim()) { setAuthError("Enter your name."); return; }
    if (authPassword.length < 6) { setAuthError("Password must be at least 6 characters."); return; }
    setAuthBusy(true);
    const result = authMode === "signup" ? await signUp(authEmail, authPassword, authName) : await signIn(authEmail, authPassword);
    setAuthBusy(false);
    if (!result.ok) { setAuthError(result.message); return; }
    if (authMode === "signup" && !result.message.toLowerCase().includes("confirm")) { setAuthNotice(""); } else if (authMode === "signup") { setAuthNotice(result.message); }
  };
  const [workspaceName, setWorkspaceName] = useState(activeWorkspace?.name ?? "");
  const [businessType, setBusinessType] = useState(businessProfile.businessType);
  const [industry, setIndustry] = useState(businessProfile.industry);
  const [email, setEmail] = useState(businessProfile.email);
  const [phone, setPhone] = useState(businessProfile.phone);
  const [description, setDescription] = useState(businessProfile.description);
  const [website, setWebsite] = useState(businessProfile.website);
  const [social, setSocial] = useState(businessProfile.social);
  const [primary, setPrimary] = useState(invoiceDesign.primaryColor);
  const [accent, setAccent] = useState(invoiceDesign.accentColor);
  const [prefix, setPrefix] = useState(businessProfile.invoicePrefix);
  const [currency, setCurrency] = useState(businessProfile.currency);
  const [paymentDetails, setPaymentDetails] = useState(businessProfile.paymentDetails);
  const [terms, setTerms] = useState(businessProfile.terms);

  const saveWorkspace = () => {
    if (!workspaceName.trim()) { Alert.alert("Workspace name required", "Enter the business or workspace name to continue."); return; }
    if (!activeWorkspace) createWorkspace({ name: workspaceName.trim(), businessType: businessType.trim(), industry: industry.trim(), email: email.trim(), phone: phone.trim(), description: description.trim(), website: website.trim(), social: social.trim() });
    else updateBusinessProfile({ name: workspaceName.trim(), businessType: businessType.trim(), industry: industry.trim(), email: email.trim(), phone: phone.trim(), description: description.trim(), website: website.trim(), social: social.trim() });
    setStep(2);
  };
  const saveBrand = async () => {
    if (!validHex(primary) || !validHex(accent)) { Alert.alert("Use valid HEX colours", "Enter six-digit values such as #0562E9."); return; }
    updateInvoiceDesign({ primaryColor: primary.toUpperCase(), accentColor: accent.toUpperCase(), tableHeaderColor: `${primary.toUpperCase()}1F` });
    setStep(3);
  };
  const uploadLogo = async () => { try { const logo = await pickInvoiceImage("logo"); if (logo) updateBusinessProfile({ logo }); } catch { Alert.alert("Couldn’t import logo", "Choose a PNG, JPG, JPEG, or SVG file under 700 KB."); } };
  const saveInvoice = () => { updateBusinessProfile({ invoicePrefix: prefix.trim().toUpperCase() || "INV", currency: currency.trim().toUpperCase().slice(0, 3) || "NGN", paymentDetails: paymentDetails.trim(), terms: terms.trim() }); setStep(4); };
  const finish = () => { completeOnboarding(); router.replace("/(tabs)"); };
  const progress = ((step + 1) / STEPS.length) * 100;

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
    <View style={styles.brand}><View style={styles.brandMark}><Text style={styles.brandMarkText}>K</Text></View><View><Text style={styles.brandName}>KreaFlow</Text><Text style={styles.brandTagline}>Your business, in flow.</Text></View></View>
    <View style={styles.stepLine}><Text style={styles.stepCaption}>STEP {step + 1} OF {STEPS.length}</Text><Text style={styles.stepName}>{STEPS[step]}</Text></View><ProgressBar value={progress} tone="primary" height={7} />
    {step === 0 ? <View style={styles.hero}><View style={styles.heroIcon}><MaterialIcons name="lock" size={28} color="#044BB2" /></View><Text style={styles.title}>Create your KreaFlow account</Text><Text style={styles.subtitle}>Start with a secure account, then create a private workspace for your business. You can use the same account for multiple workspaces.</Text>{account.loading ? <Text style={styles.loading}>Checking your account…</Text> : account.isAuthenticated ? <View style={styles.accountReady}><MaterialIcons name="verified-user" size={21} color={palette.moss} /><View><Text style={styles.accountReadyTitle}>{account.name ?? "Account connected"}</Text><Text style={styles.accountReadyDetail}>{account.email ?? "Secure sign-in active"}</Text></View></View> : <View style={styles.authCard}>
        <View style={styles.authTabs}>
          <TouchableOpacity onPress={() => { setAuthMode("signup"); setAuthError(""); setAuthNotice(""); }} style={[styles.authTab, authMode === "signup" && styles.authTabActive]}><Text style={[styles.authTabText, authMode === "signup" && styles.authTabTextActive]}>Sign up</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => { setAuthMode("signin"); setAuthError(""); setAuthNotice(""); }} style={[styles.authTab, authMode === "signin" && styles.authTabActive]}><Text style={[styles.authTabText, authMode === "signin" && styles.authTabTextActive]}>Sign in</Text></TouchableOpacity>
        </View>
        {authMode === "signup" ? <FormField label="Your name" value={authName} onChangeText={setAuthName} placeholder="e.g. Emmanuel" /> : null}
        <FormField label="Email" value={authEmail} onChangeText={setAuthEmail} keyboardType="email-address" autoCapitalize="none" placeholder="you@email.com" />
        <FormField label="Password" value={authPassword} onChangeText={setAuthPassword} secureTextEntry placeholder="At least 6 characters" />
        {authError ? <Text style={styles.authErrorText}>{authError}</Text> : null}
        {authNotice ? <Text style={styles.authNoticeText}>{authNotice}</Text> : null}
        <PrimaryButton label={authBusy ? "Please wait…" : authMode === "signup" ? "Create account" : "Sign in"} icon="arrow-forward" onPress={submitAuth} disabled={authBusy} />
      </View>}{account.isAuthenticated ? <PrimaryButton label="Continue to workspace" icon="arrow-forward" onPress={() => setStep(1)} /> : null}</View> : null}
    {step === 1 ? <View style={styles.form}><Text style={styles.title}>Create your workspace</Text><Text style={styles.subtitle}>Your workspace is where you manage a business, brand, or freelance operation. Optional details can be completed later.</Text><FormSection title="Business details"><FormField label="Workspace name *" value={workspaceName} onChangeText={setWorkspaceName} placeholder="e.g. Kreativeemmy" /><FormField label="Business type" value={businessType} onChangeText={setBusinessType} placeholder="e.g. Social media brand design" /><FormField label="Industry or category" value={industry} onChangeText={setIndustry} placeholder="e.g. Creative services" /><FormField label="Business email" value={email} onChangeText={setEmail} keyboardType="email-address" /><FormField label="Phone number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" /><FormField label="Business description" value={description} onChangeText={setDescription} multiline /><FormField label="Website" value={website} onChangeText={setWebsite} /><FormField label="Social media" value={social} onChangeText={setSocial} /></FormSection><PrimaryButton label="Continue to brand" icon="arrow-forward" onPress={saveWorkspace} /><TouchableOpacity onPress={() => setStep(2)} style={styles.skip}><Text style={styles.skipText}>Skip optional details for now</Text></TouchableOpacity></View> : null}
    {step === 2 ? <View style={styles.form}><Text style={styles.title}>Set up your brand</Text><Text style={styles.subtitle}>These workspace colours and logo will shape invoices, PDFs, and business identity. You can refine them later.</Text><View style={styles.logoCard}><View style={styles.logoPreview}>{businessProfile.logo ? <MaterialIcons name="image" size={25} color="#044BB2" /> : <Text style={styles.logoLetter}>{(activeWorkspace?.name ?? workspaceName ?? "K").slice(0, 1).toUpperCase()}</Text>}</View><View style={styles.logoCopy}><Text style={styles.logoTitle}>{businessProfile.logo ? businessProfile.logo.name : "Workspace logo"}</Text><Text style={styles.logoDetail}>PNG, JPG, JPEG, or SVG · optional</Text></View><TouchableOpacity onPress={uploadLogo} style={styles.import}><Text style={styles.importText}>{businessProfile.logo ? "Change" : "Upload"}</Text></TouchableOpacity></View><FormSection title="Brand colours"><Text style={styles.fieldLabel}>Primary colour</Text><View style={styles.colorRow}><View style={[styles.swatch, { backgroundColor: validHex(primary) ? primary : "#FFFFFF" }]} /><TextInput value={primary} onChangeText={setPrimary} autoCapitalize="characters" maxLength={7} style={styles.hex} /></View><Text style={styles.fieldLabel}>Accent colour</Text><View style={styles.colorRow}><View style={[styles.swatch, { backgroundColor: validHex(accent) ? accent : "#FFFFFF" }]} /><TextInput value={accent} onChangeText={setAccent} autoCapitalize="characters" maxLength={7} style={styles.hex} /></View></FormSection><PrimaryButton label="Continue to invoice setup" icon="arrow-forward" onPress={saveBrand} /><TouchableOpacity onPress={() => setStep(3)} style={styles.skip}><Text style={styles.skipText}>Keep the default workspace brand for now</Text></TouchableOpacity></View> : null}
    {step === 3 ? <View style={styles.form}><Text style={styles.title}>Set up invoices</Text><Text style={styles.subtitle}>Your workspace logo and colours will carry into future client-ready invoices and PDF downloads.</Text><FormSection title="Invoice defaults"><FormField label="Invoice prefix" value={prefix} onChangeText={setPrefix} placeholder="INV" /><FormField label="Currency" value={currency} onChangeText={setCurrency} placeholder="NGN" /><FormField label="Payment information" value={paymentDetails} onChangeText={setPaymentDetails} multiline /><FormField label="Default payment terms" value={terms} onChangeText={setTerms} multiline /></FormSection><View style={styles.nairaNote}><Text style={styles.nairaTitle}>₦ Nigerian Naira is the default</Text><Text style={styles.nairaDetail}>The workspace is configured for Naira by default and is structured to support other currencies later.</Text></View><PrimaryButton label="Review workspace" icon="arrow-forward" onPress={saveInvoice} /><TouchableOpacity onPress={() => setStep(4)} style={styles.skip}><Text style={styles.skipText}>Skip optional invoice details for now</Text></TouchableOpacity></View> : null}
    {step === 4 ? <View style={styles.hero}><View style={[styles.heroIcon, styles.readyIcon]}><MaterialIcons name="check-circle" size={31} color={palette.moss} /></View><Text style={styles.title}>Your KreaFlow workspace is ready.</Text><Text style={styles.subtitle}>You can now manage clients, projects, payments, invoices, follow-ups, and goals in {activeWorkspace?.name ?? workspaceName}.</Text><View style={styles.readyList}><Text style={styles.readyItem}>• Workspace identity is saved</Text><Text style={styles.readyItem}>• Invoice branding is ready to customize</Text><Text style={styles.readyItem}>• Your dashboard will use your workspace data</Text></View><PrimaryButton label="Open my dashboard" icon="dashboard" onPress={finish} /></View> : null}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { padding: 22, paddingTop: 46, paddingBottom: 38, gap: 17 },
  brand: { flexDirection: "row", alignItems: "center", gap: 10 }, brandMark: { width: 42, height: 42, borderRadius: 15, backgroundColor: "#044BB2", alignItems: "center", justifyContent: "center" }, brandMarkText: { color: "#FFFFFF", fontSize: 21, lineHeight: 26, fontWeight: "900" }, brandName: { color: palette.ink, fontSize: 18, lineHeight: 23, fontWeight: "900" }, brandTagline: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" },
  stepLine: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 8 }, stepCaption: { color: palette.coral, fontSize: 10, lineHeight: 14, fontWeight: "900", letterSpacing: .8 }, stepName: { color: palette.primary, fontSize: 12, lineHeight: 16, fontWeight: "800" },
  hero: { marginTop: 16, gap: 14 }, heroIcon: { width: 58, height: 58, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: "#EAF4FF" }, readyIcon: { backgroundColor: "#E3F1EA" }, title: { color: palette.ink, fontSize: 29, lineHeight: 35, fontWeight: "900", letterSpacing: -.7 }, subtitle: { color: palette.muted, fontSize: 14, lineHeight: 21, fontWeight: "600" }, loading: { color: palette.muted, fontSize: 13, lineHeight: 18, fontWeight: "700" },
  authCard: { padding: 16, borderRadius: 20, gap: 10, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog }, authTitle: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "900" }, authDetail: { color: palette.muted, fontSize: 12, lineHeight: 18, fontWeight: "600" },
  authTabs: { flexDirection: "row", backgroundColor: palette.paper, borderRadius: 12, padding: 3, gap: 3 }, authTab: { flex: 1, paddingVertical: 8, borderRadius: 10, alignItems: "center" }, authTabActive: { backgroundColor: palette.primary }, authTabText: { color: palette.muted, fontSize: 12, fontWeight: "800" }, authTabTextActive: { color: "#FFFFFF" },
  authErrorText: { color: palette.coral, fontSize: 12, lineHeight: 17, fontWeight: "700" }, authNoticeText: { color: palette.moss, fontSize: 12, lineHeight: 17, fontWeight: "700" }, accountReady: { padding: 15, borderRadius: 19, flexDirection: "row", gap: 10, alignItems: "center", backgroundColor: "#E3F1EA" }, accountReadyTitle: { color: "#326A50", fontSize: 14, lineHeight: 19, fontWeight: "900" }, accountReadyDetail: { color: "#47715D", fontSize: 11, lineHeight: 16, fontWeight: "600" },
  form: { marginTop: 16, gap: 15 }, skip: { minHeight: 38, justifyContent: "center", alignItems: "center" }, skipText: { color: palette.primary, fontSize: 12, lineHeight: 17, fontWeight: "800" },
  logoCard: { flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderRadius: 17, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.fog }, logoPreview: { width: 43, height: 43, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "#EAF4FF" }, logoLetter: { color: "#044BB2", fontSize: 18, lineHeight: 22, fontWeight: "900" }, logoCopy: { flex: 1, gap: 2 }, logoTitle: { color: palette.ink, fontSize: 12, lineHeight: 17, fontWeight: "800" }, logoDetail: { color: palette.muted, fontSize: 10, lineHeight: 14, fontWeight: "600" }, import: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: 9, backgroundColor: "#EAF4FF" }, importText: { color: "#044BB2", fontSize: 10, lineHeight: 13, fontWeight: "900" },
  fieldLabel: { color: palette.muted, fontSize: 10, lineHeight: 14, letterSpacing: .5, fontWeight: "900", textTransform: "uppercase", marginTop: 2 }, colorRow: { flexDirection: "row", alignItems: "center", gap: 9 }, swatch: { width: 36, height: 36, borderRadius: 11, borderWidth: 1, borderColor: "#D8DAD5" }, hex: { height: 36, width: 110, paddingHorizontal: 10, borderRadius: 11, borderWidth: 1, borderColor: palette.fog, backgroundColor: "#FFFFFF", color: palette.ink, fontSize: 12, fontWeight: "800" },
  nairaNote: { padding: 14, borderRadius: 17, backgroundColor: "#FFF5D6", gap: 3 }, nairaTitle: { color: "#85621B", fontSize: 12, lineHeight: 17, fontWeight: "900" }, nairaDetail: { color: "#85621B", fontSize: 11, lineHeight: 16, fontWeight: "600" }, readyList: { padding: 15, borderRadius: 18, backgroundColor: "#EAF4FF", gap: 5 }, readyItem: { color: "#32516E", fontSize: 12, lineHeight: 18, fontWeight: "700" },
});
