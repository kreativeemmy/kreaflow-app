import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { InvoicePreview } from "@/components/invoice-preview";
import { EmptyState, PrimaryButton, ScreenHeader, palette } from "@/components/business-ui";
import type { InvoiceLineItem } from "@/lib/business-types";
import { createInvoiceData, exportInvoicePdf } from "@/lib/invoice";

export default function InvoiceScreen() {
  const params = useLocalSearchParams<{ id: string }>();
  const { transactions, projects, clients, businessProfile, invoiceDesign, updateInvoiceLineItems } = useBusiness();
  const [exporting, setExporting] = useState(false);
  const [editingItems, setEditingItems] = useState(false);
  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([]);
  const transaction = transactions.find((item) => item.id === params.id);
  const project = transaction?.projectId ? projects.find((item) => item.id === transaction.projectId) : undefined;
  const client = transaction?.clientId ? clients.find((item) => item.id === transaction.clientId) : undefined;
  useEffect(() => {
    if (!transaction || !project) return;
    setLineItems(transaction.invoiceSnapshot?.lineItems?.length ? transaction.invoiceSnapshot.lineItems : [{ description: project.service, detail: project.name, quantity: 1, rate: project.price, amount: project.price }]);
  }, [transaction?.id, project?.id]);
  if (!transaction || !project || !client) return <View style={styles.missing}><EmptyState title="Invoice unavailable" detail="This payment needs a linked client and project before an invoice can be generated." actionLabel="Back to money" onAction={() => router.replace("/money")} icon="receipt-long" /></View>;
  const invoice = createInvoiceData(transaction, project, client, transactions, { businessProfile, design: invoiceDesign });
  const updateItem = (index: number, patch: Partial<InvoiceLineItem>) => setLineItems((previous) => previous.map((item, itemIndex) => itemIndex === index ? { ...item, ...patch } : item));
  const addItem = () => setLineItems((previous) => [...previous, { description: "Additional service", detail: "", quantity: 1, rate: 0, amount: 0 }]);
  const removeItem = (index: number) => { if (lineItems.length === 1) return Alert.alert("Keep one item", "An invoice needs at least one line item."); setLineItems((previous) => previous.filter((_, itemIndex) => itemIndex !== index)); };
  const saveItems = () => { const normalized = lineItems.map((item) => ({ ...item, quantity: Math.max(1, Number(item.quantity) || 1), rate: Math.max(0, Number(item.rate) || 0), amount: Math.max(1, Number(item.quantity) || 1) * Math.max(0, Number(item.rate) || 0) })); updateInvoiceLineItems(transaction.id, normalized); setLineItems(normalized); setEditingItems(false); };
  const itemTotal = lineItems.reduce((sum, item) => sum + Math.max(1, Number(item.quantity) || 1) * Math.max(0, Number(item.rate) || 0), 0);
  const exportPdf = async () => {
    setExporting(true);
    try {
      const result = await exportInvoicePdf(invoice);
      Alert.alert(result.method === "opened" ? "PDF opened in a new tab" : "Invoice downloaded successfully", result.method === "shared" ? `${result.fileName} is ready to save or send from the share sheet.` : result.method === "printed" ? `Use the system print dialog to save ${result.fileName} as a PDF.` : result.method === "opened" ? `Your preview blocks direct downloads, so the PDF opened in a new tab. Use the browser menu there to download or share it.` : `${result.fileName} is ready to download.`);
    } catch (error) {
      Alert.alert("Unable to generate invoice. Please try again.", error instanceof Error ? error.message : "Please try again.");
    } finally {
      setExporting(false);
    }
  };
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Invoice preview" title={invoice.invoiceNumber} subtitle={`${invoice.design.name} · Issued ${invoice.issueDate}`} onBack={() => router.back()} />
    <View style={styles.itemsWrap}><View style={styles.itemsHeader}><View><Text style={styles.itemsTitle}>Invoice items</Text><Text style={styles.itemsSubtitle}>{lineItems.length} service{lineItems.length === 1 ? "" : "s"} · ₦{itemTotal.toLocaleString()}</Text></View><TouchableOpacity onPress={() => editingItems ? saveItems() : setEditingItems(true)} style={styles.editButton} activeOpacity={0.72}><MaterialIcons name={editingItems ? "check" : "edit"} size={16} color="#fff" /><Text style={styles.editButtonText}>{editingItems ? "Save items" : "Edit items"}</Text></TouchableOpacity></View>
      {lineItems.map((item, index) => editingItems ? <View key={`${index}-${item.description}`} style={styles.editorCard}><View style={styles.editorTop}><Text style={styles.itemNumber}>ITEM {index + 1}</Text><TouchableOpacity onPress={() => removeItem(index)} hitSlop={8}><MaterialIcons name="delete-outline" size={20} color={palette.coral} /></TouchableOpacity></View><TextInput value={item.description} onChangeText={(value) => updateItem(index, { description: value })} placeholder="Service description" style={styles.input} /><TextInput value={item.detail} onChangeText={(value) => updateItem(index, { detail: value })} placeholder="Optional details" style={styles.input} /><View style={styles.numberRow}><View style={styles.numberField}><Text style={styles.fieldLabel}>QTY</Text><TextInput value={String(item.quantity)} onChangeText={(value) => updateItem(index, { quantity: Number(value.replace(/[^0-9]/g, "")) || 1 })} keyboardType="number-pad" style={styles.input} /></View><View style={styles.rateField}><Text style={styles.fieldLabel}>RATE (₦)</Text><TextInput value={String(item.rate)} onChangeText={(value) => updateItem(index, { rate: Number(value.replace(/[^0-9.]/g, "")) || 0 })} keyboardType="decimal-pad" style={styles.input} /></View></View></View> : <View key={`${index}-${item.description}`} style={styles.itemRow}><View style={styles.itemCopy}><Text style={styles.itemName}>{item.description}</Text>{item.detail ? <Text style={styles.itemDetail}>{item.detail}</Text> : null}<Text style={styles.itemMeta}>{item.quantity} × ₦{item.rate.toLocaleString()}</Text></View><Text style={styles.itemAmount}>₦{(item.quantity * item.rate).toLocaleString()}</Text></View>)}
      {editingItems ? <TouchableOpacity onPress={addItem} activeOpacity={0.72} style={styles.addItem}><MaterialIcons name="add-circle-outline" size={18} color={palette.primary} /><Text style={styles.addItemText}>Add another service</Text></TouchableOpacity> : null}
    </View>
    <View style={styles.previewWrap}><InvoicePreview invoice={invoice} design={invoice.design} /></View>
    <View style={styles.exportWrap}><PrimaryButton label={exporting ? "Generating invoice..." : "Download Invoice"} icon="file-download" onPress={exportPdf} tone="primary" /><TouchableOpacity activeOpacity={0.7} onPress={() => router.push("/invoice-design")} style={styles.designOption}><MaterialIcons name="palette" size={18} color={palette.primary} /><Text style={styles.designText}>Customize future invoices</Text></TouchableOpacity><TouchableOpacity activeOpacity={0.7} onPress={exportPdf} style={styles.printOption}><MaterialIcons name="share" size={18} color={palette.primary} /><Text style={styles.printText}>Share or print PDF</Text></TouchableOpacity></View>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 34 }, missing: { flex: 1, padding: 20, justifyContent: "center", backgroundColor: palette.paper }, itemsWrap: { margin: 20, marginTop: 4, padding: 15, borderWidth: 1, borderColor: "#DCE6F2", borderRadius: 17, backgroundColor: "#fff" }, itemsHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 11, gap: 12 }, itemsTitle: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "900" }, itemsSubtitle: { color: palette.muted, fontSize: 11, lineHeight: 16, marginTop: 1, fontWeight: "600" }, editButton: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, minHeight: 34, borderRadius: 10, backgroundColor: palette.primary }, editButtonText: { color: "#fff", fontSize: 11, fontWeight: "900" }, itemRow: { flexDirection: "row", justifyContent: "space-between", gap: 12, paddingVertical: 11, borderTopWidth: 1, borderTopColor: "#E8EFF7" }, itemCopy: { flex: 1 }, itemName: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "800" }, itemDetail: { color: palette.muted, fontSize: 11, lineHeight: 16, marginTop: 1 }, itemMeta: { color: palette.muted, fontSize: 10, lineHeight: 15, marginTop: 3, fontWeight: "700" }, itemAmount: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "900" }, editorCard: { marginTop: 10, padding: 11, borderRadius: 12, backgroundColor: "#F4F8FD" }, editorTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 7 }, itemNumber: { color: palette.primary, fontSize: 10, fontWeight: "900", letterSpacing: 0.7 }, input: { minHeight: 40, borderWidth: 1, borderColor: "#D5E0EE", borderRadius: 9, backgroundColor: "#fff", paddingHorizontal: 10, color: palette.ink, fontSize: 12, marginTop: 7 }, numberRow: { flexDirection: "row", gap: 8 }, numberField: { width: 86 }, rateField: { flex: 1 }, fieldLabel: { marginTop: 9, color: palette.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.5 }, addItem: { minHeight: 40, marginTop: 10, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6, borderRadius: 10, borderWidth: 1, borderColor: "#B4CDEE", borderStyle: "dashed" }, addItemText: { color: palette.primary, fontSize: 12, fontWeight: "900" }, previewWrap: { paddingHorizontal: 20, marginTop: 4 }, exportWrap: { paddingHorizontal: 20, marginTop: 25, gap: 12 }, designOption: { minHeight: 43, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, borderRadius: 13, backgroundColor: "#E6F1FF" }, designText: { color: palette.primary, fontSize: 12, lineHeight: 17, fontWeight: "800" }, printOption: { minHeight: 43, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, printText: { color: palette.primary, fontSize: 12, lineHeight: 17, fontWeight: "800" },
});
