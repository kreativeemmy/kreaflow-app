import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, ScreenHeader, palette } from "@/components/business-ui";
import { clientName, formatNaira } from "@/lib/business-metrics";

type SearchResult = { id: string; type: "Project" | "Client" | "Lead" | "Transaction"; title: string; subtitle: string; route: () => void };

export default function SearchScreen() {
  const { clients, projects, leads, transactions } = useBusiness();
  const [query, setQuery] = useState("");
  const results = useMemo<SearchResult[]>(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return [];
    return [
      ...projects.filter((item) => `${item.name} ${clientName(item.clientId, clients)}`.toLowerCase().includes(needle)).map((item) => ({ id: item.id, type: "Project" as const, title: item.name, subtitle: `${clientName(item.clientId, clients)} · ${item.status}`, route: () => router.push({ pathname: "/project/[id]", params: { id: item.id } }) })),
      ...clients.filter((item) => `${item.name} ${item.business}`.toLowerCase().includes(needle)).map((item) => ({ id: item.id, type: "Client" as const, title: item.business, subtitle: item.name, route: () => router.push({ pathname: "/client/[id]", params: { id: item.id } }) })),
      ...leads.filter((item) => `${item.name} ${item.business} ${item.service}`.toLowerCase().includes(needle)).map((item) => ({ id: item.id, type: "Lead" as const, title: item.business, subtitle: `${item.name} · ${item.status}`, route: () => router.push({ pathname: "/lead/[id]", params: { id: item.id } }) })),
      ...transactions.filter((item) => `${item.note} ${clientName(item.clientId, clients)}`.toLowerCase().includes(needle)).map((item) => ({ id: item.id, type: "Transaction" as const, title: item.note, subtitle: `${clientName(item.clientId, clients)} · ${formatNaira(item.amount)}`, route: () => router.push("/money") })),
    ];
  }, [query, clients, projects, leads, transactions]);
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Business search" title="Find anything" subtitle="Search clients, projects, leads, and transactions." onBack={() => router.back()} />
    <View style={styles.searchBox}><MaterialIcons name="search" size={21} color={palette.primary} /><TextInput autoFocus value={query} onChangeText={setQuery} placeholder="Try a client, project, or lead" placeholderTextColor="#9AA09C" style={styles.input} returnKeyType="search" /></View>
    <View style={styles.results}>{query ? results.length ? results.map((result) => <TouchableOpacity key={`${result.type}-${result.id}`} style={styles.row} activeOpacity={0.74} onPress={result.route}><View style={styles.type}><Text style={styles.typeText}>{result.type.slice(0, 1)}</Text></View><View style={styles.copy}><Text style={styles.title}>{result.title}</Text><Text style={styles.subtitle}>{result.subtitle}</Text></View><Text style={styles.resultType}>{result.type}</Text><MaterialIcons name="chevron-right" size={20} color="#9AA09C" /></TouchableOpacity>) : <EmptyState title="No matching records" detail="Try a different name, business, project, or payment note." icon="search-off" /> : <View style={styles.prompt}><MaterialIcons name="search" size={30} color="#B0B5B1" /><Text style={styles.promptTitle}>Start with a business detail</Text><Text style={styles.promptDetail}>You can search across your workspace from this one place.</Text></View>}</View>
  </ScrollView>;
}

const styles = StyleSheet.create({ page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 32 }, searchBox: { flexDirection: "row", alignItems: "center", gap: 9, marginHorizontal: 20, paddingHorizontal: 13, height: 52, borderRadius: 16, backgroundColor: palette.surface, borderWidth: 1, borderColor: "#B4DEFF" }, input: { flex: 1, color: palette.ink, fontSize: 14, lineHeight: 19, fontWeight: "600" }, results: { paddingHorizontal: 20, paddingTop: 18 }, row: { minHeight: 66, paddingHorizontal: 14, backgroundColor: palette.surface, borderBottomWidth: 1, borderBottomColor: palette.fog, flexDirection: "row", alignItems: "center", gap: 10 }, type: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF" }, typeText: { color: palette.primary, fontSize: 13, lineHeight: 17, fontWeight: "800" }, copy: { flex: 1, gap: 2 }, title: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "800" }, subtitle: { color: palette.muted, fontSize: 11, lineHeight: 15, fontWeight: "600" }, resultType: { color: palette.muted, fontSize: 10, lineHeight: 14, fontWeight: "800" }, prompt: { padding: 35, alignItems: "center", gap: 8 }, promptTitle: { color: palette.ink, fontSize: 16, lineHeight: 21, fontWeight: "800", marginTop: 4 }, promptDetail: { color: palette.muted, fontSize: 12, lineHeight: 18, textAlign: "center", maxWidth: 250 }, });
