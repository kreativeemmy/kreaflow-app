import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useBusiness } from "@/components/business-provider";
import { EmptyState, ScreenHeader, SectionHeading, palette } from "@/components/business-ui";
import { clientName, formatNaira } from "@/lib/business-metrics";
import { createInvoiceData } from "@/lib/invoice";

export default function InvoicesScreen() {
  const { transactions, clients, projects, businessProfile, invoiceDesign } = useBusiness();
  const invoices = transactions.filter((transaction) => transaction.clientId && transaction.projectId);
  return <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <ScreenHeader eyebrow="Workspace invoices" title="Invoices" subtitle="Open, preview, download, print, or share saved client invoices." onBack={() => router.back()} />
    {invoices.length ? <View style={styles.section}><SectionHeading title="Saved invoices" /><View style={styles.list}>{invoices.map((transaction) => { const project = projects.find((item) => item.id === transaction.projectId); const client = clients.find((item) => item.id === transaction.clientId); if (!project || !client) return null; const invoice = createInvoiceData(transaction, project, client, transactions, { businessProfile, design: invoiceDesign }); return <TouchableOpacity key={transaction.id} activeOpacity={0.74} onPress={() => router.push({ pathname: "/invoice/[id]", params: { id: transaction.id } })} style={styles.row}><View style={styles.icon}><MaterialIcons name="receipt-long" size={22} color="#044BB2" /></View><View style={styles.copy}><Text style={styles.invoiceNumber}>{invoice.invoiceNumber}</Text><Text style={styles.detail}>{clientName(transaction.clientId, clients)} · {project.name}</Text><Text style={styles.detail}>{transaction.date}</Text></View><View style={styles.amountWrap}><Text style={styles.amount}>{formatNaira(transaction.amount)}</Text><View style={styles.download}><MaterialIcons name="file-download" size={19} color={palette.primary} /></View></View></TouchableOpacity>; })}</View></View> : <View style={styles.empty}><EmptyState icon="receipt-long" title="No invoices yet" detail="Record a client payment from Money to create a workspace-branded invoice you can download." actionLabel="Record payment" onAction={() => router.push("/create?type=payment")} /></View>}
  </ScrollView>;
}

const styles = StyleSheet.create({ page: { flex: 1, backgroundColor: palette.paper }, content: { paddingBottom: 32 }, section: { marginTop: 5, paddingHorizontal: 20 }, list: { borderRadius: 20, overflow: "hidden", borderWidth: 1, borderColor: palette.fog, backgroundColor: palette.surface }, row: { minHeight: 78, padding: 13, flexDirection: "row", alignItems: "center", gap: 11, borderBottomWidth: 1, borderBottomColor: palette.fog }, icon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "#EAF4FF" }, copy: { flex: 1, gap: 2 }, invoiceNumber: { color: palette.ink, fontSize: 13, lineHeight: 18, fontWeight: "900" }, detail: { color: palette.muted, fontSize: 10, lineHeight: 14, fontWeight: "600" }, amountWrap: { alignItems: "flex-end", gap: 5 }, amount: { color: palette.ink, fontSize: 12, lineHeight: 16, fontWeight: "900" }, download: { width: 28, height: 28, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#E6F1FF" }, empty: { paddingHorizontal: 20, paddingTop: 7 } });
