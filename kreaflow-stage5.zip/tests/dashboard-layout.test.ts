import { describe, expect, it } from "vitest";

import { dashboardMetricLayout } from "../lib/dashboard-layout";

describe("dashboard KPI responsiveness", () => {
  it.each([360, 390, 430, 768])("uses a readable two-column grid at %ipx", (width) => {
    expect(dashboardMetricLayout(width)).toEqual({ columns: 2, cellWidth: "48.5%" });
  });

  it("uses a four-card row only on a large desktop viewport", () => {
    expect(dashboardMetricLayout(1280)).toEqual({ columns: 4, cellWidth: "23.9%" });
  });
});
