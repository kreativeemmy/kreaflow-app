import { describe, expect, it } from "vitest";

import { initialBusinessState } from "../lib/business-data";
import { projectBalance, projectProgress, totalOutstanding, totalRevenue } from "../lib/business-metrics";

describe("business operating system metrics", () => {
  const onyxProject = initialBusinessState.projects.find((project) => project.id === "project-onyx-launch");

  it("calculates project completion from checked deliverables", () => {
    expect(onyxProject).toBeDefined();
    expect(projectProgress(onyxProject!)).toBe(50);
  });

  it("calculates a project balance only from received funds", () => {
    expect(onyxProject).toBeDefined();
    expect(projectBalance(onyxProject!, initialBusinessState.transactions)).toBe(45000);
  });

  it("summarizes received revenue and unpaid project balances", () => {
    expect(totalRevenue(initialBusinessState.transactions)).toBe(195000);
    expect(totalOutstanding(initialBusinessState.projects, initialBusinessState.transactions)).toBe(105000);
  });
});
