import { describe, expect, it } from "vitest";

import { initialBusinessState } from "../lib/business-data";
import { DEFAULT_BUSINESS_PROFILE, DEFAULT_INVOICE_DESIGN, type BusinessProfile, type InvoiceDesign, type InvoiceSnapshot } from "../lib/business-types";
import { createBrowserInvoicePdf, createInvoiceData, invoiceHtml } from "../lib/invoice";

describe("invoice design defaults", () => {
  it("provides a client-ready default design and business profile", () => {
    expect(DEFAULT_INVOICE_DESIGN.name).toBe("Kreativeemmy Default");
    expect(DEFAULT_INVOICE_DESIGN.layout).toBe("Modern");
    expect(DEFAULT_INVOICE_DESIGN.primaryColor).toMatch(/^#[0-9A-F]{6}$/i);
    expect(DEFAULT_BUSINESS_PROFILE.notes.length).toBeGreaterThan(10);
    expect(DEFAULT_BUSINESS_PROFILE.terms.length).toBeGreaterThan(10);
  });

  it("keeps a complete visual snapshot with historical invoice data", () => {
    const snapshot: InvoiceSnapshot = {
      businessProfile: { ...DEFAULT_BUSINESS_PROFILE, name: "Saved Identity" },
      design: { ...DEFAULT_INVOICE_DESIGN, primaryColor: "#0562E9" },
      lineItems: [{ description: "Launch design", detail: "Historic invoice", quantity: 1, rate: 85000, amount: 85000 }],
    };
    const changedDefault = { ...DEFAULT_INVOICE_DESIGN, primaryColor: "#F26A50" };
    expect(snapshot.design.primaryColor).toBe("#0562E9");
    expect(changedDefault.primaryColor).toBe("#F26A50");
    expect(snapshot.lineItems[0].amount).toBe(85000);
  });

  it("fills missing legacy profile and design fields before creating an invoice", () => {
    const transaction = { ...initialBusinessState.transactions[0], invoiceSnapshot: undefined };
    const project = initialBusinessState.projects.find((item) => item.id === transaction.projectId)!;
    const client = initialBusinessState.clients.find((item) => item.id === transaction.clientId)!;
    const invoice = createInvoiceData(transaction, project, client, initialBusinessState.transactions, {
      businessProfile: { name: "Existing workspace" } as BusinessProfile,
      design: {} as InvoiceDesign,
    });
    expect(invoice.invoiceNumber).toMatch(/^INV-/);
    expect(invoice.businessProfile.invoicePrefix).toBe("INV");
    expect(invoiceHtml(invoice)).toContain("Existing workspace");
  });

  it("builds a standalone browser-download PDF document", () => {
    const transaction = initialBusinessState.transactions[0];
    const project = initialBusinessState.projects.find((item) => item.id === transaction.projectId)!;
    const client = initialBusinessState.clients.find((item) => item.id === transaction.clientId)!;
    const pdf = createBrowserInvoicePdf(createInvoiceData(transaction, project, client, initialBusinessState.transactions));
    expect(pdf.startsWith("%PDF-1.4")).toBe(true);
    expect(pdf).toContain("xref");
    expect(pdf).toContain("INVOICE");
  });
});

describe("invoice payment details (account number for the client)", () => {
  const transaction = initialBusinessState.transactions[0];
  const project = initialBusinessState.projects.find((item) => item.id === transaction.projectId)!;
  const client = initialBusinessState.clients.find((item) => item.id === transaction.clientId)!;
  const businessProfile = { ...DEFAULT_BUSINESS_PROFILE, paymentDetails: "GTBank · 0123456789 · Kreativeemmy Studio" };

  it("appears in the HTML/PDF export used on Android and iOS", () => {
    const invoice = createInvoiceData(transaction, project, client, initialBusinessState.transactions, { businessProfile, design: DEFAULT_INVOICE_DESIGN });
    const html = invoiceHtml(invoice);
    expect(html).toContain("Payment details");
    expect(html).toContain("GTBank");
    expect(html).toContain("0123456789");
  });

  it("appears in the standalone PDF used for web downloads", () => {
    const invoice = createInvoiceData(transaction, project, client, initialBusinessState.transactions, { businessProfile, design: DEFAULT_INVOICE_DESIGN });
    const pdf = createBrowserInvoicePdf(invoice);
    expect(pdf).toContain("PAYMENT DETAILS");
    expect(pdf).toContain("GTBank");
  });

  it("is left out entirely when the workspace hasn't set any payment details", () => {
    const emptyProfile = { ...DEFAULT_BUSINESS_PROFILE, paymentDetails: "" };
    const invoice = createInvoiceData(transaction, project, client, initialBusinessState.transactions, { businessProfile: emptyProfile, design: DEFAULT_INVOICE_DESIGN });
    expect(invoiceHtml(invoice)).not.toContain("Payment details");
    expect(createBrowserInvoicePdf(invoice)).not.toContain("PAYMENT DETAILS");
  });
});

describe("logo size as a continuous value (replacing Small/Medium/Large)", () => {
  it("renders whatever pixel width the workspace picked", () => {
    const transaction = initialBusinessState.transactions[0];
    const project = initialBusinessState.projects.find((item) => item.id === transaction.projectId)!;
    const client = initialBusinessState.clients.find((item) => item.id === transaction.clientId)!;
    const design = { ...DEFAULT_INVOICE_DESIGN, logoScale: 168 };
    const invoice = createInvoiceData(transaction, project, client, initialBusinessState.transactions, { businessProfile: DEFAULT_BUSINESS_PROFILE, design });
    expect(invoiceHtml(invoice)).toContain("width:168px");
  });
});
