import { describe, expect, it } from "vitest";

import { invoiceFilename } from "../lib/invoice";

describe("invoice download filename", () => {
  it("creates a professional filename and removes unsafe characters", () => {
    expect(invoiceFilename({ invoiceNumber: "INV-0001", client: { business: "Maru Skincare / Lagos", name: "Maru" } } as never)).toBe("Invoice-INV-0001-Maru-Skincare-Lagos.pdf");
  });

  it("falls back to the client name when a business is not available", () => {
    expect(invoiceFilename({ invoiceNumber: "INV-0030", client: { business: "", name: "Jane Visuals" } } as never)).toBe("Invoice-INV-0030-Jane-Visuals.pdf");
  });
});
