/** @type {const} */
const themeColors = {
  primary: { light: '#0562E9', dark: '#B8A8E8' },
  background: { light: '#F4F8FD', dark: '#323637' },
  surface: { light: '#FFFFFF', dark: '#22302A' },
  foreground: { light: '#323637', dark: '#F5F7F4' },
  muted: { light: '#6D736F', dark: '#AAB4AE' },
  border: { light: '#DCE6F2', dark: '#39473F' },
  success: { light: '#3E8E6A', dark: '#6EC39A' },
  warning: { light: '#D99B2B', dark: '#E9BC62' },
  error: { light: '#F26A50', dark: '#FA967F' },
};

module.exports = { themeColors };
