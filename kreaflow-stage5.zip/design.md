# Kreativeemmy Business OS — Mobile Interface Design

## Product intent

Kreativeemmy Business OS is a focused, local-first command center for a freelance social media brand designer. The app prioritizes the day’s work, client relationships, cash position, and lead movement over generic productivity features. The first release uses realistic, editable sample data with local persistence, so the business system can be explored immediately without requiring an account or network connection.

## Mobile design principles

The experience is designed for **portrait, one-handed use**. The most frequent actions are reachable from a persistent bottom navigation bar and a prominent floating quick-action control. Dense business information is grouped into calm, scannable cards with an editorial hierarchy rather than corporate dashboard clutter. Lists use clear data labels, high-contrast statuses, and tap targets suited to standard iOS ergonomics.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Dashboard | Morning greeting, daily focus, compact KPI grid, active project workflow, revenue goal progress, and quick actions. |
| Projects | Searchable, filterable project list with service, price, deadline, status, payment state, and completion. Tapping a project opens a detailed workflow view. |
| Project detail | Project overview, workflow stage progression, deliverable checklist, revision allowance, project tasks, payment summary, and notes. |
| Clients | Client directory with active status, project count, value, and latest activity. Tapping opens a rich client profile. |
| Client profile | Client contact summary, financial value, associated projects, payments, follow-ups, and activity timeline. |
| Leads | Pipeline view grouped by new, contacted, proposal, negotiation, won, and lost stages, including next follow-up dates. A lead can move stages and be converted conceptually into a client/project. |
| Money | Financial snapshot, a switchable revenue trend, transactions, project balances, and a flow to record a payment. |
| Goals | Monthly revenue goal, milestone cards for client/project/content goals, visual progress, and an action to create a new goal. |
| Global search | A full-screen search surface that finds projects, clients, leads, and transactions as the user types. |
| Create flow | A bottom sheet-style form surface reused for client, project, lead, payment, follow-up, and goal creation. |

## Navigation model

The primary navigation uses five bottom tabs: **Home**, **Projects**, **Clients**, **Pipeline**, and **More**. More presents Money, Goals, and settings-style options without overloading the tab bar. An always-present quick-action button on the dashboard opens the most common creation paths. Contextual header controls provide search and notifications; page-level actions stay close to the related list or summary.

## Key user flows

| User goal | Flow |
|---|---|
| Check the day’s work | Home tab → Today’s Focus → tap a project or follow-up item → detail context. |
| Create a new project | Dashboard quick action or Projects header → project form → select an existing client → save → project appears in workflow and client profile. |
| Progress a design job | Projects → select project → tap the next workflow stage → update deliverable checkboxes → completion and project status update. |
| Track a potential client | Pipeline → select a lead → advance its stage → add/confirm next follow-up → move to Won when ready. |
| Record money received | More → Money → Record payment → select client/project → enter amount/method → save → project balance and monthly revenue update. |
| Review business targets | More → Goals → inspect monthly revenue target and supporting targets → add or update a goal. |

## Visual direction and color choices

The visual system combines an off-white working canvas with **ink black**, **deep plum**, and a distinctive **coral-red signal**. The palette supports a creative professional while preserving financial and operational clarity.

| Token | Color | Intended use |
|---|---|---|
| Ink | `#17211E` | Primary headings, high-priority values, navigation text. |
| Paper | `#F7F7F3` | App background and quiet breathing space. |
| Surface | `#FFFFFF` | Cards, sheets, and active content containers. |
| Plum | `#332A53` | Brand anchor, primary actions, selected controls. |
| Coral | `#F26A50` | Attention, outstanding balances, primary metric emphasis. |
| Moss | `#3E8E6A` | Paid, complete, healthy progress, and achieved goals. |
| Gold | `#D99B2B` | Deadlines, waiting-for-feedback, and warning states. |
| Fog | `#E7E7E1` | Borders, dividers, secondary surfaces. |

Typography favors bold but compact metric figures and warm, readable body text. Rounded card corners, hairline borders, restrained shadows, and occasional full-bleed color blocks create a confident, composed workspace. Dark mode tokens will remain supported by the existing theme framework, but the first MVP’s primary interface is light.

## Data model vocabulary

The client is the relationship record. A project belongs to one client and contains workflow status, deliverables, tasks, revisions, and notes. Transactions may be tied to a project and update its balance. Follow-ups belong to a client, lead, or project context. A won lead becomes a client record and can seed a project. Goals summarize targets independently while reading progress from the broader business data.

## MVP boundaries

The app will include the command-center workflows for dashboard, projects, clients, leads, money, goals, search, and contextual creation. It will not implement invoicing, a client portal, team collaboration, chat, complex accounting, marketing automation, social scheduling, or advanced analytics. The code structure will keep domain data, screen components, and reusable UI elements separated so these later capabilities can be added without rebuilding the core navigation or data vocabulary.
