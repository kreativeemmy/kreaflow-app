import AsyncStorage from "@react-native-async-storage/async-storage";
import { AppState } from "react-native";
import { createContext, type PropsWithChildren, useContext, useEffect, useMemo, useRef, useState } from "react";
import {
  cloudAddClient, cloudAddDeliverable, cloudAddFollowUp, cloudAddGoal, cloudAddGoalStep, cloudAddLead, cloudAddProject,
  cloudDeleteClient, cloudDeleteProject,
  cloudAddTransaction, cloudCompleteOnboarding, cloudToggleDeliverable,
  cloudToggleGoalStep, cloudToggleProjectTask, cloudTouchClient, cloudUpdateBusinessProfile, cloudUpdateClient, cloudUpdateGoalProgress,
  cloudUpdateInvoiceDesign, cloudUpdateInvoiceSnapshot, cloudUpdateLead, cloudUpdateProject,
  fetchCloudWorkspaces, insertCloudWorkspace, pushWorkspaceToCloud,
} from "@/lib/cloud-sync";
import { newId } from "@/lib/id";
import { countRecords } from "@/lib/cloud-mapping";
import { today } from "@/lib/dates";

import { initialBusinessState } from "@/lib/business-data";
import { DEFAULT_BUSINESS_PROFILE, DEFAULT_INVOICE_DESIGN } from "@/lib/business-types";
import { useAuth } from "@/hooks/use-auth";
import { DEVICE_REMINDERS_KEY, setDeviceRemindersEnabled as configureDeviceReminders } from "@/lib/notifications";
import type {
  BusinessProfile,
  BusinessState,
  Client,
  ClientStatus,
  FollowUp,
  Goal,
  InvoiceDesign,
  InvoiceLineItem,
  Lead,
  LeadStage,
  Project,
  Transaction,
  Workspace,
  WorkspaceStore,
  WorkspaceSummary,
} from "@/lib/business-types";

const LEGACY_STORAGE_KEY = "kreativeemmy-business-os-v1";
const WORKSPACE_STORAGE_KEY = "kreaflow-workspaces-v2";
const CLOUD_SYNC_KEY = "kreativeemmy-cloud-sync-enabled";

type NewClient = Omit<Client, "id" | "lastActivity">;
type NewProject = Omit<Project, "id" | "deliverables" | "tasks" | "revisionsUsed"> & Partial<Pick<Project, "deliverables" | "tasks" | "revisionsUsed">>;
type NewLead = Omit<Lead, "id">;
type NewTransaction = Omit<Transaction, "id" | "invoiceSnapshot">;
type NewFollowUp = Omit<FollowUp, "id" | "complete"> & Partial<Pick<FollowUp, "complete">>;
type NewGoal = Omit<Goal, "id">;
type WorkspaceInput = Pick<BusinessProfile, "name"> & Partial<BusinessProfile>;

interface BusinessContextValue extends BusinessState {
  hydrated: boolean;
  activeWorkspace: WorkspaceSummary | null;
  workspaces: WorkspaceSummary[];
  needsOnboarding: boolean;
  account: {
    name: string | null;
    email: string | null;
    isAuthenticated: boolean;
    loading: boolean;
    signOut: () => Promise<void>;
  };
  cloudSync: {
    enabled: boolean;
    lastBackupAt: string | null;
    syncNow: () => Promise<boolean>;
    restoreFromCloud: () => Promise<boolean>;
    setEnabled: (enabled: boolean) => Promise<boolean>;
  };
  reminders: {
    deviceEnabled: boolean;
    cloudEnabled: boolean;
    setDeviceEnabled: (enabled: boolean) => Promise<number>;
    enableCloud: () => Promise<"enabled" | "signin" | "device" | "project">;
    disableCloud: () => Promise<void>;
  };
  createWorkspace: (input: WorkspaceInput) => string;
  switchWorkspace: (workspaceId: string) => void;
  completeOnboarding: () => void;
  addClient: (client: NewClient) => string;
  addProject: (project: NewProject) => string;
  addLead: (lead: NewLead) => string;
  addTransaction: (transaction: NewTransaction) => string;
  addFollowUp: (followUp: NewFollowUp) => string;
  addGoal: (goal: NewGoal) => string;
  addGoalStep: (goalId: string, title: string) => void;
  toggleGoalStep: (goalId: string, stepId: string) => void;
  updateProject: (id: string, patch: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  toggleDeliverable: (projectId: string, deliverableId: string) => void;
  addDeliverable: (projectId: string, title: string) => void;
  toggleTask: (projectId: string, taskId: string) => void;
  moveLead: (id: string, status: LeadStage) => void;
  updateLead: (id: string, patch: Partial<Lead>) => void;
  updateClient: (id: string, patch: Partial<Client>) => void;
  // Blocked with a reason when the client still has projects attached —
  // deleting a client never silently deletes their project/payment history.
  deleteClient: (id: string) => { ok: true } | { ok: false; reason: string };
  nudgeGoal: (id: string) => void;
  updateBusinessProfile: (patch: Partial<BusinessProfile>) => void;
  updateInvoiceDesign: (patch: Partial<InvoiceDesign>) => void;
  updateInvoiceLineItems: (transactionId: string, lineItems: InvoiceLineItem[]) => void;
  resetInvoiceDesign: () => void;
}

const BusinessContext = createContext<BusinessContextValue | null>(null);

function cloneProfile(profile: BusinessProfile): BusinessProfile { return { ...profile, logo: profile.logo ? { ...profile.logo } : undefined }; }
function cloneDesign(design: InvoiceDesign): InvoiceDesign { return { ...design, customFont: design.customFont ? { ...design.customFont } : undefined, logo: design.logo ? { ...design.logo } : undefined, backgroundImage: design.backgroundImage ? { ...design.backgroundImage } : undefined }; }
function projectInvoiceItems(project: Project | undefined): InvoiceLineItem[] { return project ? [{ description: project.service, detail: project.name, quantity: 1, rate: project.price, amount: project.price }] : []; }

// Older local saves stored logo size as "Small"/"Medium"/"Large"; anything
// else (undefined, or already a number) passes straight through.
function coerceLogoScale(value: unknown): number {
  if (typeof value === "number") return value;
  if (value === "Small") return 54;
  if (value === "Large") return 112;
  if (value === "Medium") return 82;
  return DEFAULT_INVOICE_DESIGN.logoScale;
}

function normalizeBusinessState(saved: Partial<BusinessState>): BusinessState {
  const businessProfile = { ...DEFAULT_BUSINESS_PROFILE, ...(saved.businessProfile ?? {}) };
  const invoiceDesign = { ...DEFAULT_INVOICE_DESIGN, ...(saved.invoiceDesign ?? {}), logoScale: coerceLogoScale((saved.invoiceDesign ?? {}).logoScale) };
  const projects = saved.projects ?? initialBusinessState.projects;
  return {
    ...initialBusinessState,
    ...saved,
    businessProfile,
    invoiceDesign,
    transactions: (saved.transactions ?? initialBusinessState.transactions).map((transaction) => ({
      ...transaction,
      invoiceSnapshot: transaction.invoiceSnapshot ?? { businessProfile: cloneProfile(businessProfile), design: cloneDesign(invoiceDesign), lineItems: projectInvoiceItems(projects.find((project) => project.id === transaction.projectId)) },
    })),
  };
}

function emptyWorkspaceData(input: WorkspaceInput): BusinessState {
  const businessProfile = { ...DEFAULT_BUSINESS_PROFILE, ...input, name: input.name.trim() || "Untitled workspace" };
  return {
    clients: [], projects: [], leads: [], transactions: [], followUps: [], goals: [],
    businessProfile,
    invoiceDesign: { ...DEFAULT_INVOICE_DESIGN, name: `${businessProfile.name} Default`, primaryColor: "#0562E9", accentColor: "#F26A50", textColor: "#323637", tableHeaderColor: "#F1EFF7", borderColor: "#DCE6F2" },
  };
}

function workspaceSummary(workspace: Workspace): WorkspaceSummary { return { id: workspace.id, name: workspace.name, createdAt: workspace.createdAt, onboardingComplete: workspace.onboardingComplete }; }

function legacyWorkspaceStore(saved: Partial<BusinessState>): WorkspaceStore {
  const data = normalizeBusinessState(saved);
  const id = "workspace-kreativeemmy";
  return { version: 2, activeWorkspaceId: id, workspaces: [{ id, name: data.businessProfile.name, createdAt: new Date().toISOString(), onboardingComplete: true, data }] };
}

function normalizeWorkspaceStore(raw: unknown): WorkspaceStore {
  const candidate = raw as Partial<WorkspaceStore>;
  if (candidate?.version === 2 && Array.isArray(candidate.workspaces)) {
    const workspaces = candidate.workspaces.map((workspace) => ({
      ...workspace,
      name: workspace.name || workspace.data?.businessProfile?.name || "Untitled workspace",
      createdAt: workspace.createdAt || new Date().toISOString(),
      onboardingComplete: workspace.onboardingComplete ?? true,
      data: normalizeBusinessState(workspace.data ?? {}),
    }));
    const activeWorkspaceId = workspaces.some((workspace) => workspace.id === candidate.activeWorkspaceId) ? candidate.activeWorkspaceId ?? null : workspaces[0]?.id ?? null;
    return { version: 2, activeWorkspaceId, workspaces };
  }
  return legacyWorkspaceStore(candidate as Partial<BusinessState>);
}

export function BusinessProvider({ children }: PropsWithChildren) {
  const [workspaceStore, setWorkspaceStore] = useState<WorkspaceStore>({ version: 2, activeWorkspaceId: null, workspaces: [] });
  const [hydrated, setHydrated] = useState(false);
  const [cloudSyncEnabled, setCloudSyncEnabled] = useState(false);
  const [lastBackupAt, setLastBackupAt] = useState<string | null>(null);
  const [deviceRemindersEnabled, setDeviceRemindersEnabledState] = useState(false);
  const [cloudRemindersEnabled, setCloudRemindersEnabled] = useState(false);
  const auth = useAuth();
  const workspaceStoreRef = useRef(workspaceStore);
  const cloudSyncedRef = useRef(false);

  useEffect(() => {
    let active = true;
    Promise.all([AsyncStorage.getItem(WORKSPACE_STORAGE_KEY), AsyncStorage.getItem(LEGACY_STORAGE_KEY), AsyncStorage.getItem(CLOUD_SYNC_KEY), AsyncStorage.getItem(DEVICE_REMINDERS_KEY)])
      .then(([workspaceSaved, legacySaved, cloudSetting, deviceReminderSetting]) => {
        if (!active) return;
        if (workspaceSaved) setWorkspaceStore(normalizeWorkspaceStore(JSON.parse(workspaceSaved)));
        else if (legacySaved) setWorkspaceStore(legacyWorkspaceStore(JSON.parse(legacySaved) as Partial<BusinessState>));
        setCloudSyncEnabled(cloudSetting === "true");
        setDeviceRemindersEnabledState(deviceReminderSetting === "true");
      })
      .catch(() => undefined)
      .finally(() => { if (active) setHydrated(true); });
    return () => { active = false; };
  }, []);

  useEffect(() => { if (hydrated) AsyncStorage.setItem(WORKSPACE_STORAGE_KEY, JSON.stringify(workspaceStore)).catch(() => undefined); }, [workspaceStore, hydrated]);
  useEffect(() => { workspaceStoreRef.current = workspaceStore; }, [workspaceStore]);

  // The moment someone is signed in, the cloud becomes the source of truth.
  // First time ever (no cloud workspace yet): whatever was built locally
  // before signing in gets pushed up, id-for-id. After that, every open of
  // the app just pulls the latest from the cloud.
  const refreshFromCloud = async (): Promise<boolean> => {
    if (!auth.isAuthenticated) return false;
    try {
      let cloudWorkspaces = await fetchCloudWorkspaces();
      const cloudById = new Map(cloudWorkspaces.map((workspace) => [workspace.id, workspace]));
      let healedAnything = false;

      // Heal before trusting the cloud copy: if this phone's local copy of a
      // workspace has more in it than what's actually in the cloud — an
      // interrupted upload, a save that dropped mid-flight — the cloud copy
      // is the stale one here, not the local one. Push the full local
      // workspace up (upsert-safe, so this can't duplicate what already
      // made it) before adopting anything, so a shaky connection can never
      // make real entries disappear.
      for (const local of workspaceStoreRef.current.workspaces) {
        const cloudMatch = cloudById.get(local.id);
        if (!cloudMatch || countRecords(local.data) > countRecords(cloudMatch.data)) {
          await pushWorkspaceToCloud(local);
          healedAnything = true;
        }
      }
      if (healedAnything) cloudWorkspaces = await fetchCloudWorkspaces();

      if (cloudWorkspaces.length > 0) {
        setWorkspaceStore((previous) => ({
          version: 2,
          activeWorkspaceId: cloudWorkspaces.some((workspace) => workspace.id === previous.activeWorkspaceId) ? previous.activeWorkspaceId : cloudWorkspaces[0].id,
          workspaces: cloudWorkspaces,
        }));
      }
      setLastBackupAt(new Date().toISOString());
      return true;
    } catch (error) {
      console.warn("[cloud] sync failed:", error);
      return false;
    }
  };

  useEffect(() => {
    if (!hydrated) return;
    if (!auth.isAuthenticated) { cloudSyncedRef.current = false; return; }
    if (cloudSyncedRef.current) return;
    cloudSyncedRef.current = true;
    refreshFromCloud().then((ok) => { if (!ok) cloudSyncedRef.current = false; });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth.isAuthenticated, hydrated]);

  // Also heal whenever the app comes back to the foreground, not just on
  // cold start — catches a save that failed while the phone had no signal
  // a few minutes ago, without needing a full app restart to fix itself.
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active" && hydrated && auth.isAuthenticated) refreshFromCloud();
    });
    return () => subscription.remove();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, auth.isAuthenticated]);

  const activeWorkspace = workspaceStore.workspaces.find((workspace) => workspace.id === workspaceStore.activeWorkspaceId) ?? null;
  const business = activeWorkspace?.data ?? emptyWorkspaceData({ name: "" });
  const summaries = workspaceStore.workspaces.map(workspaceSummary);
  const workspaceId = activeWorkspace?.id ?? null;
  const cloudReady = auth.isAuthenticated && !!workspaceId;
  const updateActiveData = (updater: (previous: BusinessState) => BusinessState) => {
    setWorkspaceStore((previous) => ({
      ...previous,
      workspaces: previous.workspaces.map((workspace) => workspace.id === previous.activeWorkspaceId ? (() => {
        const data = updater(workspace.data);
        return { ...workspace, name: data.businessProfile.name || workspace.name, data };
      })() : workspace),
    }));
  };

  const syncNow = refreshFromCloud;
  const restoreFromCloud = refreshFromCloud;
  const setCloudSync = async (enabled: boolean): Promise<boolean> => {
    setCloudSyncEnabled(enabled);
    AsyncStorage.setItem(CLOUD_SYNC_KEY, String(enabled)).catch(() => undefined);
    return enabled ? auth.isAuthenticated : true;
  };

  const setDeviceReminders = async (enabled: boolean): Promise<number> => {
    const count = await configureDeviceReminders(enabled, business);
    setDeviceRemindersEnabledState(enabled && count >= 0);
    return count;
  };
  const enableCloudReminders = async (): Promise<"enabled" | "signin" | "device" | "project"> => "signin";
  const disableCloudReminders = async () => { setCloudRemindersEnabled(false); };

  const value = useMemo<BusinessContextValue>(() => ({
    ...business,
    hydrated,
    activeWorkspace: activeWorkspace ? workspaceSummary(activeWorkspace) : null,
    workspaces: summaries,
    needsOnboarding: !activeWorkspace || !activeWorkspace.onboardingComplete,
    account: { name: auth.user?.name ?? null, email: auth.user?.email ?? null, isAuthenticated: auth.isAuthenticated, loading: auth.loading, signOut: auth.logout },
    cloudSync: { enabled: cloudSyncEnabled, lastBackupAt, syncNow, restoreFromCloud, setEnabled: setCloudSync },
    reminders: { deviceEnabled: deviceRemindersEnabled, cloudEnabled: cloudRemindersEnabled, setDeviceEnabled: setDeviceReminders, enableCloud: enableCloudReminders, disableCloud: disableCloudReminders },
    createWorkspace: (input) => {
      const id = newId();
      const data = emptyWorkspaceData(input);
      if (auth.isAuthenticated) insertCloudWorkspace(id, { name: data.businessProfile.name, businessProfile: data.businessProfile, invoiceDesign: data.invoiceDesign, onboardingComplete: false }).catch((error) => console.warn("[cloud] create workspace failed:", error));
      setWorkspaceStore((previous) => ({ version: 2, activeWorkspaceId: id, workspaces: [...previous.workspaces, { id, name: data.businessProfile.name, createdAt: new Date().toISOString(), onboardingComplete: false, data }] }));
      return id;
    },
    switchWorkspace: (workspaceId) => setWorkspaceStore((previous) => previous.workspaces.some((workspace) => workspace.id === workspaceId) ? { ...previous, activeWorkspaceId: workspaceId } : previous),
    completeOnboarding: () => { if (cloudReady && workspaceId) cloudCompleteOnboarding(workspaceId); setWorkspaceStore((previous) => ({ ...previous, workspaces: previous.workspaces.map((workspace) => workspace.id === previous.activeWorkspaceId ? { ...workspace, onboardingComplete: true } : workspace) })); },
    addClient: (client) => {
      const id = newId();
      const full: Client = { ...client, id, lastActivity: "Client created today" };
      if (cloudReady && workspaceId) cloudAddClient(workspaceId, full);
      updateActiveData((previous) => ({ ...previous, clients: [full, ...previous.clients] }));
      return id;
    },
    addProject: (project) => {
      const id = newId();
      const full: Project = { ...project, id, revisionsUsed: project.revisionsUsed ?? 0, deliverables: project.deliverables ?? [], tasks: project.tasks ?? [] };
      if (cloudReady && workspaceId) { cloudAddProject(workspaceId, full); cloudTouchClient(workspaceId, project.clientId, { status: "Active", lastActivity: "New project created today" }); }
      updateActiveData((previous) => ({ ...previous, projects: [full, ...previous.projects], clients: previous.clients.map((client) => client.id === project.clientId ? { ...client, status: "Active" as ClientStatus, lastActivity: "New project created today" } : client) }));
      return id;
    },
    addLead: (lead) => {
      const id = newId();
      const full: Lead = { ...lead, id };
      if (cloudReady && workspaceId) cloudAddLead(workspaceId, full);
      updateActiveData((previous) => ({ ...previous, leads: [full, ...previous.leads] }));
      return id;
    },
    addTransaction: (transaction) => {
      const id = newId();
      const project = transaction.projectId ? business.projects.find((item) => item.id === transaction.projectId) : undefined;
      const full: Transaction = { ...transaction, id, invoiceSnapshot: { businessProfile: cloneProfile(business.businessProfile), design: cloneDesign(business.invoiceDesign), lineItems: projectInvoiceItems(project) } };
      if (cloudReady && workspaceId) { cloudAddTransaction(workspaceId, full); if (transaction.clientId) cloudTouchClient(workspaceId, transaction.clientId, { lastActivity: "Payment recorded today" }); }
      updateActiveData((previous) => ({ ...previous, transactions: [full, ...previous.transactions], clients: transaction.clientId ? previous.clients.map((client) => client.id === transaction.clientId ? { ...client, lastActivity: "Payment recorded today" } : client) : previous.clients }));
      return id;
    },
    addFollowUp: (followUp) => {
      const id = newId();
      const full: FollowUp = { ...followUp, id, complete: followUp.complete ?? false };
      if (cloudReady && workspaceId) cloudAddFollowUp(workspaceId, full);
      updateActiveData((previous) => ({ ...previous, followUps: [full, ...previous.followUps] }));
      return id;
    },
    addGoal: (goal) => {
      const id = newId();
      const full: Goal = { ...goal, id };
      if (cloudReady && workspaceId) cloudAddGoal(workspaceId, full);
      updateActiveData((previous) => ({ ...previous, goals: [full, ...previous.goals] }));
      return id;
    },
    addGoalStep: (goalId, title) => {
      const id = newId();
      const position = business.goals.find((g) => g.id === goalId)?.steps.length ?? 0;
      if (cloudReady && workspaceId) cloudAddGoalStep(workspaceId, goalId, { id, title, done: false }, position);
      updateActiveData((previous) => ({ ...previous, goals: previous.goals.map((g) => g.id === goalId ? { ...g, steps: [...g.steps, { id, title, done: false }] } : g) }));
    },
    toggleGoalStep: (goalId, stepId) => {
      const current = business.goals.find((g) => g.id === goalId)?.steps.find((s) => s.id === stepId)?.done ?? false;
      if (cloudReady && workspaceId) cloudToggleGoalStep(workspaceId, stepId, !current);
      updateActiveData((previous) => ({ ...previous, goals: previous.goals.map((g) => g.id === goalId ? { ...g, steps: g.steps.map((s) => s.id === stepId ? { ...s, done: !s.done } : s) } : g) }));
    },
    updateProject: (id, patch) => { if (cloudReady && workspaceId) cloudUpdateProject(workspaceId, id, patch); updateActiveData((previous) => ({ ...previous, projects: previous.projects.map((project) => project.id === id ? { ...project, ...patch } : project) })); },
    toggleDeliverable: (projectId, deliverableId) => {
      const current = business.projects.find((p) => p.id === projectId)?.deliverables.find((d) => d.id === deliverableId)?.complete ?? false;
      if (cloudReady && workspaceId) cloudToggleDeliverable(workspaceId, deliverableId, !current);
      updateActiveData((previous) => ({ ...previous, projects: previous.projects.map((project) => project.id === projectId ? { ...project, deliverables: project.deliverables.map((item) => item.id === deliverableId ? { ...item, complete: !item.complete } : item) } : project) }));
    },
    addDeliverable: (projectId, title) => {
      const id = newId();
      const position = business.projects.find((p) => p.id === projectId)?.deliverables.length ?? 0;
      if (cloudReady && workspaceId) cloudAddDeliverable(workspaceId, projectId, { id, title, complete: false }, position);
      updateActiveData((previous) => ({ ...previous, projects: previous.projects.map((project) => project.id === projectId ? { ...project, deliverables: [...project.deliverables, { id, title, complete: false }] } : project) }));
    },
    toggleTask: (projectId, taskId) => {
      const current = business.projects.find((p) => p.id === projectId)?.tasks.find((t) => t.id === taskId)?.complete ?? false;
      if (cloudReady && workspaceId) cloudToggleProjectTask(workspaceId, taskId, !current);
      updateActiveData((previous) => ({ ...previous, projects: previous.projects.map((project) => project.id === projectId ? { ...project, tasks: project.tasks.map((task) => task.id === taskId ? { ...task, complete: !task.complete } : task) } : project) }));
    },
    moveLead: (id, status) => {
      const nextFollowUp = status === "Won" ? "Converted" : business.leads.find((l) => l.id === id)?.nextFollowUp;
      if (cloudReady && workspaceId) cloudUpdateLead(workspaceId, id, { status, ...(status === "Won" ? { nextFollowUp: "Converted" } : {}) });
      updateActiveData((previous) => ({ ...previous, leads: previous.leads.map((lead) => lead.id === id ? { ...lead, status, nextFollowUp: status === "Won" ? "Converted" : lead.nextFollowUp } : lead) }));
      void nextFollowUp;
    },
    updateLead: (id, patch) => { if (cloudReady && workspaceId) cloudUpdateLead(workspaceId, id, patch); updateActiveData((previous) => ({ ...previous, leads: previous.leads.map((lead) => lead.id === id ? { ...lead, ...patch } : lead) })); },
    updateClient: (id, patch) => { if (cloudReady && workspaceId) cloudUpdateClient(workspaceId, id, patch); updateActiveData((previous) => ({ ...previous, clients: previous.clients.map((client) => client.id === id ? { ...client, ...patch } : client) })); },
    deleteClient: (id) => {
      const attached = business.projects.filter((project) => project.clientId === id).length;
      if (attached > 0) return { ok: false, reason: `${attached} project${attached === 1 ? "" : "s"} still ${attached === 1 ? "belongs" : "belong"} to this client. Delete or reassign ${attached === 1 ? "it" : "them"} first.` };
      if (cloudReady && workspaceId) cloudDeleteClient(workspaceId, id).catch((error) => console.warn("[cloud] delete client failed:", error));
      updateActiveData((previous) => ({ ...previous, clients: previous.clients.filter((client) => client.id !== id) }));
      return { ok: true };
    },
    deleteProject: (id) => {
      if (cloudReady && workspaceId) cloudDeleteProject(workspaceId, id).catch((error) => console.warn("[cloud] delete project failed:", error));
      updateActiveData((previous) => ({ ...previous, projects: previous.projects.filter((project) => project.id !== id) }));
    },
    nudgeGoal: (id) => {
      const goal = business.goals.find((g) => g.id === id);
      const nextCurrent = goal ? Math.min(goal.target, goal.current + Math.max(1, Math.round(goal.target * 0.1))) : 0;
      if (cloudReady && workspaceId) cloudUpdateGoalProgress(workspaceId, id, nextCurrent);
      updateActiveData((previous) => ({ ...previous, goals: previous.goals.map((g) => g.id === id ? { ...g, current: nextCurrent } : g) }));
    },
    updateBusinessProfile: (patch) => {
      const next = { ...business.businessProfile, ...patch };
      if (cloudReady && workspaceId) cloudUpdateBusinessProfile(workspaceId, next);
      updateActiveData((previous) => ({ ...previous, businessProfile: { ...previous.businessProfile, ...patch } }));
    },
    updateInvoiceDesign: (patch) => {
      const next = { ...business.invoiceDesign, ...patch };
      if (cloudReady && workspaceId) cloudUpdateInvoiceDesign(workspaceId, next);
      updateActiveData((previous) => ({ ...previous, invoiceDesign: { ...previous.invoiceDesign, ...patch } }));
    },
    updateInvoiceLineItems: (transactionId, lineItems) => {
      const transaction = business.transactions.find((t) => t.id === transactionId);
      const snapshot = {
        businessProfile: cloneProfile(transaction?.invoiceSnapshot?.businessProfile ?? business.businessProfile),
        design: cloneDesign(transaction?.invoiceSnapshot?.design ?? business.invoiceDesign),
        lineItems: lineItems.map((item) => ({ ...item, quantity: Math.max(1, Number(item.quantity) || 1), rate: Math.max(0, Number(item.rate) || 0), amount: Math.max(1, Number(item.quantity) || 1) * Math.max(0, Number(item.rate) || 0), description: item.description.trim() || "Service", detail: item.detail.trim() })),
      };
      if (cloudReady && workspaceId) cloudUpdateInvoiceSnapshot(workspaceId, transactionId, snapshot);
      updateActiveData((previous) => ({ ...previous, transactions: previous.transactions.map((transaction) => transaction.id === transactionId ? { ...transaction, invoiceSnapshot: snapshot } : transaction) }));
    },
    resetInvoiceDesign: () => {
      const next = { ...cloneDesign(DEFAULT_INVOICE_DESIGN), name: `${business.businessProfile.name} Default` };
      if (cloudReady && workspaceId) cloudUpdateInvoiceDesign(workspaceId, next);
      updateActiveData((previous) => ({ ...previous, invoiceDesign: { ...cloneDesign(DEFAULT_INVOICE_DESIGN), name: `${previous.businessProfile.name} Default` } }));
    },
  }), [business, hydrated, activeWorkspace, summaries, auth.user, auth.isAuthenticated, auth.loading, auth.logout, cloudSyncEnabled, lastBackupAt, deviceRemindersEnabled, cloudRemindersEnabled, workspaceId, cloudReady]);

  return <BusinessContext.Provider value={value}>{children}</BusinessContext.Provider>;
}

export function useBusiness(): BusinessContextValue { const context = useContext(BusinessContext); if (!context) throw new Error("useBusiness must be used within BusinessProvider"); return context; }
export { today };
